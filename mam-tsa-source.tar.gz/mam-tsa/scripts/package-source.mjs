import { lstat, mkdir, rename, rm } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));

// A positive file list prevents uploaded documents, local credentials, old assets,
// generated test results, or new unrelated files from entering the distribution.
export const SOURCE_FILES = Object.freeze([
  'README.md', 'LICENSE', '.gitignore', 'package.json', 'package-lock.json',
  'index.html', 'styles.css', 'app.js', 'views.js', 'learning.js', 'content.js', 'ai.js', 'storage.js', 'quality.js',
  'content/math.js', 'content/science.js', 'content/reading.js', 'server.mjs',
  'scripts/build.mjs', 'scripts/package-source.mjs',
  'tests/learning.test.mjs', 'tests/server.test.mjs', 'tests/offline.test.mjs',
  'tests/planner.test.mjs', 'tests/retention.test.mjs', 'tests/question-identity.test.mjs', 'tests/ai.test.mjs', 'tests/quality.test.mjs',
  'tools/acceptance.py', 'tools/storage-check.py', 'tools/storage-integration.py',
]);
export const OPTIONAL_FILES = Object.freeze(['dist/mam-tsa.html']);

export async function packageSource() {
  const files = [];
  for (const entry of [...SOURCE_FILES, ...OPTIONAL_FILES]) {
    let info;
    try { info = await lstat(path.join(root, entry)); }
    catch (error) {
      if (error.code === 'ENOENT' && OPTIONAL_FILES.includes(entry)) continue;
      throw new Error(`Thiếu tệp cần đóng gói: ${entry}`, { cause: error });
    }
    if (!info.isFile() || info.isSymbolicLink()) {
      throw new Error(`Chỉ đóng gói tệp thường, không nhận liên kết: ${entry}`);
    }
    // Reject symlinked parent folders as well as symlinked individual files.
    let parent = path.dirname(path.join(root, entry));
    while (parent !== root) {
      const parentInfo = await lstat(parent);
      if (!parentInfo.isDirectory() || parentInfo.isSymbolicLink()) {
        throw new Error(`Thư mục nguồn không hợp lệ: ${entry}`);
      }
      parent = path.dirname(parent);
    }
    files.push(entry);
  }
  const output = path.join(root, 'dist', 'mam-tsa-source.tar.gz');
  const temporary = output + `.tmp-${process.pid}`;
  await mkdir(path.dirname(output), { recursive: true });
  const outputDirectory = await lstat(path.dirname(output));
  if (!outputDirectory.isDirectory() || outputDirectory.isSymbolicLink()) {
    throw new Error('Thư mục dist phải là thư mục thường trong dự án.');
  }
  try {
    const result = spawnSync('tar', [
      '--create', '--gzip', '--file', temporary, '--directory', root,
      '--no-recursion', '--transform=s,^,mam-tsa/,', '--', ...files,
    ], { encoding: 'utf8', maxBuffer: 1024 * 1024 });
    if (result.error || result.status !== 0) {
      throw new Error('Chưa tạo được gói mã nguồn. Cần công cụ tar có hỗ trợ gzip và --transform.', { cause: result.error || new Error(result.stderr.trim()) });
    }
    await rename(temporary, output);
  } finally {
    await rm(temporary, { force: true });
  }
  return { output, files };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const result = await packageSource();
    console.log(`Đã tạo dist/mam-tsa-source.tar.gz (${result.files.length} tệp được cho phép).`);
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}

