import { build } from 'esbuild';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const [template, css, bundle] = await Promise.all([
  readFile(path.join(root, 'index.html'), 'utf8'),
  readFile(path.join(root, 'styles.css'), 'utf8'),
  build({
    entryPoints: [path.join(root, 'app.js')],
    bundle: true,
    write: false,
    format: 'iife',
    platform: 'browser',
    target: ['es2022'],
    charset: 'utf8',
    legalComments: 'none',
  }),
]);
let html = template.replace(/<link\b(?=[^>]*\bhref=["'](?:\.\/)?styles\.css["'])[^>]*>/gi, '');
html = html.replace(/<script\b(?=[^>]*\bsrc=["'](?:\.\/)?app\.js["'])[^>]*>\s*<\/script>/gi, '');
if (!html.includes('</head>') || !html.includes('</body>')) {
  throw new Error('index.html cần có thẻ head và body hoàn chỉnh.');
}
const safeCss = css.replace(/<\/style/gi, '<\\/style');
const safeJs = bundle.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
html = html.replace('</head>', `<style>${safeCss}</style>\n</head>`);
html = html.replace('</body>', `<script>globalThis.__TSA_STANDALONE__ = true;\n${safeJs}</script>\n</body>`);
await mkdir(path.join(root, 'dist'), { recursive: true });
await writeFile(path.join(root, 'dist', 'mam-tsa.html'), html, 'utf8');
console.log('Đã tạo dist/mam-tsa.html: CSS và JavaScript được nhúng để dùng ngoại tuyến.');
