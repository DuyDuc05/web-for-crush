export const STORAGE_KEY = 'mam-tsa-v1';
export const VERSION = 1;
const dayFormatter=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'});
const evidenceCache=new WeakMap();
export function todayKey(date = new Date()) {
  return dayFormatter.format(new Date(date));
}
export function defaultState() {
  return {version:VERSION,profile:{name:'',dailyMinutes:150,targetMonth:'2027-05',aiConsent:false},attempts:[],notes:[],reflections:[],completedLessons:[],lessonReadAt:{},studySeconds:{},assessments:[],activeAssessment:null,seed:0,chat:[],createdAt:new Date().toISOString()};
}
const txt=(v,n=1000)=>typeof v==='string'?v.slice(0,n):'';
const dateOK=v=>typeof v==='string'&&Number.isFinite(Date.parse(v));
const obj=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const canonical=v=>String(v??'').normalize('NFC').replace(/\s+/g,' ').trim();
export function questionFingerprint(q){
  const content=JSON.stringify([q.topicId,canonical(q.prompt),canonical(q.context),q.table||null,canonical(q.answer)]);
  let hash=0xcbf29ce484222325n;
  for(const char of content){hash^=BigInt(char.codePointAt(0));hash=BigInt.asUintN(64,hash*0x100000001b3n);}
  return String(q.topicId)+':content:'+hash.toString(16);
}
export function validateImport(input) {
  if(!obj(input)||input.version!==VERSION||!obj(input.profile)||!Array.isArray(input.attempts)||!Array.isArray(input.notes)||!Array.isArray(input.completedLessons))throw new Error('Tệp không phải bản sao lưu stem phiên bản 1.');
  const r=defaultState(),minutes=Number(input.profile.dailyMinutes),month=input.profile.targetMonth;
  if(!Number.isFinite(minutes)||minutes<15||minutes>480)throw new Error('Thời gian học phải từ 15 đến 480 phút/ngày.');
  if(typeof month!=='string'||!/^\d{4}-(0[1-9]|1[0-2])$/.test(month))throw new Error('Tháng mục tiêu không hợp lệ.');
  r.profile={name:txt(input.profile.name,60),dailyMinutes:Math.round(minutes),targetMonth:month,aiConsent:input.profile.aiConsent===true};
  if(input.attempts.length>500000||input.notes.length>100000)throw new Error('Tệp sao lưu quá lớn để xử lý an toàn trong một lần.');
  r.attempts=input.attempts.map(a=>{
    if(!obj(a)||!a.topicId||!a.questionId||!dateOK(a.at)||typeof a.correct!=='boolean')throw new Error('Dữ liệu bài làm không hợp lệ.');
    const hintsUsed=Math.max(0,Math.min(3,Number(a.hintsUsed)||0));
    return {id:txt(a.id,180),assessmentId:txt(a.assessmentId,180),topicId:txt(a.topicId,60),questionId:txt(a.questionId,180),questionKey:txt(a.questionKey,180),prompt:txt(a.prompt,3000),answer:txt(a.answer),expected:txt(a.expected),explanation:txt(a.explanation,5000),correct:a.correct,unknown:a.unknown===true,independent:a.independent===true&&a.correct&&!a.unknown&&hintsUsed===0,retrieval:a.retrieval===true&&a.correct&&!a.unknown&&hintsUsed===0,hintsUsed,confidence:['low','medium','high'].includes(a.confidence)?a.confidence:'medium',mode:txt(a.mode,30),difficulty:Math.max(1,Math.min(3,Number(a.difficulty)||1)),transfer:a.transfer===true,at:new Date(a.at).toISOString()};
  });
  const note=n=>{if(!obj(n)||!dateOK(n.at)||typeof n.text!=='string')throw new Error('Ghi chú trong tệp không hợp lệ.');return{id:txt(n.id,180),text:txt(n.text,10000),topicId:txt(n.topicId,60),at:n.at};};
  r.notes=input.notes.map(note);
  r.reflections=(Array.isArray(input.reflections)?input.reflections:[]).map(note);
  r.completedLessons=[...new Set(input.completedLessons.filter(v=>typeof v==='string').map(v=>v.slice(0,60)))].slice(0,200);
  if(obj(input.lessonReadAt))for(const [id,at]of Object.entries(input.lessonReadAt).slice(0,200))if(/^[a-z][a-z0-9-]{0,59}$/.test(id)&&dateOK(at))r.lessonReadAt[id]=new Date(at).toISOString();
  if(obj(input.studySeconds))for(const [k,v]of Object.entries(input.studySeconds))if(/^\d{4}-\d{2}-\d{2}$/.test(k)&&Number.isFinite(v)&&v>=0&&v<=86400)r.studySeconds[k]=Math.round(v);
  r.assessments=(Array.isArray(input.assessments)?input.assessments:[]).map(a=>{
    if(!obj(a)||!dateOK(a.at)||!Number.isInteger(a.total)||a.total<1||a.total>100||!Number.isInteger(a.correct)||a.correct<0||a.correct>a.total)throw new Error('Kết quả đánh giá không hợp lệ.');
    return{id:txt(a.id,180),mode:txt(a.mode,30),topicId:txt(a.topicId,60),startedAt:dateOK(a.startedAt)?new Date(a.startedAt).toISOString():null,at:a.at,correct:a.correct,total:a.total,unknown:Math.max(0,Math.min(a.total,Number(a.unknown)||0)),seconds:Math.max(0,Math.min(86400,Number(a.seconds)||0))};
  });
  r.seed=Math.max(0,Math.min(1e9,Number(input.seed)||0));r.createdAt=dateOK(input.createdAt)?input.createdAt:r.createdAt;
  r.chat=(Array.isArray(input.chat)?input.chat:[]).filter(m=>obj(m)&&['user','assistant'].includes(m.role)).slice(-30).map(m=>({role:m.role,content:txt(m.content,6000),mode:m.mode==='online'?'online':'guided'}));
  const a=input.activeAssessment;
  if(obj(a)&&['topic','diagnostic','practice','review'].includes(a.mode)&&Array.isArray(a.questions)&&a.questions.length>0&&a.questions.length<=100&&Array.isArray(a.results)&&Number.isInteger(a.index)&&a.index>=0&&a.index<a.questions.length&&dateOK(a.startedAt)){
    const valid=a.questions.every(q=>obj(q)&&typeof q.id==='string'&&typeof q.topicId==='string'&&typeof q.prompt==='string'&&Array.isArray(q.options)&&q.options.length>=2&&q.options.length<=6&&q.options.every(o=>typeof o==='string'&&o.length<=3000)&&new Set(q.options).size===q.options.length&&q.options.includes(q.answer)&&typeof q.explanation==='string'&&Array.isArray(q.hints)&&q.hints.every(h=>typeof h==='string')&&(!q.context||typeof q.context==='string'));
    if(valid)r.activeAssessment={id:txt(a.id,180),mode:a.mode,topicId:txt(a.topicId,60),index:a.index,questions:a.questions.map(q=>({id:q.id.slice(0,180),topicId:q.topicId.slice(0,60),prompt:q.prompt.slice(0,5000),options:q.options.map(o=>o.slice(0,3000)),answer:q.answer.slice(0,3000),explanation:q.explanation.slice(0,6000),hints:q.hints.slice(0,3).map(h=>h.slice(0,3000)),misconception:txt(q.misconception,3000),difficulty:Number(q.difficulty)||1,transfer:q.transfer===true,context:txt(q.context,10000),table:validTable(q.table)?q.table:undefined})),results:a.results.slice(0,a.questions.length).map(v=>({correct:v?.correct===true,unknown:v?.unknown===true})),startedAt:a.startedAt,expiresAt:dateOK(a.expiresAt)?a.expiresAt:null,selection:txt(a.selection,3000),hintLevel:Math.max(0,Math.min(3,Number(a.hintLevel)||0)),confidence:['low','medium','high'].includes(a.confidence)?a.confidence:'medium',answered:a.answered===true,lastCorrect:a.lastCorrect===true,lastUnknown:a.lastUnknown===true};
  }
  return r;
}
function validTable(t){return obj(t)&&Array.isArray(t.headers)&&t.headers.length<=10&&t.headers.every(v=>typeof v==='string'&&v.length<200)&&Array.isArray(t.rows)&&t.rows.length<=30&&t.rows.every(row=>Array.isArray(row)&&row.length<=10&&row.every(v=>['string','number'].includes(typeof v)));}
export function recordAttempt(state,q,answer,options={}){
  const at=new Date(options.at||Date.now()).toISOString(),unknown=answer==='__unknown',hintsUsed=Math.max(0,Math.min(3,options.hintsUsed||0)),correct=!unknown&&answer===q.answer;
  const questionKey=questionFingerprint(q);
  const previous=state.attempts.findLast(v=>v.questionId===q.id||v.questionKey===questionKey||(!v.questionKey&&v.topicId===q.topicId&&canonical(v.prompt)===canonical(q.prompt)));
  const retrieval=correct&&hintsUsed===0&&Boolean(previous)&&Date.parse(at)-Date.parse(previous.at)>=86400000;
  const a={id:q.id+':'+at+':'+state.attempts.length,assessmentId:txt(options.assessmentId,180),questionId:q.id,questionKey,topicId:q.topicId,prompt:q.prompt,answer:unknown?'Chưa học / chưa biết':String(answer),expected:q.answer,explanation:q.explanation,correct,unknown,hintsUsed,independent:correct&&hintsUsed===0&&!previous,retrieval,confidence:options.confidence||'medium',mode:options.mode||'topic',difficulty:q.difficulty||1,transfer:q.transfer===true,at};
  return{...state,attempts:[...state.attempts,a]};
}
export function topicEvidence(state,id,now=new Date()){
  let cache=evidenceCache.get(state.attempts);
  if(!cache){cache=new Map();evidenceCache.set(state.attempts,cache);}
  if(cache.has(id)){const value=cache.get(id);return{...value,isDue:value.dueAt!==null&&Date.parse(value.dueAt)<=new Date(now).getTime()};}
  const a=state.attempts.filter(v=>v.topicId===id),known=a.filter(v=>!v.unknown),independent=a.filter(v=>v.independent),retrieved=a.filter(v=>v.retrieval),guided=known.filter(v=>v.correct&&v.hintsUsed>0),repeated=known.filter(v=>v.correct&&!v.independent&&!v.retrieval&&v.hintsUsed===0),memory=[...independent,...retrieved],days=new Set(memory.map(v=>todayKey(v.at))),transfer=independent.filter(v=>v.transfer).length,last=a.at(-1);
  let first=Infinity,latest=-Infinity;for(const item of memory){const at=Date.parse(item.at);first=Math.min(first,at);latest=Math.max(latest,at);}const span=memory.length?latest-first:0;
  const retained=days.size>=2&&span>=86400000&&independent.length>=3&&transfer>=1;
  const failed=known.filter(v=>!v.correct).length,effective=independent.length+retrieved.length+guided.length+failed;
  let score=effective?Math.round((independent.length+retrieved.length+guided.length*.3)/(effective+2)*100):0;score=Math.min(retained?95:60,score);
  const needsHelp=known.slice(-3).filter(v=>!v.correct).length>=2;
  const label=!known.length?'Chưa đủ dữ liệu':needsHelp?'Cần củng cố':retained?'Có bằng chứng nhớ lại':independent.length>=2?'Đang tự làm được':'Đang xây nền';
  let dueAt=null;
  if(last&&!last.unknown){const daysLater=!last.correct?10/1440:last.hintsUsed?1:independent.length<2?1:independent.length<4?3:independent.length<7?7:14;dueAt=new Date(Date.parse(last.at)+daysLater*86400000).toISOString();}
  const value={attempts:a.length,known:known.length,independent:independent.length,guided:guided.length,retrieval:retrieved.length,repeated:repeated.length,failed,unknown:a.length-known.length,days:days.size,transfer,score,label,retained,dueAt,confidenceErrors:known.filter(v=>!v.correct&&v.confidence==='high').length};
  cache.set(id,value);return{...value,isDue:dueAt!==null&&Date.parse(dueAt)<=new Date(now).getTime()};
}
export function recommendTopics(state,topics,now=new Date()){
  const priority=t=>{const e=topicEvidence(state,t.id,now);if(e.isDue)return-100+e.score/10;const missing=(t.prerequisites||[]).filter(id=>topicEvidence(state,id,now).independent<2).length;return missing*100+e.score+(t.level||0)*10;};
  const priorities=new Map(topics.map(t=>[t.id,priority(t)]));
  return[...topics].sort((a,b)=>priorities.get(a.id)-priorities.get(b.id));
}
export function studyPlan(minutes=150){const n=Math.max(15,Math.min(480,Number(minutes)||150)),first=Math.floor(n/3);return[first,first,n-first*2].map((total,index)=>({index,total,rest:Math.min(5,Math.floor(total/5)),focus:total-Math.min(5,Math.floor(total/5))}));}
export function activityDays(state){return[...new Set([...state.attempts.map(a=>todayKey(a.at)),...Object.entries(state.studySeconds).filter(([,v])=>v>=60).map(([k])=>k)])].sort();}
export function learningStreak(state,now=new Date()){const days=new Set(activityDays(state)),date=new Date(now);if(!days.has(todayKey(date)))date.setUTCDate(date.getUTCDate()-1);let n=0;while(days.has(todayKey(date))){n++;date.setUTCDate(date.getUTCDate()-1);if(n>10000)break;}return n;}
export function createQuestions(topics,state,mode,topicId){
  const seed=state.seed||0;
  if(mode==='topic'){const t=topics.find(t=>t.id===topicId);if(!t)throw new Error('Không tìm thấy chủ đề.');return Array.from({length:5},(_,i)=>t.makeQuestion(seed+i));}
  if(mode==='review'){const due=recommendTopics(state,topics).filter(t=>topicEvidence(state,t.id).attempts>0).slice(0,5),chosen=due.length?due:recommendTopics(state,topics).slice(0,5);return chosen.map((t,i)=>t.makeQuestion(seed+i+10));}
  const groups={math:topics.filter(t=>t.domain==='math'),science:topics.filter(t=>t.domain==='science'),reading:topics.filter(t=>t.domain==='reading')},counts=mode==='diagnostic'?{math:6,science:3,reading:3}:{math:6,science:6,reading:3},result=[];
  for(const domain of ['math','reading','science'])for(let i=0;i<counts[domain];i++){const list=groups[domain];if(!list.length)throw new Error('Thiếu nội dung '+domain);result.push(list[(i+(mode==='diagnostic'?0:Math.floor(seed/3)))%list.length].makeQuestion(seed+i+result.length+30));}
  return result;
}
export function sourceLabel(topic){const s=topic?.source;if(!s)return'Nội dung tự biên soạn.';return s.label+(s.chapter?' · chương '+s.chapter:'')+(s.part?' · phần '+s.part+', trang PDF '+s.pages:'');}
export function weeklyPlan(state,topics,now=new Date()){
  const day=new Date(todayKey(now)+'T00:00:00Z'),weekMs=7*86400000;
  const mondayOf=value=>{const monday=new Date(value);monday.setUTCDate(monday.getUTCDate()-((monday.getUTCDay()+6)%7));return monday;};
  // Preserve the learner's original calendar instead of rebuilding week one on
  // every visit. validateImport also retains this creation timestamp in backups.
  const created=dateOK(state.createdAt)?new Date(todayKey(state.createdAt)+'T00:00:00Z'):day;
  const started=Number.isFinite(created.getTime())?created:day,origin=mondayOf(started);
  const target=new Date(state.profile.targetMonth+'-01T00:00:00Z');
  const past=target<=day,goalWeeks=Math.max(4,Math.ceil((target-origin)/weekMs));
  let anchor=origin,totalWeeks=goalWeeks,cycle=1,offset=0,mode='goal';
  if(past){
    // A named, stable four-week continuation cycle keeps the app useful after
    // the goal date without pretending a new exam countdown has begun.
    const continuationOrigin=mondayOf(new Date(Math.max(target.getTime(),started.getTime())));
    cycle=Math.max(0,Math.floor((day-continuationOrigin)/(4*weekMs)))+1;
    anchor=new Date(continuationOrigin.getTime()+(cycle-1)*4*weekMs);
    totalWeeks=4;mode='continuation';
  }else if(goalWeeks>52){
    // Bound the rendered list, not the usable lifetime. Later years advance
    // to the next anchored block and keep continuous week numbers.
    cycle=Math.max(0,Math.floor((day-origin)/(52*weekMs)))+1;
    offset=(cycle-1)*52;anchor=new Date(origin.getTime()+offset*weekMs);
    totalWeeks=Math.min(52,Math.max(4,Math.ceil((target-anchor)/weekMs)));mode='year';
  }
  const currentIndex=Math.max(0,Math.min(totalWeeks-1,Math.floor((day-anchor)/weekMs)));
  const foundationWeeks=Math.max(2,Math.ceil(totalWeeks*.4)),connectionWeeks=Math.max(1,Math.ceil(totalWeeks*.3));
  const groups=[
    ['numbers','reading-evidence','units'],['fractions','percent','chemistry'],
    ['algebra','linear','motion'],['geometry','functions','reading-inference'],
    ['quadratic','exponents','forces'],['trigonometry','probability','energy'],
    ['statistics','experiment','reading-structure']
  ];
  const weak=recommendTopics(state,topics,now).filter(t=>topicEvidence(state,t.id,now).failed>0).map(t=>t.id);
  const focusMinutes=studyPlan(state.profile.dailyMinutes).reduce((sum,p)=>sum+p.focus,0)*7;
  const weeks=Array.from({length:totalWeeks},(_,index)=>{
    const phase=index<foundationWeeks?'Gieo nền tảng':index<foundationWeeks+connectionWeeks?'Kết nối & tự làm':'Luyện xen kẽ & nhớ lại';
    const group=index<foundationWeeks?Math.min(6,Math.floor(index*groups.length/foundationWeeks)):(index-foundationWeeks)%groups.length;
    let ids=[...groups[group]];
    if(index>=foundationWeeks&&weak.length)ids=[weak[(index-foundationWeeks)%weak.length],...ids].slice(0,3);
    const start=new Date(anchor);start.setUTCDate(start.getUTCDate()+index*7);
    const end=new Date(start);end.setUTCDate(end.getUTCDate()+6);
    return{number:offset+index+1,start:start.toISOString(),end:end.toISOString(),phase,isCurrent:index===currentIndex,topicIds:[...new Set(ids)].filter(id=>topics.some(t=>t.id===id)),focusMinutes,
      objective:index<foundationWeeks?'Nói rõ ý tưởng, làm ví dụ nhỏ và tự làm bài đổi số.':index<foundationWeeks+connectionWeeks?'Chọn cách làm, kiểm tra điều kiện và sửa lỗi đã gặp.':'Làm bài trộn có giờ, giải thích lỗi và thử nhớ lại sau ít nhất một ngày.'};
  });
  return{weeks,past,totalWeeks,focusMinutes,scheduledMinutes:state.profile.dailyMinutes*7,rolling:mode!=='goal',mode,cycle,currentWeek:offset+currentIndex+1,startedAt:origin.toISOString(),windowStart:anchor.toISOString()};
}
