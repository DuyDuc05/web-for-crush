import { mathTopics } from './content/math.js';
import { scienceTopics } from './content/science.js';
import { readingTopics } from './content/reading.js';
export const topics=[...mathTopics,...readingTopics,...scienceTopics];
export const domains={
  math:{title:'Tư duy Toán học',short:'Toán học',icon:'math',color:'green'},
  reading:{title:'Tư duy Đọc hiểu',short:'Đọc hiểu',icon:'book',color:'purple'},
  science:{title:'Tư duy Khoa học',short:'Khoa học',icon:'science',color:'peach'}
};
