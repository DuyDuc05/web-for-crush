import { topicEvidence } from './learning.js';

const DAY = 86400000;
const validTime = value => typeof value === 'string' && Number.isFinite(Date.parse(value));
const earlier = (a, b) => !a ? b : !b ? a : Date.parse(a) <= Date.parse(b) ? a : b;

// Completion means the learner has read a section. It is deliberately separate
// from evidence that they can solve, transfer and remember its ideas.
export function chapterQuality(state, topic, now = new Date()) {
  const topicId = typeof topic === 'string' ? topic : topic.id;
  const read = state.completedLessons.includes(topicId);
  const lastReadAt = validTime(state.lessonReadAt?.[topicId]) ? new Date(state.lessonReadAt[topicId]).toISOString() : null;
  const attempts = state.attempts.filter(a => a.topicId === topicId);
  const evidence = topicEvidence(state, topicId, now);
  const assessments = (state.assessments || []).filter(a => a.mode === 'topic' && a.topicId === topicId);
  let latest = null;
  for (const assessment of assessments) {
    // Completing an old, already-answered quiz after rereading is not a new
    // knowledge check. A recorded read time needs an actual new quiz start.
    // Older backups without read timestamps continue to accept their results.
    const afterRead = !lastReadAt || (validTime(assessment.startedAt) && Date.parse(assessment.startedAt) >= Date.parse(lastReadAt) && Date.parse(assessment.startedAt) <= Date.parse(assessment.at));
    if (afterRead && (!latest || Date.parse(assessment.at) >= Date.parse(latest.at))) latest = assessment;
  }
  const latestAssessment = latest ? { id: latest.id, at: latest.at, correct: latest.correct, total: latest.total, unknown: latest.unknown || 0 } : null;

  // Use the stable assessment ID for current quizzes. For legacy backups, only
  // describe answer types when final topic-mode answers reconcile with a result.
  let assessmentEvidence = null;
  if (latest) {
    let previousAt = -Infinity;
    for (const assessment of assessments) {
      const at = Date.parse(assessment.at);
      if (at < Date.parse(latest.at)) previousAt = Math.max(previousAt, at);
    }
    const identified = attempts.filter(a => a.assessmentId && a.assessmentId === latest.id);
    const answers = identified.length ? identified : attempts.filter(a => !a.assessmentId && a.mode === 'topic' && Date.parse(a.at) <= Date.parse(latest.at) && Date.parse(a.at) > previousAt).slice(-latest.total);
    if (answers.length === latest.total && answers.filter(a => a.correct).length === latest.correct && answers.filter(a => a.unknown).length === (latest.unknown || 0)) {
      assessmentEvidence = {
        independent: answers.filter(a => a.independent).length,
        retrieval: answers.filter(a => a.retrieval).length,
        guided: answers.filter(a => a.correct && a.hintsUsed > 0).length,
        repeated: answers.filter(a => a.correct && !a.independent && !a.retrieval && !a.hintsUsed).length,
        wrong: answers.filter(a => !a.correct && !a.unknown).length,
        unknown: answers.filter(a => a.unknown).length
      };
    }
  }

  const reflectionCount = (state.reflections || []).filter(r => r.topicId === topicId).length;
  let dueAt = evidence.dueAt;
  if (!evidence.retained && evidence.independent >= 3 && evidence.transfer >= 1) {
    let lastSelfSolved = -Infinity;
    for (const a of attempts) if (a.independent || a.retrieval) lastSelfSolved = Math.max(lastSelfSolved, Date.parse(a.at));
    if (Number.isFinite(lastSelfSolved)) dueAt = earlier(dueAt, new Date(lastSelfSolved + DAY).toISOString());
  }
  const isDue = dueAt !== null && Date.parse(dueAt) <= new Date(now).getTime();
  const quizSummary = latest ? `Bài kiểm tra cuối phần gần nhất: ${latest.correct}/${latest.total} câu đúng${latest.unknown ? `, ${latest.unknown} câu chưa biết` : ''}. ` : '';
  let status, label, summary, nextAction, nextLabel;

  if (!latest) {
    if (read) {
      status = 'read-untested'; label = 'Đã đọc · chưa kiểm tra';
      summary = lastReadAt ? 'Chưa có bài kiểm tra cuối phần sau lần đánh dấu đã đọc mới nhất.' : 'Đánh dấu đã đọc chưa cho biết bạn có tự làm được hay không.';
      nextAction = 'assess'; nextLabel = 'Kiểm tra 5 câu cuối phần';
    } else if (attempts.length) {
      status = 'started-untested'; label = 'Đã thử · chưa kiểm tra cuối phần';
      summary = 'Đã có bài làm về chủ đề này, nhưng chưa có bài kiểm tra cuối phần riêng.';
      nextAction = 'assess'; nextLabel = 'Kiểm tra 5 câu cuối phần';
    } else {
      status = 'not-started'; label = 'Chưa học phần này';
      summary = 'Bắt đầu từ ý tưởng và ví dụ, rồi tự làm bài để biết chỗ mình chưa hiểu.';
      nextAction = 'learn'; nextLabel = 'Học phần này';
    }
  } else {
    const latestWrong = latest.total - latest.correct - (latest.unknown || 0);
    // A later correct answer to a different question does not close a new gap.
    // Keep it visible until a subsequent end-of-section quiz checks the topic.
    const newGap = attempts.some(a => Date.parse(a.at) > Date.parse(latest.at) && !a.correct);
    if (latestWrong > 0 || latest.unknown > 0 || newGap) {
      status = 'needs-repair'; label = 'Cần củng cố chỗ chưa hiểu';
      summary = quizSummary + (newGap ? 'Bài làm sau đó còn có câu sai hoặc chưa biết. ' : '') + 'Xem lại lỗi và ý tưởng liên quan, rồi làm một bài kiểm tra mới.';
      nextAction = 'learn'; nextLabel = 'Xem lại bài và lỗi sai';
    } else if (assessmentEvidence && assessmentEvidence.independent + assessmentEvidence.retrieval === 0) {
      status = 'needs-independent'; label = 'Cần tự làm bài mới';
      summary = quizSummary + 'Những câu đúng trong bài này đều đã dùng gợi ý hoặc vừa làm lặp lại; chưa tạo thêm bằng chứng tự hiểu.';
      nextAction = 'assess'; nextLabel = 'Tự làm bài mới, không gợi ý';
    } else if (evidence.independent < 3 || evidence.transfer < 1) {
      status = 'needs-independent'; label = 'Cần thêm bằng chứng tự làm';
      summary = quizSummary + `Đã tự làm đúng ${evidence.independent} câu mới; cần ít nhất 3 câu mới và 1 câu đổi bối cảnh trước khi kiểm tra khả năng nhớ lại.`;
      nextAction = 'assess'; nextLabel = 'Thử câu mới và đổi bối cảnh';
    } else if (!evidence.retained) {
      status = isDue ? 'due-recall' : 'awaiting-recall';
      label = isDue ? 'Đến lúc kiểm tra nhớ lại' : 'Tự làm được · chờ nhớ lại';
      summary = quizSummary + 'Đã có bằng chứng tự làm và đổi bối cảnh. Cần tự làm lại sau ít nhất 24 giờ; đúng ngay sau khi học chưa chứng minh nhớ lâu.';
      nextAction = 'review'; nextLabel = isDue ? 'Kiểm tra nhớ lại phần này' : 'Lên lịch kiểm tra nhớ lại';
    } else {
      status = isDue ? 'due-review' : 'retained';
      label = isDue ? 'Đến hạn ôn lại' : 'Có bằng chứng nhớ lại';
      summary = quizSummary + 'Đã tự làm câu mới, đổi bối cảnh và nhớ lại cách nhau ít nhất 24 giờ. Tiếp tục ôn xen kẽ để kiểm tra kiến thức còn vững.';
      nextAction = 'review'; nextLabel = isDue ? 'Ôn lại phần này' : 'Kiểm tra lại phần này';
    }
  }

  return {
    topicId, read, lastReadAt, hasReflection: reflectionCount > 0, reflectionCount,
    hasAssessment: Boolean(latest), assessmentAt: latest?.at || null, latestAssessment, assessmentEvidence,
    attempts: evidence.attempts, independent: evidence.independent, guided: evidence.guided,
    repeated: evidence.repeated, retrieval: evidence.retrieval, wrong: evidence.failed, unknown: evidence.unknown,
    transfer: evidence.transfer, retained: evidence.retained, dueAt, isDue,
    status, label, summary, nextAction, nextLabel,
    reflectionNotice: reflectionCount ? 'Đã lưu lời giải thích của bạn; ứng dụng chưa tự chấm chất lượng phần viết này.' : 'Chưa có lời giải thích bằng lời của bạn.'
  };
}

export function qualityOverview(state, topics, now = new Date()) {
  const chapters = topics.map(topic => chapterQuality(state, topic, now));
  return {
    chapters,
    read: chapters.filter(q => q.read).length,
    pendingReadUntested: chapters.filter(q => q.read && !q.hasAssessment).length,
    assessed: chapters.filter(q => q.hasAssessment).length,
    needsReview: chapters.filter(q => q.hasAssessment && (q.isDue || ['needs-repair', 'needs-independent'].includes(q.status))).length,
    retained: chapters.filter(q => ['retained', 'due-review'].includes(q.status)).length
  };
}
