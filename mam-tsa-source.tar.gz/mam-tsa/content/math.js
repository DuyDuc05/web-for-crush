// Original beginner lessons and deterministic exercises. Sources identify ideas,
// not copied exercises. These questions are not calibrated TSA examinations.

const integerSeed = (seed) => Math.abs(Math.trunc(Number(seed) || 0));
function params(seed) {
  let state = (integerSeed(seed) + 0x9e3779b9) >>> 0;
  return (min, max) => {
    state = (Math.imul(state ^ (state >>> 16), 0x21f0aaad) + 0x735a2d97) >>> 0;
    state = Math.imul(state ^ (state >>> 15), 0x735a2d97) >>> 0;
    return min + (state % (max - min + 1));
  };
}
function gcd(a, b) {
  a = Math.abs(a); b = Math.abs(b);
  while (b) [a, b] = [b, a % b];
  return a || 1;
}
function frac(a, b) {
  if (!Number.isInteger(a) || !Number.isInteger(b) || !b) throw new Error('Invalid fraction');
  if (b < 0) { a = -a; b = -b; }
  const d = gcd(a, b); a /= d; b /= d;
  return b === 1 ? String(a) : `${a}/${b}`;
}
const num = (n) => String(Math.round(n * 1e8) / 1e8).replace('.', ',');
const money = (n) => `${num(n)} đồng`;
const sign = (n) => n < 0 ? `− ${Math.abs(n)}` : `+ ${n}`;
const factor = (r) => r < 0 ? `(x + ${-r})` : r === 0 ? 'x' : `(x − ${r})`;
const roots = (a, b) => {
  const values = [...new Set([a, b])].sort((x, y) => x - y);
  return values.length === 1 ? `Chỉ x = ${values[0]}` : `x = ${values[0]} hoặc x = ${values[1]}`;
};

function question(topicId, seed, spec) {
  const answer = String(spec.answer);
  const choices = [...new Set([answer, ...spec.wrong.map(String)])].slice(0, 4);
  if (choices.length !== 4) throw new Error(`Insufficient distinct choices: ${topicId}:${seed}`);
  // Fisher–Yates: reproducible, with the correct choice in varying positions.
  const pick = params(integerSeed(seed) + 6173);
  for (let i = choices.length - 1; i > 0; i--) {
    const j = pick(0, i); [choices[i], choices[j]] = [choices[j], choices[i]];
  }
  const { wrong, ...rest } = spec;
  return { id: `${topicId}:${seed}`, topicId, difficulty: 1, transfer: integerSeed(seed) % 3 === 2,
    ...rest, answer, options: choices };
}

export const mathTopics = [
  {
    id: 'numbers', domain: 'math', title: 'Làm bạn với các con số', subtitle: 'Số âm, thứ tự tính và cách tự kiểm tra',
    icon: 'calculator', color: 'green', minutes: 15, level: 0, prerequisites: [],
    why: 'Số học là viên gạch đầu của đại số, tốc độ, phần trăm và việc đọc dữ liệu. Ta học ý nghĩa trước khi tăng tốc.',
    concepts: [
      'Trên trục số, sang phải là lớn hơn. Số −2 lớn hơn −5 vì nằm gần phía bên phải hơn; dấu âm không có nghĩa là số đó “không dùng được”.',
      'Cộng số dương là tiến sang phải; cộng số âm là tiến sang trái. Trừ một số là cộng số đối của nó: 3 − (−2) = 3 + 2.',
      'Tính phần trong ngoặc trước, rồi lũy thừa, nhân/chia, cuối cùng cộng/trừ. Các phép cùng mức làm từ trái sang phải. Dấu bằng nói hai bên có cùng giá trị.'
    ],
    example: { prompt: 'Nhiệt độ đang −4 °C, sau đó tăng 7 °C. Nhiệt độ mới là bao nhiêu?',
      steps: ['Bắt đầu ở −4 trên trục số.', 'Tăng 4 °C thì tới 0 °C; còn tăng thêm 3 °C.', 'Vậy −4 + 7 = 3. Kết quả lớn hơn nhiệt độ cũ, hợp với việc tăng.'], answer: '3 °C' },
    reflection: 'Hãy giải thích bằng lời vì sao 5 − (−3) bằng 8. Bạn có thể kể một ví dụ về việc bỏ đi một khoản nợ.',
    source: { label: 'THCP, nền số âm và phép tính; bài học tự biên soạn', chapter: '52.11.3–52.11.5', part: 5, pages: '47–51' }, visual: 'numberline',
    makeQuestion(seed = 0) {
      const r = params(seed); const a = r(2, 16), b = r(2, 13); const mode = integerSeed(seed) % 4;
      if (mode === 0) return question('numbers', seed, { prompt: `Nhiệt độ đang −${a} °C và tăng ${b} °C. Nhiệt độ mới là bao nhiêu?`,
        answer: `${b - a} °C`, wrong: [`${a + b} °C`, `${-a - b} °C`, `${b - a + 1} °C`],
        explanation: `Bắt đầu ở −${a}, đi sang phải ${b} đơn vị: −${a} + ${b} = ${b - a} °C. Tăng nhiệt độ không nhất thiết làm kết quả dương.`,
        hints: ['Tăng nghĩa là cộng, hãy bắt đầu ở vị trí âm.', `Viết phép tính −${a} + ${b}.`, `So sánh ${b} với ${a}; lấy hiệu và giữ dấu theo phía cuối trên trục số.`], misconception: 'Bỏ dấu âm ban đầu hoặc nghĩ rằng tăng thì chắc chắn thành số dương.' });
      if (mode === 1) return question('numbers', seed, { prompt: `Tính ${a} − (−${b}).`, answer: String(a + b),
        wrong: [String(a - b), String(-a - b), String(a + b + 1)], explanation: `Số đối của −${b} là ${b}. Vì vậy ${a} − (−${b}) = ${a} + ${b} = ${a + b}.`,
        hints: ['Trừ một số là cộng số đối của số đó.', `Số đối của −${b} là +${b}.`, `Phép tính trở thành ${a} + ${b}.`], misconception: 'Trừ số âm thành trừ số dương.' });
      if (mode === 2) {
        const c = r(2, 6); return question('numbers', seed, { prompt: `Tính ${a} + ${b} × ${c}.`, answer: String(a + b * c),
          wrong: [String((a + b) * c), String(a + b + c), String(a + b * c + 1), String(a + b * c - 1), String(a + b * c + 2)],
          explanation: `Nhân trước: ${b} × ${c} = ${b * c}. Sau đó ${a} + ${b * c} = ${a + b * c}. Không có ngoặc để cộng ${a} với ${b} trước.`,
          hints: ['Nhân và chia có mức ưu tiên cao hơn cộng và trừ.', `Làm ${b} × ${c} trước.`, `Thay tích bằng ${b * c}, rồi cộng với ${a}.`], misconception: 'Luôn tính mọi phép từ trái sang phải mà bỏ mức ưu tiên.' });
      }
      return question('numbers', seed, { prompt: `Số nào lớn nhất trong −${a + 3}, −${a}, 0 và ${b}?`, answer: String(b),
        wrong: [String(-a - 3), String(-a), '0'], explanation: `${b} dương, nên lớn hơn 0 và cả hai số âm. Trên trục số, nó nằm xa nhất về phía bên phải.`,
        hints: ['Chia các số thành âm, 0 và dương.', 'Mọi số dương đều lớn hơn 0; mọi số âm nhỏ hơn 0.', `Trong bốn số chỉ có ${b} là dương.`], misconception: 'So sánh độ lớn của các chữ số nhưng quên dấu âm.' });
    }
  },
  {
    id: 'fractions', domain: 'math', title: 'Phân số có ý nghĩa gì?', subtitle: 'Cùng một đơn vị rồi mới cộng',
    icon: 'pie', color: 'peach', minutes: 15, level: 0, prerequisites: ['numbers'],
    why: 'Phân số giúp diễn tả một phần của toàn thể, tỉ lệ trong hình học, xác suất và dữ liệu khoa học.',
    concepts: [
      'Trong 3/5, mẫu 5 nói một đơn vị được chia thành 5 phần bằng nhau; tử 3 nói ta lấy 3 phần. Mẫu số phải khác 0.',
      '1/2 và 2/4 là cùng một lượng, được chia theo hai cách. Nhân hoặc chia cả tử và mẫu với cùng một số khác 0 giữ nguyên giá trị.',
      'Để cộng, đổi về các phần cùng cỡ. Để chia cho một phân số khác 0, nhân với nghịch đảo của nó; kiểm lại bằng phép nhân.'
    ],
    example: { prompt: 'Có 1/3 lít nước, thêm 1/6 lít. Tổng là bao nhiêu?',
      steps: ['Chia 1 lít thành 6 phần bằng nhau.', '1/3 lít chiếm 2 phần sáu; thêm 1 phần sáu được 3 phần sáu.', '3/6 = 1/2 lít. Tổng phải lớn hơn 1/3 vì có thêm nước.'], answer: '1/2 lít' },
    reflection: 'Vì sao 1/2 + 1/3 không bằng 2/5? Hãy dùng một chiếc bánh hoặc một thanh dài 1 mét để giải thích.',
    source: { label: 'THCP, phân số và đơn vị; bài học tự biên soạn', chapter: '52.11.6–52.11.7', part: 5, pages: '52–54' }, visual: 'fraction',
    makeQuestion(seed = 0) {
      const r = params(seed), d = r(3, 9), a = r(1, d - 1), k = r(2, 5), mode = integerSeed(seed) % 3;
      if (mode === 0) {
        const b = r(1, 4), n = 2 * a + b;
        return question('fractions', seed, { prompt: `Tính ${a}/${d} + ${b}/${2 * d}. Chọn kết quả ở dạng tối giản.`, answer: frac(n, 2 * d),
          wrong: [frac(a + b, 3 * d), frac(a + b, 2 * d), frac(n, d), frac(n, 3 * d), frac(n + 1, 2 * d)],
          explanation: `${a}/${d} = ${2 * a}/${2 * d}. Cộng các phần cùng cỡ: (${2 * a} + ${b})/${2 * d} = ${frac(n, 2 * d)}. Ta không cộng hai mẫu số.`,
          hints: ['Tìm một mẫu chung; mẫu lớn đã là bội của mẫu nhỏ.', `Đổi ${a}/${d} thành ${2 * a}/${2 * d}.`, `Cộng hai tử ${2 * a} và ${b}, giữ mẫu ${2 * d}, rồi rút gọn.`], misconception: 'Cộng cả tử lẫn mẫu hoặc đổi mẫu mà không đổi tử.' });
      }
      if (mode === 1) return question('fractions', seed, { prompt: `Tính (${a}/${d}) ÷ (1/${k}). Chọn dạng tối giản.`, answer: frac(a * k, d),
        wrong: [frac(a, d * k), frac(a, d), frac(a + k, d), frac(a * k + 1, d)],
        explanation: `Chia cho 1/${k} là nhân với ${k}: (${a}/${d}) × ${k} = ${frac(a * k, d)}. Chia cho một phần nhỏ hơn 1 làm số dương ban đầu lớn lên.`,
        hints: ['Số chia là phân số khác 0.', `Nghịch đảo của 1/${k} là ${k}.`, `Nhân tử ${a} với ${k}, giữ mẫu ${d}, rồi rút gọn.`], misconception: 'Nhân với số chia thay vì nghịch đảo của số chia.' });
      const total = d * k, amount = a * k;
      return question('fractions', seed, { prompt: `Một hộp có ${total} thẻ. ${a}/${d} số thẻ là màu xanh. Có bao nhiêu thẻ xanh?`, answer: `${amount} thẻ`,
        wrong: [`${total - amount} thẻ`, `${a + k} thẻ`, `${amount + 1} thẻ`, `${total + amount} thẻ`, `${total + amount + 1} thẻ`],
        explanation: `Một phần ${d} của ${total} là ${total} ÷ ${d} = ${k} thẻ. Lấy ${a} phần được ${a} × ${k} = ${amount} thẻ.`,
        hints: ['Tìm một phần trước, rồi lấy số phần cần thiết.', `Chia ${total} thẻ thành ${d} nhóm bằng nhau.`, `Mỗi nhóm có ${k} thẻ; cần lấy ${a} nhóm.`], misconception: 'Lấy phần còn lại hoặc chỉ nhân tử và mẫu mà không xét toàn thể.' });
    }
  },
  {
    id: 'percent', domain: 'math', title: 'Phần trăm và gốc so sánh', subtitle: '100% đang là lượng nào?',
    icon: 'percent', color: 'purple', minutes: 15, level: 0, prerequisites: ['fractions'],
    why: 'Tăng giảm giá, nồng độ, số liệu thí nghiệm và xác suất đều cần hiểu rõ phần trăm được tính trên lượng nào.',
    concepts: [
      'p% nghĩa là p phần trong 100 phần bằng nhau: 25% = 25/100 = 1/4. Muốn lấy p% của một lượng, nhân lượng đó với p/100.',
      'Tăng 10% đưa lượng cũ thành 1,10 lần; giảm 10% đưa thành 0,90 lần. Hai lần thay đổi liên tiếp thường có hai gốc 100% khác nhau.',
      'Muốn tìm lượng gốc từ lượng sau giảm, chia cho hệ số còn lại. Không cộng lại đúng phần trăm của giá đã giảm.'
    ],
    example: { prompt: 'Áo 240000 đồng giảm 25%, rồi thêm phí 10% của giá sau giảm. Trả bao nhiêu?',
      steps: ['Sau giảm: 240000 × 0,75 = 180000 đồng.', 'Phí: 180000 × 0,10 = 18000 đồng.', 'Tổng 198000 đồng. Mức giảm thực là 17,5% so với 240000 đồng.'], answer: '198000 đồng' },
    reflection: 'Một số tăng 20% rồi giảm 20% có về ban đầu không? Hãy thử với 100 và chỉ rõ gốc của mỗi lần tính.',
    source: { label: 'THCP, phần trăm và gốc so sánh; bài học tự biên soạn', chapter: '52.11.8', part: 5, pages: '54–57' }, visual: 'fraction',
    makeQuestion(seed = 0) {
      const r = params(seed), base = r(2, 12) * 100000, p = r(1, 6) * 5, mode = integerSeed(seed) % 3;
      if (mode === 0) return question('percent', seed, { prompt: `Một khoản ${base} đồng được dành ${p}% để mua sách. Tiền mua sách là bao nhiêu?`, answer: money(base * p / 100),
        wrong: [money(base * (100 - p) / 100), money(base / p), money(base * p / 10), money(base * p / 100 + 5000)],
        explanation: `${p}% = ${p}/100. Tiền mua sách bằng ${base} × ${p}/100 = ${num(base * p / 100)} đồng. Đây là phần dành ra, không phải phần còn lại.`,
        hints: ['100% là toàn bộ khoản tiền ban đầu.', `Viết ${p}% thành ${p}/100.`, `Lấy ${base} nhân ${p}, rồi chia 100.`], misconception: 'Nhầm phần trăm với phần tiền còn lại hoặc chia cho p.' });
      if (mode === 1) {
        const down = [10, 20, 25][r(0, 2)], up = [5, 10, 20][r(0, 2)], reduced = base * (100 - down) / 100, answer = reduced * (100 + up) / 100;
        return question('percent', seed, { prompt: `Món hàng ${base} đồng giảm ${down}%, rồi cộng phí ${up}% tính trên giá đã giảm. Tổng phải trả là bao nhiêu?`, answer: money(answer),
          wrong: [money(base * (100 - down + up) / 100), money(reduced), money(base * (100 + up) / 100), money(answer + 10000)],
          explanation: `Sau giảm còn ${num(reduced)} đồng. Phí là ${up}% của ${num(reduced)}, nên tổng = ${num(reduced)} × ${num(1 + up / 100)} = ${num(answer)} đồng. Gốc tính phí đã thay đổi.`,
          hints: ['Tính hai bước, không trừ hai phần trăm trực tiếp.', `Giá sau giảm = ${base} × ${num(1 - down / 100)}.`, `Dùng giá ${num(reduced)} đồng làm 100% mới, rồi nhân ${num(1 + up / 100)}.`], misconception: 'Cộng trừ hai tỉ lệ dù chúng có gốc khác nhau.', difficulty: 2 });
      }
      const sale = base * (100 - p) / 100;
      return question('percent', seed, { prompt: `Sau khi giảm ${p}%, giá một món đồ còn ${num(sale)} đồng. Giá ban đầu là bao nhiêu?`, answer: money(base),
        wrong: [money(sale * (100 + p) / 100), money(sale), money(base + 10000), money(sale * 100 / p)],
        explanation: `Giá sau giảm chiếm ${100 - p}% giá gốc. Vì thế giá gốc = ${num(sale)} ÷ ${num((100 - p) / 100)} = ${num(base)} đồng.`,
        hints: [`Sau giảm còn ${100 - p}% của giá gốc.`, `Gọi giá gốc là x: ${num((100 - p) / 100)} × x = ${num(sale)}.`, `Chia ${num(sale)} cho ${num((100 - p) / 100)}.`], misconception: 'Tăng trở lại p% của giá đã giảm để tìm giá cũ.', difficulty: 2 });
    }
  },
  {
    id: 'algebra', domain: 'math', title: 'Chữ cái thay cho một số', subtitle: 'Đọc biểu thức bằng tiếng Việt',
    icon: 'variable', color: 'blue', minutes: 15, level: 1, prerequisites: ['numbers', 'fractions'],
    why: 'Một chữ có thể diễn tả cả một quy luật. Đọc được biểu thức giúp bạn hiểu công thức Toán, Lý và Hóa.',
    concepts: [
      'x là tên của một số hoặc đại lượng đang xét. 3x nghĩa là 3 × x; x² nghĩa là x × x. Hai cách viết này thường cho hai kết quả khác nhau.',
      'Tính phân phối nói a(x + b) = ax + ab. Có thể kiểm tra bằng số, hoặc hình chữ nhật được chia thành hai phần.',
      'Dấu trừ trước ngoặc tương đương nhân mọi số hạng trong ngoặc với −1. Với phương trình, chỉ biến đổi một bên thường làm mất cân bằng.'
    ],
    example: { prompt: 'Tính 3(x + 4) khi x = 2 theo hai cách.', steps: ['Thay số trước: 3 × (2 + 4) = 18.', 'Phân phối trước: 3(x + 4) = 3x + 12; thay x = 2 được 6 + 12 = 18.', 'Hai cách khớp nhau; 3(x + 4) không phải 3x + 4.'], answer: '18' },
    reflection: 'Hãy nói 2(x + 5) bằng lời rồi giải thích vì sao bằng 2x + 10. Nếu x đổi thì phần nào đổi?',
    source: { label: 'THCP, đại số từ quy tắc số học; bài học tự biên soạn', chapter: '52.11.1–52.11.5', part: 5, pages: '39–51' }, visual: 'balance',
    makeQuestion(seed = 0) {
      const r = params(seed), a = r(2, 7), b = r(2, 10), x = -r(1, 6), mode = integerSeed(seed) % 4;
      if (mode === 0) return question('algebra', seed, { prompt: `Tính ${a}x − ${b} khi x = ${x}.`, answer: String(a * x - b),
        wrong: [String(-a * x - b), String(a * x + b), String(a + x - b), String(a * x - b + 1)],
        explanation: `${a}x là ${a} × x. Thay x = ${x}: ${a} × (${x}) − ${b} = ${a * x} − ${b} = ${a * x - b}.`,
        hints: ['Thay x bằng giá trị đã cho, dùng ngoặc cho số âm.', `${a} × (${x}) = ${a * x}.`, `Từ ${a * x}, trừ thêm ${b}.`], misconception: 'Bỏ dấu âm của x hoặc hiểu ax là a + x.' });
      if (mode === 1) return question('algebra', seed, { prompt: `Khai triển ${a}(x + ${b}) được biểu thức nào?`, answer: `${a}x + ${a * b}`,
        wrong: [`${a}x + ${b}`, `x + ${a * b}`, `${a + b}x`, `${a}x − ${a * b}`],
        explanation: `Phân phối ${a} tới cả x và ${b}: ${a} × x + ${a} × ${b} = ${a}x + ${a * b}.`,
        hints: ['Số ngoài ngoặc nhân với từng số hạng bên trong.', `Có hai tích: ${a} × x và ${a} × ${b}.`, `Tích thứ hai bằng ${a * b}; giữ dấu cộng.`], misconception: 'Chỉ nhân số ngoài ngoặc với số hạng đầu.' });
      if (mode === 2) return question('algebra', seed, { prompt: `Bỏ ngoặc trong −(${a}x − ${b}) được gì?`, answer: `−${a}x + ${b}`,
        wrong: [`−${a}x − ${b}`, `${a}x − ${b}`, `${a}x + ${b}`],
        explanation: `Nhân mỗi số hạng với −1: (−1) × ${a}x + (−1) × (−${b}) = −${a}x + ${b}.`,
        hints: ['Dấu trừ trước ngoặc là nhân ngoặc với −1.', 'Cả hai số hạng đều đổi dấu.', `Số hạng ${a}x thành −${a}x; số hạng −${b} thành +${b}.`], misconception: 'Chỉ đổi dấu một số hạng trong ngoặc.' });
      return question('algebra', seed, { prompt: `Hai vế ${a}x + ${b} = ${a * 3 + b} đang bằng nhau. Thao tác nào luôn giữ phương trình tương đương?`, answer: `Trừ ${b} ở cả hai vế`,
        wrong: [`Chỉ trừ ${b} ở vế trái`, `Chỉ cộng ${b} vào vế phải`, 'Nhân cả hai vế với 0 rồi coi là cùng tập nghiệm'],
        explanation: `Trừ cùng ${b} ở cả hai vế bảo toàn nghiệm. Chỉ đổi một vế làm đổi đẳng thức. Nhân với 0 làm mất thông tin: 0 = 0 đúng với mọi x.`,
        hints: ['Hãy tưởng tượng phương trình là hai bên của một cân.', 'Cần làm cùng một phép ở hai bên và không làm mất thông tin.', `Bỏ ${b} ở hai bên để còn ${a}x = ${a * 3}.`], misconception: 'Biến đổi một vế hoặc nhân với 0 vẫn được coi là tương đương.' });
    }
  },
  {
    id: 'linear', domain: 'math', title: 'Tìm số chưa biết', subtitle: 'Giữ cân bằng, rồi thử lại',
    icon: 'equal', color: 'green', minutes: 15, level: 1, prerequisites: ['algebra'],
    why: 'Phương trình bậc nhất giúp chuyển một câu chuyện có số chưa biết thành những bước tính rõ ràng.',
    concepts: [
      'Nghiệm là giá trị thay vào khiến hai vế bằng nhau. Cộng hoặc trừ cùng một số ở hai vế giữ nguyên tập nghiệm.',
      'Nhân hoặc chia hai vế với cùng số khác 0 cũng giữ nghiệm. Với ax + b = c và a khác 0, trước hết bỏ b rồi chia cho a.',
      'Nếu hệ số x bằng 0, cần đọc phương trình còn lại: 0 = 0 đúng với mọi x; 0 = 5 không đúng với x nào. Luôn thử đáp án trong đề gốc.'
    ],
    example: { prompt: '3 hộp bút cùng giá, thêm phí 12000 đồng, tổng 87000 đồng. Một hộp bao nhiêu?',
      steps: ['Gọi giá một hộp là x đồng: 3x + 12000 = 87000.', 'Trừ 12000 hai vế: 3x = 75000. Chia cho 3: x = 25000.', 'Kiểm lại: 3 × 25000 + 12000 = 87000 đồng.'], answer: '25000 đồng' },
    reflection: 'Vì sao không lấy 87000 chia 3 rồi trừ 12000? Hãy giải thích phí được tính một lần hay ba lần.',
    source: { label: 'THCP, phương trình và phép cân bằng; bài học tự biên soạn', chapter: '53.1', part: 6, pages: '69–70' }, visual: 'balance',
    makeQuestion(seed = 0) {
      const r = params(seed), a = r(2, 8), b = r(2, 15), x = r(-8, 9), c = a * x + b, mode = integerSeed(seed) % 4;
      if (mode === 0) return question('linear', seed, { prompt: `Giải phương trình ${a}x + ${b} = ${c} trên tập số thực.`, answer: `x = ${x}`,
        wrong: [`x = ${num(c / a)}`, `x = ${num((c + b) / a)}`, `x = ${x + 1}`, `x = ${x - 1}`],
        explanation: `Trừ ${b} hai vế: ${a}x = ${c - b}. Chia hai vế cho ${a} khác 0: x = ${x}. Thử lại: ${a} × (${x}) + ${b} = ${c}.`,
        hints: [`Bỏ số cộng ${b} trước bằng cách trừ ở cả hai vế.`, `${a}x = ${c} − ${b} = ${c - b}.`, `Chia ${c - b} cho ${a}.`], misconception: 'Đổi vế nhưng không đổi dấu hoặc chia trước rồi quên xử lý số cộng.' });
      if (mode === 1) {
        const d = a + r(1, 4), e = (a - d) * x + b;
        return question('linear', seed, { prompt: `Giải ${a}x + ${b} = ${d}x ${sign(e)}.`, answer: `x = ${x}`,
          wrong: [`x = ${-x}`, `x = ${x + 1}`, `x = ${num((e + b) / (a + d))}`, `x = ${x - 1}`, `x = ${x + 2}`, `x = ${x - 2}`],
          explanation: `Trừ ${d}x và ${b} ở cả hai vế: (${a} − ${d})x = ${e} − ${b} = ${e - b}. Vì ${a - d} khác 0, x = ${e - b} ÷ (${a - d}) = ${x}.`,
          hints: ['Gom các số hạng chứa x về một vế.', `Trừ ${d}x và ${b} ở cả hai vế.`, `Bạn có ${a - d}x = ${e - b}; chia cho ${a - d}.`], misconception: 'Gom hệ số hoặc số hạng tự do sai dấu.', difficulty: 2 });
      }
      if (mode === 2) {
        const each = r(2, 12) * 1000, fee = b * 1000, total = a * each + fee;
        return question('linear', seed, { prompt: `Mua ${a} quyển sổ cùng giá và trả ${fee} đồng phí giao, tổng ${total} đồng. Mỗi quyển sổ giá bao nhiêu?`, answer: money(each),
          wrong: [money(total / a), money(each - fee), money(each + 1000), money(total + fee)],
          explanation: `Tiền riêng cho sổ là ${total} − ${fee} = ${a * each} đồng. Chia cho ${a} quyển được ${each} đồng mỗi quyển. Phí chỉ tính một lần.`,
          hints: ['Tách khoản phí khỏi tổng trước.', `Tiền ${a} quyển sổ là ${total} − ${fee}.`, `Chia ${a * each} cho ${a}.`], misconception: 'Chia tổng gồm phí cho số sổ hoặc trừ phí nhiều lần.', difficulty: 2 });
      }
      const equal = r(0, 1) === 0;
      return question('linear', seed, { prompt: `Phương trình 0 × x + ${b} = ${equal ? b : b + a} có những nghiệm thực nào?`,
        answer: equal ? 'Mọi số thực x' : 'Không có nghiệm', wrong: [equal ? 'Không có nghiệm' : 'Mọi số thực x', 'Chỉ x = 0', `Chỉ x = ${a}`],
        explanation: `Vì 0 × x luôn bằng 0, phương trình còn ${b} = ${equal ? b : b + a}. ${equal ? 'Đẳng thức này đúng với mọi số thực x.' : 'Đẳng thức này sai với mọi x, nên không có nghiệm.'} Không được chia cho 0.`,
        hints: ['Tính 0 × x trước; nó không phụ thuộc x.', `Hai vế còn ${b} và ${equal ? b : b + a}.`, 'Nếu chúng bằng nhau thì mọi x; nếu khác nhau thì không có x nào.'], misconception: 'Chia cho hệ số 0 hoặc luôn kết luận x = 0.' });
    }
  },
  {
    id: 'quadratic', domain: 'math', title: 'Bình phương và đủ nghiệm', subtitle: 'Hai, một hay không có nghiệm thực?',
    icon: 'curve', color: 'purple', minutes: 15, level: 2, prerequisites: ['linear', 'exponents'],
    why: 'Hiểu nghiệm giúp bạn tránh bỏ số âm, nhận ra khi bài toán không có nghiệm thực và kiểm tra điều kiện của mô hình.',
    concepts: [
      'Bình phương một số thực luôn không âm. √9 là căn chính bằng 3, nhưng phương trình x² = 9 có hai nghiệm x = −3 và x = 3.',
      'Một tích bằng 0 thì ít nhất một nhân tử bằng 0. (x − 2)(x + 5) = 0 có nghiệm 2 và −5.',
      'Phương trình bậc hai ax² + bx + c = 0 cần a khác 0. Biệt thức b² − 4ac dương, bằng 0, âm lần lượt cho hai, một, không có nghiệm thực.'
    ],
    example: { prompt: 'Giải (x − 4)² = 9 trên tập số thực.', steps: ['x − 4 có thể là 3 hoặc −3, vì cả hai bình phương đều bằng 9.', 'x = 7 hoặc x = 1.', 'Thử lại: (7 − 4)² = 9 và (1 − 4)² = 9.'], answer: 'x = 1 hoặc x = 7' },
    reflection: 'Vì sao x² = 16 có nghiệm −4, còn cạnh hình vuông diện tích 16 cm² chỉ dài 4 cm?',
    source: { label: 'THCP, phương trình bậc hai; bài học tự biên soạn', chapter: '53.2', part: 6, pages: '71–74' }, visual: 'graph',
    makeQuestion(seed = 0) {
      const r = params(seed), k = r(2, 10), shift = r(-5, 5), mode = integerSeed(seed) % 4;
      if (mode === 0) return question('quadratic', seed, { prompt: `Giải x² = ${k * k} trên tập số thực. Chọn đầy đủ nghiệm.`, answer: roots(-k, k),
        wrong: [`Chỉ x = ${k}`, `Chỉ x = ${-k}`, roots(-k * k, k * k), 'Không có nghiệm thực'],
        explanation: `Cả ${k}² và (${ -k})² đều bằng ${k * k}. Vậy hai nghiệm là −${k} và ${k}; căn chính √${k * k} = ${k} không phải toàn bộ nghiệm phương trình.`,
        hints: ['Tìm cả số dương và số âm có cùng bình phương.', `${k} × ${k} = ${k * k}.`, `(${ -k}) × (${ -k}) cũng bằng ${k * k}; giữ cả hai nghiệm.`], misconception: 'Chỉ lấy căn chính dương và bỏ nghiệm âm.' });
      if (mode === 1) {
        const other = shift + r(1, 7);
        return question('quadratic', seed, { prompt: `Giải ${factor(shift)}${factor(other)} = 0 trên tập số thực.`, answer: roots(shift, other),
          wrong: [roots(-shift, -other), `Chỉ x = ${shift}`, `Chỉ x = ${other}`, roots(shift + 1, other + 1)],
          explanation: `Một tích bằng 0 khi ít nhất một nhân tử bằng 0: ${factor(shift)} = 0 cho x = ${shift}; ${factor(other)} = 0 cho x = ${other}. Hai nghiệm này khác nhau.`,
          hints: ['Một tích bằng 0 không đòi cả hai nhân tử cùng bằng 0.', `Cho nhân tử thứ nhất bằng 0 để tìm một nghiệm.`, `Làm tương tự với nhân tử thứ hai; kết hợp bằng “hoặc”.`], misconception: 'Đổi dấu nghiệm sai hoặc chỉ xét một nhân tử.', difficulty: 2 });
      }
      if (mode === 2) return question('quadratic', seed, { prompt: `Phương trình x² + ${k} = 0 có những nghiệm thực nào?`, answer: 'Không có nghiệm thực',
        wrong: [roots(-k, k), 'Chỉ x = 0', `Chỉ x = ${-k}`],
        explanation: `Với mọi số thực x, x² ≥ 0 nên x² + ${k} ≥ ${k} > 0. Nó không thể bằng 0. Bài chỉ hỏi số thực.`,
        hints: ['Bình phương số thực có thể âm không?', `Phương trình yêu cầu x² = −${k}.`, `Số −${k} âm, trong khi x² luôn không âm.`], misconception: 'Cho căn bậc hai của số âm một nghiệm thực.' });
      return question('quadratic', seed, { prompt: `Giải ${factor(shift)}² = 0 trên tập số thực.`, answer: `Chỉ x = ${shift}`,
        wrong: [roots(shift - k, shift + k), `Chỉ x = ${shift + 1}`, 'Không có nghiệm thực', 'Mọi số thực x'],
        explanation: `Bình phương bằng 0 chỉ khi biểu thức bên trong bằng 0. Từ ${factor(shift)} = 0 suy ra x = ${shift}. Đây là một nghiệm phân biệt, dù gọi là nghiệm kép.`,
        hints: ['Số nào bình phương bằng 0?', 'Biểu thức trong ngoặc phải bằng 0.', `Giải ${factor(shift)} = 0.`], misconception: 'Mặc định mọi phương trình bậc hai luôn có hai nghiệm phân biệt.' });
    }
  },
  {
    id: 'functions', domain: 'math', title: 'Hàm số: từ đầu vào đến đồ thị', subtitle: 'Một quy tắc, nhiều cách nhìn',
    icon: 'chart', color: 'blue', minutes: 15, level: 1, prerequisites: ['linear'],
    why: 'Bảng, công thức và đồ thị diễn tả cùng một mối liên hệ. Đây là cầu nối để đọc chuyển động và dữ liệu thực nghiệm.',
    concepts: [
      'Một hàm gán cho mỗi đầu vào hợp lệ đúng một đầu ra. f(x) là đầu ra khi đưa x vào quy tắc; f(3) không có nghĩa là f nhân 3.',
      'Với y = mx + b, khi x tăng 1 thì y thay đổi m; b là đầu ra lúc x = 0. Điểm (x, y) giúp vẽ mối liên hệ trên hai trục.',
      'Độ dốc = thay đổi y chia thay đổi x, với thay đổi x khác 0. Mọi công thức có miền hợp lệ: không được chia cho 0.'
    ],
    example: { prompt: 'C(x) = 15000 + 4000x là tiền thuê xe trong x giờ. C(3) và C(3) − C(2) là bao nhiêu?',
      steps: ['C(3) = 15000 + 4000 × 3 = 27000 đồng.', 'C(2) = 23000 đồng; chênh lệch là 4000 đồng.', 'Phí mở khóa không đổi; mỗi giờ thêm làm tiền tăng 4000 đồng.'], answer: '27000 đồng; chênh 4000 đồng' },
    reflection: 'Nếu tăng phí ban đầu nhưng giữ cước mỗi giờ, đồ thị thay đổi ra sao? Cái gì được giữ nguyên?',
    source: { label: 'THCP, tọa độ và độ dốc; bài học tự biên soạn', chapter: '57.1–57.3', part: 8, pages: '38–42' }, visual: 'graph',
    makeQuestion(seed = 0) {
      const r = params(seed), m = r(1, 6) * (r(0, 1) ? 1 : -1), b = r(-7, 9), x = r(2, 8), mode = integerSeed(seed) % 4;
      if (mode === 0) return question('functions', seed, { prompt: `Cho f(x) = ${m}x ${sign(b)}. Tính f(${x}).`, answer: String(m * x + b),
        wrong: [String(m * x - b), String(m + x + b), String(m * x + b + 1), String(m * x + b - 1), String(m * x + b + 2), String(m * x + b - 2)],
        explanation: `Thay đầu vào x bằng ${x}: f(${x}) = ${m} × ${x} ${sign(b)} = ${m * x + b}.`,
        hints: ['f(x) là quy tắc tính đầu ra.', `Đầu vào là ${x}; thay mọi x trong công thức bằng ${x}.`, `Nhân ${m} với ${x} trước, rồi xử lý số ${b}.`], misconception: 'Nhầm f(x) với f × x hoặc thay nhầm đầu vào.' });
      if (mode === 1) return question('functions', seed, { prompt: 'Bảng sau thuộc một hàm bậc nhất. Khi x = 3 thì y bằng bao nhiêu?', answer: String(3 * m + b),
        wrong: [String(2 * m + b), String(4 * m + b), String(3 * m + b + 1), String(3 * m + b - 1), String(3 * m + b + 2), String(3 * m + b - 2)],
        table: { headers: ['x', 'y'], rows: [['0', String(b)], ['2', String(2 * m + b)], ['4', String(4 * m + b)]] },
        explanation: `Khi x tăng 2, y thay đổi ${2 * m}; mỗi đơn vị x làm y thay đổi ${m}. Từ x = 2 đến x = 3, y = ${2 * m + b} + (${m}) = ${3 * m + b}. Đề đã cho hàm bậc nhất.`,
        hints: ['Hàm bậc nhất thay đổi đều theo x.', 'Từ x = 2 tới 3 là nửa bước từ x = 2 tới 4.', `Lấy trung bình hai giá trị y tại x = 2 và x = 4.`], misconception: 'Đọc sai cột hoặc coi bảng tăng đều dù chưa có điều kiện hàm bậc nhất.', difficulty: 2 });
      if (mode === 2) {
        const start = r(-4, 4), delta = r(2, 6), y1 = m * start + b, y2 = m * (start + delta) + b;
        return question('functions', seed, { prompt: `Đường thẳng đi qua A(${start}; ${y1}) và B(${start + delta}; ${y2}). Độ dốc Δy/Δx là bao nhiêu?`, answer: String(m),
          wrong: [String(y2 - y1), frac(1, m), String(-m), String(m + 1), String(m + 2), String(m - 2)],
          explanation: `Δy = ${y2} − (${y1}) = ${y2 - y1}; Δx = ${start + delta} − (${start}) = ${delta} khác 0. Độ dốc = ${y2 - y1}/${delta} = ${m}.`,
          hints: ['Lấy thay đổi theo chiều đứng chia thay đổi theo chiều ngang.', `Tử số là ${y2 - y1}; mẫu số là ${delta}.`, `Tính ${y2 - y1} ÷ ${delta}.`], misconception: 'Đảo Δx/Δy hoặc chỉ lấy độ tăng y.', difficulty: 2 });
      }
      const excluded = r(1, 9);
      return question('functions', seed, { prompt: `Với f(x) = 1/(x − ${excluded}), đầu vào nào sau đây không hợp lệ trên tập số thực?`, answer: `x = ${excluded}`,
        wrong: [`x = ${excluded - 1}`, `x = ${excluded + 1}`, `x = ${excluded + 2}`],
        explanation: `Tại x = ${excluded}, mẫu số x − ${excluded} bằng 0. Không định nghĩa phép chia cho 0, nên phải loại đầu vào này.`,
        hints: ['Xem điều kiện của mẫu số.', `Không được có x − ${excluded} = 0.`, `Giá trị nào thay vào làm ${excluded} − ${excluded} = 0?`], misconception: 'Quên miền xác định hoặc cho rằng chia cho 0 bằng 0.' });
    }
  },
  {
    id: 'geometry', domain: 'math', title: 'Đo hình, hiểu đơn vị', subtitle: 'Diện tích, chu vi và tam giác vuông',
    icon: 'shapes', color: 'peach', minutes: 15, level: 1, prerequisites: ['fractions'],
    why: 'Đếm ô và nhìn điều kiện giúp công thức hình học có nghĩa, rồi áp dụng đúng trong mô hình khoa học.',
    concepts: [
      'Chu vi đo đường biên, dùng cm hoặc m. Diện tích đo phần mặt được phủ, dùng cm² hoặc m²; thể tích dùng đơn vị lập phương.',
      'Diện tích tam giác bằng đáy × chiều cao vuông góc / 2. Chiều cao có thể nằm ngoài hình; một cạnh xiên không tự động là chiều cao.',
      'Phóng đồng đều các độ dài k lần làm diện tích tăng k² lần. Trong tam giác vuông, cạnh huyền đối diện góc vuông và c² = a² + b².'
    ],
    example: { prompt: 'Tam giác có đáy 8 cm, chiều cao vuông góc 5 cm. Phóng mọi độ dài lên 3 lần thì diện tích mới bao nhiêu?',
      steps: ['Ban đầu: 8 × 5 / 2 = 20 cm².', 'Đáy mới 24 cm; chiều cao mới 15 cm.', 'Diện tích mới 24 × 15 / 2 = 180 cm², tức 9 lần diện tích cũ.'], answer: '180 cm²' },
    reflection: 'Nếu chỉ trượt đỉnh tam giác sang ngang mà giữ đáy và chiều cao, diện tích có đổi không? Điều này khác phóng to ở đâu?',
    source: { label: 'THCP, đo diện tích và biến đổi kích thước; bài học tự biên soạn', chapter: '54.1–54.3, 54.9; 55.2.5', part: 7, pages: '18–23, 33, 61–62' }, visual: 'area',
    makeQuestion(seed = 0) {
      const r = params(seed), a = 2 * r(2, 9), b = r(3, 12), mode = integerSeed(seed) % 5;
      if (mode === 0) return question('geometry', seed, { prompt: `Tam giác có đáy ${a} cm và chiều cao vuông góc với đáy ${b} cm. Diện tích là bao nhiêu?`, answer: `${a * b / 2} cm²`,
        wrong: [`${a * b} cm²`, `${a + b} cm²`, `${a * b / 2 + 1} cm²`, `${2 * (a + b)} cm²`, `${a * b / 2 + 2} cm²`, `${a * b / 2 + 3} cm²`],
        explanation: `Ghép hai tam giác bằng nhau thành hình bình hành: diện tích một tam giác = ${a} × ${b} / 2 = ${a * b / 2} cm². Chiều cao đã cho là vuông góc.`,
        hints: ['Diện tích tam giác bằng nửa tích đáy và chiều cao.', `Tính ${a} × ${b}.`, `Chia ${a * b} cho 2 và dùng cm².`], misconception: 'Quên chia 2 hoặc nhầm diện tích với chu vi.' });
      if (mode === 1) return question('geometry', seed, { prompt: `Hình chữ nhật dài ${a} cm và rộng ${b} cm. Chu vi là bao nhiêu?`, answer: `${2 * (a + b)} cm`,
        wrong: [`${a + b} cm`, `${a * b} cm`, `${2 * (a + b) + 1} cm`, `${2 * a + b} cm`],
        explanation: `Đường biên có hai cạnh dài và hai cạnh rộng. Chu vi = 2 × (${a} + ${b}) = ${2 * (a + b)} cm. Đây là độ dài nên dùng cm, không dùng cm².`,
        hints: ['Chu vi là tổng độ dài các cạnh quanh biên.', 'Có hai cạnh dài và hai cạnh rộng.', `Tính 2 × (${a} + ${b}).`], misconception: 'Lấy dài nhân rộng khi đề hỏi chu vi.' });
      if (mode === 2) {
        const area = r(4, 20), scale = r(2, 5);
        return question('geometry', seed, { prompt: `Một hình có diện tích ${area} cm². Phóng đồng đều mọi độ dài ${scale} lần thì diện tích mới là bao nhiêu?`, answer: `${area * scale * scale} cm²`,
          wrong: [`${area * scale} cm²`, `${area * scale ** 3} cm²`, `${area + scale} cm²`, `${area * scale * scale + 1} cm²`],
          explanation: `Mỗi chiều dài tăng ${scale} lần nên diện tích tăng ${scale}² = ${scale * scale} lần. Diện tích mới = ${area} × ${scale * scale} = ${area * scale * scale} cm².`,
          hints: ['Diện tích phụ thuộc hai chiều độ dài.', `Hệ số diện tích là ${scale} × ${scale}.`, `Nhân diện tích cũ ${area} với ${scale * scale}.`], misconception: 'Dùng hệ số độ dài k hoặc thể tích k³ cho diện tích.', difficulty: 2 });
      }
      if (mode === 3) {
        const k = r(1, 6), x = 3 * k, y = 4 * k, c = 5 * k;
        return question('geometry', seed, { prompt: `Tam giác vuông có hai cạnh góc vuông ${x} cm và ${y} cm. Cạnh huyền dài bao nhiêu?`, answer: `${c} cm`,
          wrong: [`${x + y} cm`, `${y - x} cm`, `${c * c} cm`, `${c + 1} cm`],
          explanation: `Pythagoras áp dụng vì tam giác vuông: c² = ${x}² + ${y}² = ${c * c}. Cạnh là độ dài dương nên c = ${c} cm.`,
          hints: ['Xác nhận hai cạnh đã cho đều là cạnh góc vuông.', `Bình phương cạnh huyền bằng ${x * x} + ${y * y}.`, `Lấy căn chính của ${c * c}; cạnh không âm.`], misconception: 'Cộng trực tiếp hai cạnh hoặc quên lấy căn.', difficulty: 2 });
      }
      const radius = r(2, 10);
      return question('geometry', seed, { prompt: `Hình tròn có đường kính ${2 * radius} cm. Diện tích chính xác là bao nhiêu?`, answer: `${radius * radius}π cm²`,
        wrong: [`${4 * radius * radius}π cm²`, `${2 * radius}π cm²`, `${radius * radius + 1}π cm²`, `${radius}π cm²`],
        explanation: `Bán kính bằng nửa đường kính: r = ${radius} cm. Diện tích = πr² = ${radius * radius}π cm². Đề hỏi chính xác nên giữ π.`,
        hints: ['Công thức dùng bán kính, không phải đường kính.', `Bán kính là ${2 * radius} ÷ 2 = ${radius} cm.`, `Bình phương ${radius} rồi nhân π.`], misconception: 'Dùng đường kính thay bán kính hoặc nhầm chu vi với diện tích.' });
    }
  },
  {
    id: 'trigonometry', domain: 'math', title: 'Tỉ số trong tam giác vuông', subtitle: 'Chọn góc trước, gọi đúng tên cạnh',
    icon: 'triangle', color: 'purple', minutes: 15, level: 2, prerequisites: ['geometry', 'fractions'],
    why: 'Lượng giác nối góc với tỉ lệ chiều dài, hữu ích khi đo gián tiếp, đọc chuyển động và phân tích lực.',
    concepts: [
      'Với một góc nhọn θ của tam giác vuông, cạnh đối nằm đối diện góc θ; cạnh kề nằm cạnh θ nhưng không phải cạnh huyền. Đổi góc đang xét thì tên đối/kề có thể đổi.',
      'sin θ = đối/huyền; cos θ = kề/huyền; tan θ = đối/kề. Các tỉ số không đổi khi phóng đồng đều hình.',
      'Cạnh huyền lớn nhất nên sin và cos của góc nhọn nằm giữa 0 và 1. Một góc cũng có thể đo bằng radian: nửa vòng là π rad = 180°.'
    ],
    example: { prompt: 'Tam giác vuông có cạnh đối góc θ là 5 cm, cạnh kề 12 cm, cạnh huyền 13 cm. sin θ bằng bao nhiêu?',
      steps: ['Chọn đúng góc θ rồi xác định cạnh đối và cạnh huyền.', 'sin θ = đối / huyền = 5/13.', 'Độ dài đã có cùng đơn vị nên tỉ số không có đơn vị. 5/13 nằm giữa 0 và 1.'], answer: '5/13' },
    reflection: 'Nếu mọi cạnh tăng hai lần thì sin θ có đổi không? Hãy giải thích bằng một phân số, không chỉ nhớ công thức.',
    source: { label: 'THCP, tỉ số lượng giác từ đồng dạng; bài học tự biên soạn', chapter: '58.1–58.2', part: 9, pages: '37–40' }, visual: 'area',
    makeQuestion(seed = 0) {
      const r = params(seed), triples = [[3, 4, 5], [5, 12, 13], [8, 15, 17], [7, 24, 25]], [opp, adj, hyp] = triples[r(0, 3)], k = r(1, 5), mode = integerSeed(seed) % 4;
      if (mode < 3) {
        const which = ['sin', 'cos', 'tan'][mode], a = [opp, adj, opp][mode], b = [hyp, hyp, adj][mode];
        return question('trigonometry', seed, { prompt: `Tam giác vuông: cạnh đối góc θ là ${opp * k} cm, cạnh kề θ là ${adj * k} cm, cạnh huyền là ${hyp * k} cm. ${which} θ bằng bao nhiêu?`, answer: frac(a, b),
          wrong: [frac(b, a), frac(opp, hyp), frac(adj, hyp), frac(opp, adj), frac(adj, opp), frac(opp + adj, hyp)],
          explanation: `${which} θ = ${['đối/huyền', 'kề/huyền', 'đối/kề'][mode]} = ${a * k}/${b * k} = ${frac(a, b)}. Cả hai độ dài cùng đơn vị nên tỉ số không có đơn vị.`,
          hints: ['Cạnh đối và cạnh kề được gọi theo góc θ, không theo hướng vẽ.', `Dùng ${which} θ = ${['đối/huyền', 'kề/huyền', 'đối/kề'][mode]}.`, `Lập ${a * k}/${b * k} rồi chia cả tử và mẫu cho ước chung.`], misconception: 'Nhầm cạnh đối với cạnh kề, hoặc đảo tỉ số.', difficulty: 2 });
      }
      return question('trigonometry', seed, { prompt: `Tam giác vuông có sin θ = ${opp}/${hyp} và cạnh huyền ${hyp * k} cm. Cạnh đối θ dài bao nhiêu?`, answer: `${opp * k} cm`,
        wrong: [`${adj * k} cm`, `${hyp * k} cm`, `${opp * k + 1} cm`, `${num(hyp * k * hyp / opp)} cm`],
        explanation: `sin θ = đối/huyền, nên đối = huyền × sin θ = ${hyp * k} × ${opp}/${hyp} = ${opp * k} cm. Kết quả nhỏ hơn cạnh huyền.`,
        hints: ['Viết sin θ thành cạnh đối chia cạnh huyền.', `Nhân hai vế với ${hyp * k} cm.`, `Cạnh đối = ${hyp * k} × ${opp}/${hyp}.`], misconception: 'Chia cạnh huyền cho sin thay vì nhân.', difficulty: 2 });
    }
  },
  {
    id: 'exponents', domain: 'math', title: 'Mũ và phép làm ngược', subtitle: 'Nhân lặp, nghịch đảo và câu hỏi tìm số mũ',
    icon: 'power', color: 'blue', minutes: 15, level: 1, prerequisites: ['algebra'],
    why: 'Số mũ diễn tả tăng trưởng, diện tích, số rất lớn và rất nhỏ. Logarit là cách hỏi ngược khi số mũ chưa biết.',
    concepts: [
      'Với n nguyên dương, aⁿ là tích của n số a. Vì nhân lặp, aᵐ × aⁿ = aᵐ⁺ⁿ. Không cộng hai cơ số.',
      'Với a khác 0, a⁰ = 1 và a⁻ⁿ = 1/aⁿ. Mũ âm nói về nghịch đảo, không phải tự động biến giá trị thành số âm.',
      'logₐ b là số mũ x sao cho aˣ = b, với a > 0, a khác 1 và b > 0. Bình phương và căn chính chỉ hoàn tác nhau trên miền không âm: √(x²) = |x|.'
    ],
    example: { prompt: 'Tính 2³ × 2² và 2⁻².', steps: ['2³ × 2² có tổng cộng 5 thừa số 2: bằng 2⁵ = 32.', '2⁻² = 1/2² = 1/4.', 'Nếu 2ˣ = 32 thì x = 5; đó cũng là log₂32.'], answer: '32 và 1/4' },
    reflection: 'Vì sao 3⁻² không phải −9? Hãy nhân 3² với 3⁻² và xem kết quả cần bằng bao nhiêu.',
    source: { label: 'THCP, mũ và logarit; bài học tự biên soạn', chapter: '58.16.1–58.16.3; 58.17', part: 10, pages: '9–12, 16–18' }, visual: 'graph',
    makeQuestion(seed = 0) {
      const r = params(seed), base = r(2, 5), a = r(1, 4), b = r(1, 4), mode = integerSeed(seed) % 4;
      if (mode === 0) return question('exponents', seed, { prompt: `Tính ${base}^${a} × ${base}^${b}. Dấu ^ chỉ lũy thừa.`, answer: String(base ** (a + b)),
        wrong: [String(base ** a + base ** b), String(base ** (a * b)), String(base ** (a + b + 1)), String(base ** (a + b) + 1)],
        explanation: `Cùng cơ số nên cộng số mũ: ${base}^${a} × ${base}^${b} = ${base}^${a + b} = ${base ** (a + b)}.`,
        hints: ['Viết hai lũy thừa thành những thừa số giống nhau.', `Có tất cả ${a} + ${b} thừa số ${base}.`, `Tính ${base}^${a + b}.`], misconception: 'Nhân hai số mũ hoặc cộng hai giá trị thay vì nhân.' });
      if (mode === 1) return question('exponents', seed, { prompt: `Tính ${base}^(−${a}) với cơ số ${base} khác 0.`, answer: frac(1, base ** a),
        wrong: [String(-(base ** a)), String(base ** a), frac(-1, base ** a), frac(1, base ** a + 1)],
        explanation: `Mũ âm lấy nghịch đảo: ${base}^(−${a}) = 1/${base}^${a} = ${frac(1, base ** a)}. Giá trị vẫn dương vì cơ số dương.`,
        hints: ['Dấu âm nằm ở số mũ, không nằm trước cơ số.', `Dùng a^(−n) = 1/a^n với a khác 0.`, `Mẫu số là ${base}^${a} = ${base ** a}.`], misconception: 'Đọc mũ âm thành dấu trừ ở trước giá trị.' });
      if (mode === 2) return question('exponents', seed, { prompt: `Tìm số thực x biết ${base}^x = ${base ** (a + 1)}.`, answer: String(a + 1),
        wrong: [String(base ** (a + 1)), String(base * (a + 1)), String(a + 2), String(a)],
        explanation: `${base ** (a + 1)} = ${base}^${a + 1}. Với cơ số ${base} > 1, cùng giá trị lũy thừa thì cùng số mũ; x = ${a + 1}.`,
        hints: ['Cần tìm số mũ, không phải nhân x với cơ số.', `Thử dãy ${base}^1, ${base}^2, ${base}^3…`, `Giá trị bên phải bằng ${base}^${a + 1}.`], misconception: 'Nhầm lũy thừa với phép nhân cơ số và số mũ.', difficulty: 2 });
      const value = r(-12, -2);
      return question('exponents', seed, { prompt: `Tính căn chính √((${value})²) trên tập số thực.`, answer: String(-value),
        wrong: [String(value), String(value * value), String(-value + 1)],
        explanation: `√(x²) = |x|. Bình phương ${value} được ${value * value}; căn chính của ${value * value} là ${-value}, không âm.`,
        hints: ['Căn chính bậc hai luôn không âm.', `(${value})² = ${value * value}.`, `Tìm số không âm có bình phương bằng ${value * value}.`], misconception: 'Cho căn chính tự động trả lại số âm ban đầu.' });
    }
  },
  {
    id: 'probability', domain: 'math', title: 'Đếm trước khi tính xác suất', subtitle: 'Mẫu số phải là đúng nhóm đang xét',
    icon: 'dice', color: 'peach', minutes: 15, level: 1, prerequisites: ['fractions', 'percent'],
    why: 'Xác suất giúp đọc dữ liệu có bất định. Quan trọng nhất là xác định điều gì có thể xảy ra và điều kiện nào đã biết.',
    concepts: [
      'Khi các kết quả cơ bản đồng khả năng, xác suất bằng số kết quả thuận lợi chia tổng số kết quả. Cần nói rõ phép thử và giả thiết đồng khả năng.',
      'Gieo hai xúc xắc sáu mặt cân đối, độc lập và phân biệt: có 36 cặp kết quả đồng khả năng. Tổng 2 và tổng 7 không đồng khả năng vì có số cặp tạo thành khác nhau.',
      'Biết một điều kiện thì chỉ xét nhóm thỏa điều kiện đó. Rút không hoàn lại làm tổng số vật và số vật từng màu thay đổi ở lần sau.'
    ],
    example: { prompt: 'Túi có 4 thẻ xanh và 3 thẻ đỏ, các thẻ được trộn đều. Rút hai thẻ không hoàn lại. Xác suất cả hai xanh?',
      steps: ['Lần đầu có 4 thẻ xanh trong 7 thẻ: xác suất 4/7.', 'Nếu lần đầu xanh, còn 3 xanh trong 6 thẻ: xác suất tiếp là 3/6.', 'Hai lần cùng xanh: 4/7 × 3/6 = 2/7.'], answer: '2/7' },
    reflection: 'Nếu thẻ đầu được đặt lại rồi trộn đều, vì sao mẫu số và tử số của lần thứ hai khác ví dụ?',
    source: { label: 'THCP, không gian mẫu và điều kiện; bài học tự biên soạn', chapter: '74.1–74.3; 74.6.1', part: 18, pages: '25–32, 50–52' }, visual: 'probability',
    makeQuestion(seed = 0) {
      const r = params(seed), red = r(2, 9), blue = r(2, 8), total = red + blue, mode = integerSeed(seed) % 4;
      if (mode === 0) return question('probability', seed, { prompt: `Túi có ${red} thẻ đỏ và ${blue} thẻ xanh. Các thẻ đồng khả năng được rút. Rút 1 thẻ, xác suất đỏ là bao nhiêu?`, answer: frac(red, total),
        wrong: [frac(blue, total), frac(red, blue), frac(red + 1, total), frac(red, total + 1)],
        explanation: `Có ${total} thẻ trong nhóm đang xét và ${red} thẻ đỏ thuận lợi. Xác suất = ${red}/${total} = ${frac(red, total)}. Các thẻ được coi là đồng khả năng.`,
        hints: ['Mẫu số là tổng số thẻ, không chỉ số thẻ xanh.', `Tổng thẻ = ${red} + ${blue} = ${total}.`, `Lấy ${red} kết quả thuận lợi chia ${total}.`], misconception: 'Lấy số vật màu kia làm mẫu hoặc nhầm phần bù.' });
      if (mode === 1) return question('probability', seed, { prompt: `Túi có ${red} thẻ đỏ, ${blue} thẻ xanh. Rút ngẫu nhiên 2 thẻ liên tiếp, không đặt lại. Xác suất cả hai đỏ là bao nhiêu?`, answer: frac(red * (red - 1), total * (total - 1)),
        wrong: [frac(red * red, total * total), frac(red * (red - 1), total * total), frac(red, total), frac(red + 1, total)],
        explanation: `Lần đầu đỏ: ${red}/${total}. Khi đã rút một thẻ đỏ, còn ${red - 1} đỏ trong ${total - 1} thẻ. Xác suất cùng đỏ = ${red}/${total} × ${red - 1}/${total - 1} = ${frac(red * (red - 1), total * (total - 1))}.`,
        hints: ['Không đặt lại nên túi thay đổi sau lần đầu.', `Nếu lần đầu đỏ, còn ${red - 1} đỏ trong ${total - 1} thẻ.`, `Nhân ${red}/${total} với ${red - 1}/${total - 1}, rồi rút gọn.`], misconception: 'Coi hai lần là độc lập như trường hợp có hoàn lại.', difficulty: 2 });
      if (mode === 2) {
        const sum = r(2, 12), count = 6 - Math.abs(7 - sum);
        return question('probability', seed, { prompt: `Gieo hai xúc xắc cân đối, độc lập, phân biệt màu. Xác suất tổng số chấm bằng ${sum} là bao nhiêu?`, answer: frac(count, 36),
          wrong: [frac(1, 11), frac(count, 12), frac(count + 1, 36), frac(count, 6), frac(count + 2, 36)],
          explanation: `Có 6 × 6 = 36 cặp kết quả đồng khả năng. Liệt kê theo số chấm xúc xắc đầu và số còn thiếu trên xúc xắc sau được ${count} cặp có tổng ${sum}. Xác suất = ${count}/36 = ${frac(count, 36)}.`,
          hints: ['Không coi 11 tổng từ 2 đến 12 là đồng khả năng.', `Tổng số cặp có thứ tự là 36; liệt kê (a; ${sum} − a) với mỗi mặt từ 1 đến 6.`, `Có ${count} cặp hợp lệ; chia ${count} cho 36.`], misconception: 'Coi các tổng là đồng khả năng hoặc gộp hai cặp khác thứ tự.', difficulty: 2 });
      }
      const other = r(2, 8);
      return question('probability', seed, { prompt: 'Chọn ngẫu nhiên một người trong nhóm đã mang ô. Xác suất người đó đi xe buýt là bao nhiêu?', answer: frac(red, red + blue),
        table: { headers: ['Phương tiện', 'Mang ô', 'Không mang ô'], rows: [['Xe buýt', String(red), String(other)], ['Xe đạp', String(blue), String(other + 2)]] },
        wrong: [frac(red, red + blue + 2 * other + 2), frac(red, red + other), frac(blue, red + blue), frac(red + 1, red + blue), frac(red, red + blue + 1), frac(red + 1, red + blue + 1)],
        explanation: `Điều kiện đã biết là “mang ô”, nên chỉ xét cột Mang ô: tổng ${red + blue} người, trong đó ${red} đi xe buýt. Xác suất = ${frac(red, red + blue)}.`,
        hints: ['Khoanh đúng nhóm đã biết: những người mang ô.', `Mẫu số gồm ${red} + ${blue} người trong cột Mang ô.`, `Tử số là ${red} người vừa mang ô vừa đi xe buýt.`], misconception: 'Dùng tổng toàn bảng hoặc nhầm xác suất điều kiện ngược.', difficulty: 2 });
    }
  },
  {
    id: 'statistics', domain: 'math', title: 'Đọc một nhóm số liệu', subtitle: 'Trung bình chưa kể hết câu chuyện',
    icon: 'bars', color: 'green', minutes: 15, level: 1, prerequisites: ['fractions'],
    why: 'Dữ liệu khoa học cần đọc đúng cách gom nhóm, đơn vị, trung tâm và độ phân tán; một con số tóm tắt có giới hạn.',
    concepts: [
      'Trung bình cộng bằng tổng chia số quan sát. Với bảng tần số, mỗi giá trị phải được tính đúng số lần xuất hiện; không lấy trung bình các hàng một cách máy móc.',
      'Trung vị là giá trị giữa sau khi sắp tăng dần; với số lượng chẵn, lấy trung bình hai giá trị giữa. Khoảng biến thiên bằng giá trị lớn nhất trừ nhỏ nhất.',
      'Trung bình có thể bị kéo bởi một giá trị rất lớn. Hai nhóm cùng trung bình vẫn có thể phân tán khác nhau; kết quả từ một nhóm khảo sát không tự đại diện mọi người.'
    ],
    example: { prompt: 'Số phút làm bài của 5 người là 8, 9, 10, 11, 22. Trung bình và trung vị?',
      steps: ['Tổng = 60 phút; trung bình = 60/5 = 12 phút.', 'Dãy đã tăng dần; số thứ 3 là 10 nên trung vị 10 phút.', 'Người làm 22 phút kéo trung bình lên. Cần xem cả nhóm số, không chỉ trung bình.'], answer: 'Trung bình 12 phút; trung vị 10 phút' },
    reflection: 'Hai nhóm 5, 5, 5 và 1, 5, 9 cùng trung bình 5. Bạn cần thông tin gì để mô tả chúng khác nhau?',
    source: { label: 'THCP, kỳ vọng và phân tán; phần trung vị tự bổ sung ở mức nền tảng', chapter: '74, kỳ vọng và phương sai', part: 19, pages: '29–31, 35–39' }, visual: 'graph',
    makeQuestion(seed = 0) {
      const r = params(seed), a = r(2, 18), mode = integerSeed(seed) % 4;
      if (mode === 0) {
        const data = [a, a + 1, a + 2, a + 3, a + 9];
        return question('statistics', seed, { prompt: `Số phút làm bài của 5 người: ${data.join(', ')}. Trung bình cộng bằng bao nhiêu?`, answer: `${a + 3} phút`,
          wrong: [`${a + 2} phút`, `${a + 9} phút`, `${5 * a + 15} phút`, `${a + 4} phút`],
          explanation: `Tổng = ${5 * a + 15} phút, có 5 quan sát. Trung bình = ${5 * a + 15}/5 = ${a + 3} phút. Trung vị ${a + 2} là khái niệm khác.`,
          hints: ['Trung bình = tổng chia số lượng.', `Cộng 5 số được ${5 * a + 15}.`, `Chia ${5 * a + 15} cho 5.`], misconception: 'Lấy giá trị giữa hoặc tổng mà chưa chia số quan sát.' });
      }
      if (mode === 1) return question('statistics', seed, { prompt: `Dữ liệu là ${a + 10}, ${a}, ${a + 2}, ${a + 1}, ${a + 3}. Trung vị bằng bao nhiêu?`, answer: String(a + 2),
        wrong: [String(a), String(a + 10), frac(5 * a + 16, 5), String(a + 1)],
        explanation: `Sắp tăng dần: ${a}, ${a + 1}, ${a + 2}, ${a + 3}, ${a + 10}. Có 5 số nên giá trị ở vị trí thứ 3 là trung vị: ${a + 2}.`,
        hints: ['Sắp dữ liệu trước khi chọn số ở giữa.', `Dãy sau sắp xếp bắt đầu ${a}, ${a + 1}, ${a + 2}…`, 'Có 5 số nên lấy số thứ 3, không lấy trung bình của cả dãy.'], misconception: 'Lấy số ở giữa dãy chưa sắp hoặc nhầm trung vị với trung bình.' });
      if (mode === 2) {
        const spread = r(5, 16);
        return question('statistics', seed, { prompt: `Nhiệt độ đo được (°C): ${a + 2}, ${a + spread}, ${a}, ${a + 3}. Khoảng biến thiên bằng bao nhiêu?`, answer: `${spread} °C`,
          wrong: [`${a + spread} °C`, `${a} °C`, `${spread + 1} °C`, `${2 * a + spread} °C`],
          explanation: `Lớn nhất ${a + spread} °C; nhỏ nhất ${a} °C. Khoảng biến thiên = ${a + spread} − ${a} = ${spread} °C. Đây là một cách đo mức phân tán.`,
          hints: ['Tìm giá trị lớn nhất và nhỏ nhất.', `Lớn nhất ${a + spread}, nhỏ nhất ${a}.`, `Lấy ${a + spread} trừ ${a}.`], misconception: 'Dùng riêng giá trị lớn nhất hoặc lấy tổng hai đầu.' });
      }
      const n1 = r(2, 6), n2 = r(2, 6), high = a + r(2, 7), sum = a * n1 + high * n2, count = n1 + n2;
      return question('statistics', seed, { prompt: 'Bảng ghi thời gian đi bộ của cả nhóm. Trung bình cộng (phút) là bao nhiêu? Chọn dạng chính xác.', answer: frac(sum, count),
        table: { headers: ['Thời gian (phút)', 'Số người'], rows: [[String(a), String(n1)], [String(high), String(n2)]] },
        wrong: [frac(a + high, 2), String(sum), frac(a + high, count), frac(sum + 1, count), frac(sum + 2, count)],
        explanation: `Tổng thời gian = ${a} × ${n1} + ${high} × ${n2} = ${sum} phút. Có ${n1} + ${n2} = ${count} người. Trung bình = ${sum}/${count} = ${frac(sum, count)} phút.`,
        hints: ['Mỗi hàng cần tính cả số lần xuất hiện.', `Nhân ${a} với ${n1} và ${high} với ${n2}, rồi cộng.`, `Chia tổng ${sum} cho ${count} người.`], misconception: 'Lấy trung bình hai giá trị mà quên tần số.', difficulty: 2 });
    }
  }
];
