// All passages and questions below are original. THCP is not their textual source.
const ownSource = { label: 'Bài đọc và câu hỏi tự biên soạn', chapter: '', part: null, pages: '' };
const normalize = seed => Math.abs(Math.trunc(Number(seed) || 0));
function question(topicId, seed, rows) {
  const n = normalize(seed);
  const row = rows[n % rows.length];
  const options = [...row.options];
  const shift = Math.floor(n / rows.length) % options.length;
  return {
    id: `${topicId}:${seed}`, topicId, context: row.context, prompt: row.prompt,
    options: [...options.slice(shift), ...options.slice(0, shift)],
    answer: row.options[0], explanation: row.explanation,
    hints: row.hints || [
      'Đọc câu hỏi trước: đề đang yêu cầu thông tin nào?',
      'Tìm câu hoặc quan hệ giữa các câu trực tiếp hỗ trợ câu trả lời. Đừng thêm điều đoạn văn chưa nói.',
      row.explanation,
    ],
    misconception: row.misconception || 'Chọn điều có vẻ hợp lý nhưng đoạn văn chưa cung cấp đủ bằng chứng.',
    difficulty: row.difficulty || 1, transfer: n % 2 === 1,
  };
}

const evidence = [
  {
    context: 'Thư viện mở cửa từ 8 giờ đến 17 giờ vào thứ Hai đến thứ Sáu. Riêng thứ Tư, thư viện đóng cửa lúc 15 giờ để kiểm kê. Sáng thứ Bảy, thư viện chỉ nhận sách trả qua hộp bên ngoài; phòng đọc không mở.',
    prompt: 'Theo thông báo, thứ Tư phòng đọc đóng cửa lúc mấy giờ?',
    options: ['15 giờ', '17 giờ', '8 giờ', '12 giờ'],
    explanation: 'Câu thứ hai nêu rõ ngoại lệ: thứ Tư đóng cửa lúc 15 giờ. Lịch chung 17 giờ không áp dụng cho ngày này.',
  },
  {
    context: 'Nhóm của An đo chiều cao cùng một cây vào thứ Hai, thứ Tư và thứ Sáu. Cả ba lần đều đo lúc 7 giờ bằng cùng một chiếc thước. Cây được tưới 200 mL nước mỗi ngày. Nhóm chưa đo các cây khác.',
    prompt: 'Điều nào được nói trực tiếp trong đoạn?',
    options: ['Mỗi lần đo đều diễn ra lúc 7 giờ.', 'Cây cao thêm đúng 2 cm mỗi ngày.', 'Mọi cây đều cần 200 mL nước mỗi ngày.', 'Nhóm đo cây vào mỗi buổi tối.'],
    explanation: 'Đoạn nêu rõ cả ba lần đo đều lúc 7 giờ. Không có số liệu tăng chiều cao hoặc kết luận cho mọi cây.',
  },
  {
    context: 'Một lớp khảo sát 30 bạn về cách đến trường. Có 12 bạn đi bộ, 10 bạn đi xe đạp và 8 bạn đi xe buýt. Mỗi bạn chỉ chọn một cách thường dùng nhất. Kết quả chỉ mô tả 30 bạn của lớp này.',
    prompt: 'Thông tin nào được số liệu trong đoạn trực tiếp xác nhận?',
    options: ['Có 10 bạn chọn xe đạp.', 'Học sinh toàn trường đều thích đi bộ.', 'Xe buýt là cách đến trường nhanh nhất.', 'Mỗi bạn sử dụng cả ba cách mỗi ngày.'],
    explanation: 'Đoạn ghi 10 bạn đi xe đạp. Đoạn không đo sở thích toàn trường, thời gian di chuyển hoặc mọi cách mỗi ngày.',
  },
  {
    context: 'Từ tháng Sáu, cửa hàng đổi giờ giao hàng sang 9–11 giờ sáng. Khách đặt trước 18 giờ hôm trước được giao vào sáng hôm sau. Đơn đặt sau 18 giờ được giao vào sáng ngày kế tiếp nữa. Quy định này không nói về phí giao hàng.',
    prompt: 'Khách đặt lúc 17 giờ thứ Hai sẽ được giao khi nào theo quy định?',
    options: ['9–11 giờ sáng thứ Ba', '9–11 giờ sáng thứ Hai', '9–11 giờ sáng thứ Tư', 'Ngay lúc 18 giờ thứ Hai'],
    explanation: '17 giờ trước hạn 18 giờ hôm trước, nên đơn thứ Hai được giao vào sáng hôm sau, tức thứ Ba từ 9 đến 11 giờ.',
  },
  {
    context: 'Mai đọc 20 trang vào thứ Hai và 15 trang vào thứ Ba. Thứ Tư, Mai nghỉ đọc để ôn lại các ghi chú. Mai dự định cuối tuần mới làm bài tóm tắt. Đoạn ghi chép không nêu tổng số trang của cuốn sách.',
    prompt: 'Vào thứ Tư, Mai đã làm gì theo đoạn ghi chép?',
    options: ['Ôn lại các ghi chú.', 'Đọc thêm 15 trang.', 'Hoàn thành bài tóm tắt.', 'Đọc hết cuốn sách.'],
    explanation: 'Câu thứ hai nói Mai nghỉ đọc vào thứ Tư để ôn ghi chú. Kế hoạch cuối tuần không phải việc đã hoàn thành.',
  },
  {
    context: 'Trong tuần thử nghiệm, phòng học A đặt điều hòa ở 26°C, phòng B ở 28°C. Mỗi phòng có 20 người và bật điều hòa trong 4 giờ mỗi ngày. Nhóm chỉ ghi điện năng tiêu thụ, chưa hỏi người học cảm thấy dễ chịu hay không.',
    prompt: 'Đại lượng nào chưa được nhóm khảo sát trong đoạn?',
    options: ['Cảm giác dễ chịu của người học.', 'Điện năng tiêu thụ.', 'Nhiệt độ cài đặt ở hai phòng.', 'Số người ở mỗi phòng.'],
    explanation: 'Câu cuối nói rõ nhóm chưa hỏi về cảm giác dễ chịu. Điện năng, nhiệt độ cài đặt và số người đều được nêu.',
  },
];

const inference = [
  {
    context: 'Mọi học sinh tham gia câu lạc bộ trong buổi này đều đã đăng ký trước. Lan đang tham gia buổi sinh hoạt này với tư cách học sinh. Danh sách đăng ký được kiểm tra trước khi cho từng học sinh vào.',
    prompt: 'Nếu các thông tin trong đoạn đều đúng, điều nào chắc chắn suy ra được?',
    options: ['Lan đã đăng ký trước.', 'Lan là chủ nhiệm câu lạc bộ.', 'Mọi người đăng ký đều có mặt.', 'Lan là người đăng ký đầu tiên.'],
    explanation: 'Đoạn cho biết mọi học sinh tham gia đều đã đăng ký trước. Lan là học sinh đang tham gia, nên Lan đã đăng ký trước. Chiều ngược lại “đăng ký thì có mặt” chưa được nêu.',
    difficulty: 2,
  },
  {
    context: 'Hộp X chỉ chứa bi đỏ và bi xanh; mỗi viên có đúng một màu. Bình lấy ra một viên từ hộp X và quan sát thấy viên đó không phải màu đỏ. Không có viên bi màu khác trong hộp.',
    prompt: 'Kết luận nào bắt buộc đúng?',
    options: ['Viên bi Bình lấy ra màu xanh.', 'Trong hộp không còn bi đỏ.', 'Hai màu có số viên bằng nhau.', 'Bình thích màu xanh hơn màu đỏ.'],
    explanation: 'Chỉ có hai khả năng đỏ hoặc xanh. Loại đỏ thì viên đã lấy phải xanh. Điều này không cho biết màu hay số lượng của các viên còn lại.',
    difficulty: 2,
  },
  {
    context: 'Đường từ nhà Hà đến bến xe dài 1 km. Hôm nay Hà đi bộ suốt quãng đường với tốc độ không đổi 4 km mỗi giờ và không dừng lại. Chuyến xe Hà muốn đi khởi hành lúc 7 giờ.',
    prompt: 'Hà cần rời nhà muộn nhất lúc nào để đến bến đúng 7 giờ, theo mô hình trong đoạn?',
    options: ['6 giờ 45 phút', '6 giờ 50 phút', '6 giờ 55 phút', '7 giờ 15 phút'],
    explanation: 'Thời gian đi là 1/4 giờ = 15 phút. Lấy 7 giờ trừ 15 phút được 6 giờ 45. Kết luận dùng giả định tốc độ không đổi và không dừng.',
    difficulty: 2,
  },
  {
    context: 'Trong một phép thử, cốc A và cốc B chứa cùng thể tích nước và có cùng nhiệt độ ban đầu. A đặt dưới nắng, B đặt trong bóng râm. Sau 20 phút, A nóng hơn B. Nhóm chỉ thực hiện phép thử này một lần.',
    prompt: 'Kết luận nào được bằng chứng hỗ trợ ở mức vừa phải?',
    options: ['Trong phép thử này, cốc đặt dưới nắng có nhiệt độ cuối cao hơn.', 'Ánh nắng luôn làm mọi chất nóng lên cùng một lượng.', 'Mọi khác biệt nhiệt độ chỉ có thể do màu cốc.', 'Một phép thử đã chứng minh quy luật đúng trong mọi điều kiện.'],
    explanation: 'Quan sát hỗ trợ kết luận trong phạm vi hai cốc và lần thử này. Một lần thử không đủ chứng minh quy luật cho mọi chất và mọi điều kiện.',
    difficulty: 2,
  },
  {
    context: 'Trong danh sách này, người hoàn thành cả bài A và bài B được nhận huy hiệu. Minh chỉ hoàn thành bài A; bài B vẫn chưa hoàn thành. Không có cách nhận huy hiệu nào khác trong quy định này.',
    prompt: 'Theo đúng quy định trong đoạn, hiện Minh có đủ điều kiện nhận huy hiệu không?',
    options: ['Chưa, vì Minh chưa hoàn thành bài B.', 'Có, vì chỉ cần hoàn thành một bài.', 'Có, vì đã đọc tên cả hai bài.', 'Không thể biết bài B có bắt buộc hay không.'],
    explanation: 'Quy định dùng “cả A và B”, nghĩa là cần cả hai. Minh còn thiếu B nên chưa đủ điều kiện, dù đã hoàn thành A.',
    difficulty: 2,
  },
  {
    context: 'Trên một tuyến xe, trạm C nằm sau trạm B và trạm B nằm sau trạm A theo chiều từ đầu tuyến đến cuối tuyến. Xe xuất phát từ đầu tuyến, chạy theo đúng thứ tự các trạm và không quay lại. Xe vừa rời B, còn chưa đến C.',
    prompt: 'Điều nào chắc chắn đúng về xe này?',
    options: ['Xe đã đi qua trạm A.', 'Xe đã đến trạm C.', 'Xe đang quay lại trạm A.', 'B là trạm cuối của tuyến.'],
    explanation: 'Xe xuất phát từ đầu tuyến, đi theo thứ tự A → B → C và đã rời B, nên đã qua A. Điều kiện xuất phát từ đầu tuyến loại trừ trường hợp xe mới bắt đầu chạy ở B. Đoạn nói rõ xe chưa đến C.',
    difficulty: 2,
  },
];

const structure = [
  {
    context: 'Đầu tiên, nhóm ghi nhiệt độ nước ban đầu. Tiếp theo, nhóm đặt cốc vào chậu nước ấm và bấm giờ. Sau 5 phút, nhóm đo lại nhiệt độ. Cuối cùng, nhóm ghi chênh lệch giữa hai lần đo.',
    prompt: 'Đoạn văn chủ yếu được tổ chức theo cách nào?',
    options: ['Trình tự các bước thực hiện.', 'So sánh ưu và nhược điểm của hai ý kiến.', 'Kể tiểu sử một nhà khoa học.', 'Phản bác một kết luận bằng phản ví dụ.'],
    explanation: 'Các từ “đầu tiên”, “tiếp theo”, “sau 5 phút”, “cuối cùng” đánh dấu thứ tự thao tác. Đoạn không tranh luận hai quan điểm.',
  },
  {
    context: 'Xe đạp cần sức đạp của người đi, còn xe buýt có động cơ và chở được nhiều người cùng lúc. Xe đạp linh hoạt ở đường hẹp; xe buýt phù hợp khi cần di chuyển xa theo tuyến. Mỗi cách có ích trong điều kiện khác nhau.',
    prompt: 'Cách triển khai chính của đoạn là gì?',
    options: ['So sánh hai cách di chuyển theo đặc điểm và điều kiện sử dụng.', 'Mô tả từng bước sửa một chiếc xe đạp.', 'Chứng minh xe đạp luôn nhanh hơn xe buýt.', 'Giải thích lịch sử phát minh động cơ.'],
    explanation: 'Đoạn đặt xe đạp và xe buýt cạnh nhau theo sức vận hành, sức chở và bối cảnh sử dụng; kết luận không xếp một cách luôn tốt hơn.',
  },
  {
    context: 'Bình nước không có nắp nên nước bay hơi ra ngoài dễ hơn. Vì thế, sau nhiều ngày lượng nước giảm dù không ai lấy nước. Đậy nắp giúp hạn chế sự trao đổi với không khí, nhưng không có nghĩa là nước không thể bay hơi.',
    prompt: 'Hai câu đầu có quan hệ chủ yếu nào?',
    options: ['Nguyên nhân và kết quả.', 'Hai bước sắp xếp theo thứ tự bảng chữ cái.', 'Hai kết luận không liên quan nhau.', 'Một lời khen và một lời chê.'],
    explanation: 'Không có nắp là điều kiện được dùng để giải thích nước bay hơi và lượng nước giảm. Từ “vì thế” báo quan hệ nguyên nhân–kết quả.',
  },
  {
    context: 'Một số bạn cho rằng chỉ cần xem lời giải là đã hiểu bài. Tuy nhiên, khi đổi số trong đề, nhiều bạn vẫn không tự giải được. Vì vậy, tự làm một bài mới là cách bổ sung bằng chứng cho việc đã hiểu.',
    prompt: 'Câu thứ hai giữ vai trò gì trong lập luận?',
    options: ['Đưa ra tình huống cho thấy nhận định ở câu đầu chưa đủ.', 'Hướng dẫn cách thay pin máy tính.', 'Xác nhận mọi bạn xem lời giải đều tự giải được.', 'Giới thiệu một chủ đề không liên quan.'],
    explanation: 'Câu thứ hai nêu trường hợp xem lời giải nhưng không tự giải bài đổi số, làm yếu nhận định “chỉ cần xem”. Câu cuối rút ra đề nghị kiểm tra thêm.',
    difficulty: 2,
  },
  {
    context: 'Nước sạch là nguồn lực cần được sử dụng cẩn thận. Chẳng hạn, khóa vòi trong khi chải răng giúp tránh nước chảy liên tục không cần thiết. Ví dụ này cho thấy một thay đổi nhỏ trong sinh hoạt có thể giảm lãng phí.',
    prompt: 'Ví dụ “khóa vòi khi chải răng” có tác dụng gì?',
    options: ['Minh họa một hành động cụ thể phù hợp với ý sử dụng nước cẩn thận.', 'Đưa ra số liệu tổng lượng nước của cả thành phố.', 'Chứng minh chải răng không cần nước.', 'Kể nguồn gốc của hệ thống cấp nước.'],
    explanation: 'Ví dụ cụ thể hóa ý chung ở câu đầu. Đoạn không đưa số liệu toàn thành phố hay khẳng định hoàn toàn không dùng nước khi chải răng.',
  },
  {
    context: 'Lớp có ít chỗ đặt cây gần cửa sổ. Để mọi nhóm được dùng vị trí đủ sáng, lớp lập lịch luân phiên chỗ đặt cây theo tuần. Lịch được dán lên bảng để các nhóm biết lúc đổi chỗ.',
    prompt: 'Đoạn được triển khai chủ yếu theo quan hệ nào?',
    options: ['Nêu vấn đề rồi mô tả cách giải quyết.', 'Liệt kê các nhà thực vật học theo năm sinh.', 'So sánh hai định luật chuyển động.', 'Kể một chuỗi sự kiện không có mục đích chung.'],
    explanation: 'Vấn đề là ít chỗ đủ sáng; giải pháp là lịch luân phiên; câu cuối nêu cách thông báo lịch. Ba câu liên kết quanh cùng một vấn đề.',
  },
];

export const readingTopics = [
  {
    id: 'reading-evidence', domain: 'reading', title: 'Tìm bằng chứng trong đoạn',
    subtitle: 'Phân biệt điều được viết với điều mình tự đoán.', icon: 'book', color: 'purple',
    minutes: 15, level: 0, prerequisites: [],
    why: 'Bài đọc có thể chứa nhiều con số và ngoại lệ. Chọn đúng câu hỗ trợ giúp bạn trả lời có căn cứ.',
    concepts: [
      'Bằng chứng là thông tin trong đoạn hỗ trợ trực tiếp câu trả lời. Một câu nghe hợp lý ngoài đời vẫn có thể không được đoạn này xác nhận.',
      'Đọc đúng phạm vi: “trong lớp này” không tự động có nghĩa là “mọi học sinh”. Chú ý các từ chỉ số lượng, thời gian và ngoại lệ như “riêng”, “chỉ”, “chưa”.',
      'Hãy tự hỏi: mình có thể chỉ ra câu nào trong đoạn khiến đáp án này đúng? Nếu chưa tìm thấy, hãy đọc lại trước khi kết luận.',
    ],
    example: { prompt: 'Thông báo: “Phòng đọc mở 8–17 giờ. Riêng thứ Tư đóng lúc 15 giờ.” Thứ Tư đóng lúc mấy giờ?', steps: ['Xác định ngày được hỏi: thứ Tư.', 'Tìm câu nói riêng về ngày đó.', 'Dùng ngoại lệ 15 giờ, thay vì giờ đóng cửa chung.'], answer: '15 giờ; bằng chứng là câu bắt đầu bằng “Riêng thứ Tư”.' },
    reflection: 'Bạn vừa chọn đáp án dựa vào câu nào? Có điều gì bạn thấy hợp lý nhưng đoạn chưa nói không?',
    source: ownSource, visual: 'reading', makeQuestion: (seed = 0) => question('reading-evidence', seed, evidence),
  },
  {
    id: 'reading-inference', domain: 'reading', title: 'Suy luận có điều kiện',
    subtitle: 'Nối thông tin, giữ nguyên giới hạn của bằng chứng.', icon: 'sparkles', color: 'blue',
    minutes: 15, level: 1, prerequisites: ['reading-evidence'],
    why: 'Suy luận tốt giúp nối các câu rời nhau mà không thêm giả định chưa được cung cấp.',
    concepts: [
      'Một kết luận chắc chắn phải theo từ các điều đã cho. Nếu đoạn chỉ nói “A thì B”, bạn chưa thể tự đổi thành “B thì A”.',
      'Phân biệt quan sát trong một tình huống với quy luật cho tất cả tình huống. Một lần thử có thể gợi ý, nhưng chưa chứng minh điều luôn đúng.',
      'Khi loại trừ, hãy kiểm tra danh sách khả năng có đầy đủ không. Chỉ có hai màu đỏ và xanh, không đỏ mới buộc phải là xanh.',
    ],
    example: { prompt: 'Mọi bạn tham gia buổi này đều đã đăng ký. Lan đang tham gia. Ta suy ra gì?', steps: ['Quy định áp dụng cho mọi người tham gia.', 'Lan nằm trong nhóm đang tham gia.', 'Vì vậy, Lan đã đăng ký; chưa biết Lan đăng ký đầu hay cuối.'], answer: 'Lan đã đăng ký.' },
    reflection: 'Kết luận của bạn dùng những thông tin nào? Bạn có đang đảo chiều một điều kiện hoặc khái quát quá rộng không?',
    source: ownSource, visual: 'reading', makeQuestion: (seed = 0) => question('reading-inference', seed, inference),
  },
  {
    id: 'reading-structure', domain: 'reading', title: 'Nhìn mạch lập luận',
    subtitle: 'Nhận ra ví dụ, nguyên nhân và kết luận.', icon: 'layers', color: 'peach',
    minutes: 15, level: 1, prerequisites: ['reading-evidence'],
    why: 'Thấy mỗi câu đang làm việc gì giúp bạn đọc đoạn dài theo một mạch rõ ràng.',
    concepts: [
      'Các câu có thể được nối theo trình tự thao tác, so sánh, nguyên nhân–kết quả hoặc vấn đề–giải pháp. Hãy nhìn quan hệ ý nghĩa, không chỉ một từ riêng lẻ.',
      'Ví dụ cụ thể giúp làm rõ một ý chung. Bằng chứng hỗ trợ kết luận; phản ví dụ có thể cho thấy một khẳng định “luôn đúng” không còn đúng.',
      'Thử tóm tắt vai trò từng câu bằng vài từ: nêu vấn đề, đưa bằng chứng, rút kết luận. Nếu tóm tắt nối được nhau, bạn đã thấy mạch của đoạn.',
    ],
    example: { prompt: '“Sân ít chỗ bóng mát. Lớp chia ca dùng sân. Lịch được dán ở cửa.” Đoạn đi theo mạch nào?', steps: ['Câu đầu nêu hạn chế.', 'Câu hai mô tả cách xử lý hạn chế.', 'Câu ba giúp thực hiện cách xử lý.'], answer: 'Vấn đề → giải pháp → cách thông báo giải pháp.' },
    reflection: 'Mỗi câu trong đoạn đang làm nhiệm vụ gì? Câu nào là kết luận, câu nào là ví dụ hoặc bằng chứng?',
    source: ownSource, visual: 'reading', makeQuestion: (seed = 0) => question('reading-structure', seed, structure),
  },
];
