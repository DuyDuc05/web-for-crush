// Bài học và dữ liệu do ứng dụng biên soạn. THCP là nguồn tham khảo phương pháp,
// không phải đề cương TSA chính thức. Không chép bài tập hoặc đáp án của sách.
const seedNumber = (seed) => Number.isFinite(Number(seed)) ? Math.abs(Math.trunc(Number(seed))) % 1000000 : 0;
const number = (value) => String(Number(value.toFixed(6))).replace('.', ',');
const quantity = (value, unit) => `${number(value)} ${unit}`;

function question(topicId, seed, data) {
  const normalized = seedNumber(seed);
  const options = [...data.options];
  if (new Set(options).size !== 4 || options.filter((option) => option === data.answer).length !== 1) {
    throw new Error(`Câu hỏi ${topicId}:${normalized} có lựa chọn không hợp lệ`);
  }
  // Vị trí đáp án thay đổi, vẫn tái hiện được khi ôn cùng câu.
  const rotation = (normalized * 3 + topicId.length) % 4;
  return {
    id: `${topicId}:${normalized}`,
    topicId,
    difficulty: 1,
    ...data,
    options: options.slice(rotation).concat(options.slice(0, rotation)),
  };
}

function unitsQuestion(seed = 0) {
  const s = seedNumber(seed), variant = s % 4, k = Math.floor(s / 4) % 9 + 2;
  if (variant === 0) {
    const speed = 18 * k, answer = quantity(speed / 3.6, 'm/s');
    return question('units', s, {
      prompt: `Một xe đi với tốc độ ${speed} km/h. Đổi tốc độ này sang m/s.`,
      options: [answer, quantity(speed, 'm/s'), quantity(speed * 3.6, 'm/s'), quantity(speed / 36, 'm/s')], answer,
      explanation: `1 km = 1.000 m; 1 giờ = 3.600 giây. Vì thế ${speed} km/h = ${speed} × 1.000 / 3.600 = ${answer}. Độ lớn con số đổi, chuyển động thực của xe không đổi.`,
      hints: ['Đổi cả kilomet và giờ, không chỉ đổi một đơn vị.', '1 kilomet bằng 1.000 mét, còn 1 giờ bằng 3.600 giây.', `Chia ${speed} cho 3,6; đơn vị còn lại là m/s.`],
      misconception: 'Chỉ nhân với 1.000 hoặc nhầm chiều hệ số đổi km/h và m/s.',
    });
  }
  if (variant === 1) {
    const grams = 250 * k, answer = quantity(grams / 1000, 'kg');
    return question('units', s, {
      prompt: `Một mẫu vật có khối lượng ${grams} g. Khối lượng đó bằng bao nhiêu kg?`,
      options: [answer, quantity(grams, 'kg'), quantity(grams / 100, 'kg'), quantity(grams * 1000, 'kg')], answer,
      explanation: `1 kg = 1.000 g. Lấy ${grams} / 1.000 = ${answer}. Đổi sang đơn vị lớn hơn thì số đo nhỏ đi.`,
      hints: ['Hình dung 1 túi gạo 1 kg có khối lượng 1.000 g.', 'Số kilogram bằng số gram chia 1.000.', `Tính ${grams} / 1.000 và giữ đơn vị kg.`],
      misconception: 'Đổi sang đơn vị lớn hơn nhưng lại nhân số đo lên.',
    });
  }
  if (variant === 2) {
    const area = k * 100, answer = quantity(area / 10000, 'm²');
    return question('units', s, {
      prompt: `Một tấm bìa có diện tích ${area} cm². Diện tích đó bằng bao nhiêu m²?`,
      options: [answer, quantity(area / 100, 'm²'), quantity(area, 'm²'), quantity(area / 1000000, 'm²')], answer,
      explanation: `Vì 1 m = 100 cm nên 1 m² = 100 × 100 = 10.000 cm². Do đó ${area} cm² = ${answer}. Đổi diện tích phải bình phương hệ số đổi chiều dài.`,
      hints: ['Diện tích có hai chiều: dài và rộng.', 'Một hình vuông 1 m × 1 m cũng là 100 cm × 100 cm.', `Chia ${area} cho 10.000, không phải cho 100.`],
      misconception: 'Dùng hệ số đổi chiều dài cho diện tích.', difficulty: 2,
    });
  }
  const answer = 'Công thức A';
  return question('units', s, {
    prompt: 'Biết a có đơn vị m/s² và t có đơn vị s. Công thức nào dưới đây có thể cho một quãng đường xét riêng về đơn vị?',
    context: 'A: d = a × t² / 3. B: d = a × t. C: d = a + t. Kiểm tra đơn vị chưa đủ để chứng minh một công thức đúng về vật lý.',
    options: [answer, 'Công thức B', 'Công thức C', 'Cả ba công thức'], answer,
    explanation: 'Trong A, (m/s²) × s² = m. B cho m/s, còn C cộng hai đại lượng khác loại nên không hợp lệ. A chỉ vượt qua phép kiểm tra đơn vị; hệ số 1/3 có đúng hay không còn phụ thuộc mô hình và dữ kiện.',
    hints: ['Quãng đường cần có đơn vị mét.', 'Ở công thức A, t² có đơn vị s².', 'Triệt tiêu s² ở tử và mẫu; không suy ra hệ số 1/3 chắc chắn đúng.'],
    misconception: 'Cho rằng đúng thứ nguyên đồng nghĩa đã chứng minh đúng công thức.', difficulty: 2, transfer: true,
  });
}

function motionQuestion(seed = 0) {
  const s = seedNumber(seed), variant = s % 4, k = Math.floor(s / 4) % 8 + 2;
  if (variant === 0) {
    const time = k + 2, speed = k + 1, distance = speed * time, answer = quantity(speed, 'm/s');
    return question('motion', s, {
      prompt: `Một robot đi được ${distance} m trong ${time} s. Tốc độ trung bình của robot là bao nhiêu?`,
      options: [answer, quantity(distance, 'm/s'), quantity(distance * time, 'm/s'), quantity(time / distance, 'm/s')], answer,
      explanation: `Tốc độ trung bình bằng tổng quãng đường / tổng thời gian = ${distance} / ${time} = ${answer}. Từ dữ kiện này chưa biết robot có đi đều ở mọi thời điểm hay không.`,
      hints: ['Tốc độ cho biết trung bình mỗi giây đi bao nhiêu mét.', 'Lấy quãng đường chia cho thời gian.', `Tính ${distance} / ${time}.`],
      misconception: 'Nhân quãng đường với thời gian, hoặc suy tốc độ trung bình thành tốc độ luôn không đổi.',
    });
  }
  if (variant === 1) {
    const start = 4 * k, end = k, seconds = 3, answer = quantity((end - start) / seconds, 'm/s');
    return question('motion', s, {
      prompt: `Trên một trục thẳng, robot ở x = ${start} m, sau ${seconds} s ở x = ${end} m. Vận tốc trung bình theo trục đã chọn là bao nhiêu?`,
      options: [answer, quantity(k, 'm/s'), quantity(end - start, 'm/s'), quantity((start + end) / seconds, 'm/s')], answer,
      explanation: `Độ dời = x sau − x đầu = ${end} − ${start} = ${end - start} m. Vận tốc trung bình = độ dời / thời gian = ${answer}. Dấu âm biểu thị hướng ngược chiều dương, không có nghĩa là thời gian âm.`,
      hints: ['Vận tốc trung bình dùng độ dời có dấu.', 'Tính vị trí sau trừ vị trí đầu.', `Lấy (${end} − ${start}) / 3; kết quả cần có dấu âm.`],
      misconception: 'Bỏ dấu của độ dời nên nhầm vận tốc với tốc độ.', difficulty: 2,
    });
  }
  if (variant === 2) {
    const speed = k, answer = quantity(speed, 'm/s');
    return question('motion', s, {
      prompt: 'Bảng ghi vị trí của một xe theo thời gian. Vận tốc trung bình từ 0 s đến 6 s là bao nhiêu?',
      table: { headers: ['Thời gian (s)', 'Vị trí (m)'], rows: [['0', '0'], ['2', String(speed * 2)], ['4', String(speed * 4)], ['6', String(speed * 6)]] },
      options: [answer, quantity(speed * 6, 'm/s'), quantity(speed * 2, 'm/s'), quantity(6 / (speed * 6), 'm/s')], answer,
      explanation: `Vị trí đổi từ 0 m đến ${speed * 6} m trong 6 s, nên vận tốc trung bình bằng ${speed * 6} / 6 = ${answer}. Những khoảng được ghi đều có cùng tỉ số độ dời / thời gian.`,
      hints: ['Đọc đơn vị của cả hai cột.', 'Dùng hàng cuối trừ hàng đầu để tìm độ dời và thời gian.', `Tính ${speed * 6} m / 6 s.`],
      misconception: 'Đọc vị trí ở hàng cuối thành vận tốc.', transfer: true,
    });
  }
  const acceleration = k, time = 2, finalSpeed = acceleration * time, answer = quantity(acceleration, 'm/s²');
  return question('motion', s, {
    prompt: `Một xe chuyển động thẳng, vận tốc tăng đều từ 0 lên ${finalSpeed} m/s trong ${time} s. Gia tốc là bao nhiêu?`,
    options: [answer, quantity(finalSpeed, 'm/s²'), quantity(finalSpeed * time, 'm/s²'), quantity(1 / acceleration, 'm/s²')], answer,
    explanation: `Gia tốc = độ thay đổi vận tốc / thời gian = (${finalSpeed} − 0) / ${time} = ${answer}. Đơn vị (m/s) / s = m/s².`,
    hints: ['Gia tốc đo vận tốc thay đổi nhanh đến đâu.', `Vận tốc thay đổi ${finalSpeed} m/s trong 2 s.`, `Chia ${finalSpeed} cho 2; mỗi giây vận tốc tăng ${acceleration} m/s.`],
    misconception: 'Nhầm gia tốc với vận tốc cuối hoặc với quãng đường.', difficulty: 2,
  });
}

function forcesQuestion(seed = 0) {
  const s = seedNumber(seed), variant = s % 4, k = Math.floor(s / 4) % 8 + 2;
  if (variant === 0) {
    const right = 5 * k, left = 2 * k, answer = `${right - left} N sang phải`;
    return question('forces', s, {
      prompt: `Một vật trên mặt phẳng ngang chịu lực kéo ${right} N sang phải và lực cản ${left} N sang trái. Hai lực thẳng hàng; các lực thẳng đứng cân bằng. Hợp lực theo phương ngang là gì?`,
      options: [answer, `${right + left} N sang phải`, `${right - left} N sang trái`, `${right} N sang phải`], answer,
      explanation: `Chọn chiều dương sang phải: hợp lực = ${right} − ${left} = ${right - left} N, hướng sang phải. Hai lực ngược chiều phải trừ độ lớn. Đây là lực tổng, chưa phải vận tốc của vật.`,
      hints: ['Vẽ hai mũi tên ngược chiều nhau.', 'Lực sang phải lớn hơn lực sang trái.', `Trừ ${left} khỏi ${right}, giữ hướng của lực lớn hơn.`],
      misconception: 'Cộng độ lớn của mọi lực dù chúng ngược chiều.',
    });
  }
  if (variant === 1) {
    const mass = k, force = 3 * mass, answer = quantity(3, 'm/s²');
    return question('forces', s, {
      prompt: `Một xe có khối lượng ${mass} kg chịu hợp lực ngang ${force} N. Khối lượng không đổi; xét trong hệ quy chiếu quán tính. Gia tốc ngang có độ lớn bao nhiêu?`,
      options: [answer, quantity(force * mass, 'm/s²'), quantity(force, 'm/s²'), quantity(mass / force, 'm/s²')], answer,
      explanation: `Định luật II Newton: hợp lực F = m × a. Do đó a = F / m = ${force} / ${mass} = ${answer}. 1 N = 1 kg·m/s² nên đơn vị cũng phù hợp.`,
      hints: ['Ở đây đề cho hợp lực, không phải riêng một lực kéo.', 'Từ F = m × a, chia cả hai vế cho m.', `Tính ${force} / ${mass}.`],
      misconception: 'Thay lực kéo riêng lẻ cho hợp lực hoặc nhân F với m.', difficulty: 2,
    });
  }
  if (variant === 2) {
    const mass = k, answer = quantity(mass * 10, 'N');
    return question('forces', s, {
      prompt: `Một vật có khối lượng ${mass} kg ở nơi có g = 10 N/kg. Trọng lượng của vật là bao nhiêu?`,
      options: [answer, quantity(mass, 'N'), quantity(mass / 10, 'N'), quantity(mass * 100, 'N')], answer,
      explanation: `Trọng lượng là lực hấp dẫn: P = m × g = ${mass} kg × 10 N/kg = ${answer}. Khối lượng vẫn là ${mass} kg; trọng lượng dùng đơn vị N. g = 10 N/kg là giá trị đã cho của bài.`,
      hints: ['Khối lượng và trọng lượng là hai đại lượng khác nhau.', 'Trọng lượng P = m × g.', `Nhân ${mass} với 10; kg triệt tiêu, còn N.`],
      misconception: 'Gọi số kilogram là trọng lượng tính bằng newton.',
    });
  }
  const answer = 'Lực lò xo hướng sang trái, cùng hướng vận tốc';
  return question('forces', s, {
    prompt: 'Một vật gắn lò xo nằm bên phải vị trí cân bằng và đang chuyển động sang trái về vị trí cân bằng. Chỉ xét lực đàn hồi của lò xo lý tưởng theo phương ngang. Phát biểu nào đúng?',
    options: [answer, 'Lực lò xo hướng sang phải, ngược hướng vận tốc', 'Lực lò xo bằng 0 vì vật đang trở về', 'Lực lò xo luôn ngược vận tốc ở mọi vị trí'], answer,
    explanation: 'Lực hồi phục của lò xo hướng về vị trí cân bằng, tức sang trái khi vật ở bên phải. Vật cũng đang chuyển động sang trái nên hai hướng trùng nhau ở thời điểm này. F = −k×x nói lực ngược dấu li độ; không nói lực luôn ngược vận tốc.',
    hints: ['Xác định vị trí cân bằng nằm bên nào so với vật.', 'Lò xo kéo vật về vị trí cân bằng.', 'Cả hướng về cân bằng lẫn hướng chuyển động hiện tại đều sang trái.'],
    misconception: 'Nhầm lực hồi phục với lực cản và cho rằng dấu trừ luôn chỉ hướng ngược vận tốc.', difficulty: 2, transfer: true,
  });
}

function energyQuestion(seed = 0) {
  const s = seedNumber(seed), variant = s % 4, k = Math.floor(s / 4) % 8 + 2;
  if (variant === 0) {
    const mass = k, speed = 4, answer = quantity(mass * speed * speed / 2, 'J');
    return question('energy', s, {
      prompt: `Một xe mô hình khối lượng ${mass} kg đang đi với tốc độ ${speed} m/s. Dùng Eđ = m × v² / 2, động năng của xe là bao nhiêu?`,
      options: [answer, quantity(mass * speed / 2, 'J'), quantity(mass * speed * speed, 'J'), quantity(mass * speed * speed / 4, 'J')], answer,
      explanation: `Bình phương tốc độ trước: v² = 4² = 16 m²/s². Eđ = ${mass} × 16 / 2 = ${answer}. Đơn vị kg·m²/s² chính là J.`,
      hints: ['Chú ý v² là v nhân v.', '4² = 16, không phải 8.', `Nhân ${mass} với 16 rồi chia 2.`],
      misconception: 'Quên bình phương tốc độ hoặc quên hệ số 1/2.',
    });
  }
  if (variant === 1) {
    const factor = k % 3 + 2, answer = `Gấp ${factor * factor} lần`;
    return question('energy', s, {
      prompt: `Một vật giữ nguyên khối lượng nhưng tốc độ tăng gấp ${factor} lần. Biết động năng tỉ lệ với bình phương tốc độ, động năng mới bằng bao nhiêu so với ban đầu?`,
      options: [answer, `Gấp ${factor} lần`, 'Không đổi', `Bằng 1/${factor * factor} ban đầu`], answer,
      explanation: `Trong Eđ = m×v²/2, m không đổi. Thay v bằng ${factor}×v làm v² tăng gấp ${factor}² = ${factor * factor} lần. Đây là tỉ lệ năng lượng, không phải tỉ lệ thời gian hay quãng đường.`,
      hints: ['Viết tốc độ mới là một hệ số nhân tốc độ cũ.', `(${factor}×v)² = ${factor}²×v².`, `Bình phương ${factor}.`],
      misconception: 'Mọi đại lượng đều tăng cùng tỉ lệ với tốc độ.', difficulty: 2, transfer: true,
    });
  }
  if (variant === 2) {
    const kinetic = k * 5, total = k * 20, answer = quantity(total - kinetic, 'J');
    return question('energy', s, {
      prompt: `Một hệ vật–lò xo lý tưởng nằm ngang, không có lực cản và không nhận công từ bên ngoài. Chọn thế năng trọng trường bằng 0; cơ năng chỉ gồm động năng và thế năng đàn hồi. Hệ có cơ năng ${total} J. Ở một thời điểm động năng là ${kinetic} J. Thế năng đàn hồi lúc đó là bao nhiêu?`,
      options: [answer, quantity(total + kinetic, 'J'), quantity(kinetic, 'J'), quantity(total, 'J')], answer,
      explanation: `Trong mô hình nằm ngang này, thế năng trọng trường được chọn bằng 0, nên cơ năng = động năng + thế năng đàn hồi và được bảo toàn. Thế năng đàn hồi = ${total} − ${kinetic} = ${answer}. Cơ năng bảo toàn không có nghĩa từng dạng năng lượng đều không đổi.`,
      hints: ['Hình dung tổng năng lượng nằm trong hai ngăn.', 'Tổng = động năng + thế năng.', `Lấy ${total} trừ ${kinetic}.`],
      misconception: 'Cho rằng cơ năng bằng động năng, hoặc bảo toàn nghĩa là mọi dạng năng lượng đều không đổi.',
    });
  }
  const mass = k, height = 3, answer = quantity(mass * 10 * height, 'J');
  return question('energy', s, {
    prompt: `Một vật khối lượng ${mass} kg được nâng lên cao thêm ${height} m gần mặt đất. Cho g = 10 N/kg, độ tăng thế năng trọng trường là bao nhiêu? Dùng ΔE = m×g×Δh.`,
    options: [answer, quantity(mass * 10, 'J'), quantity(mass * height, 'J'), quantity(mass * 10 / height, 'J')], answer,
    explanation: `Độ tăng thế năng = ${mass} kg × 10 N/kg × 3 m = ${answer}. N×m = J. Đây là độ thay đổi thế năng; không cần biết mốc thế năng tuyệt đối ở đâu.`,
    hints: ['Dùng độ cao tăng thêm, không cần biết độ cao tuyệt đối.', 'Thay m, g và Δh vào công thức đề cho.', `Tính ${mass} × 10 × 3.`],
    misconception: 'Nhầm trọng lượng tính bằng N với năng lượng tính bằng J.', difficulty: 2,
  });
}

function chemistryQuestion(seed = 0) {
  const s = seedNumber(seed), variant = s % 5, k = Math.floor(s / 5) % 8 + 2;
  if (variant === 0) {
    const answer = `${2 * k} nguyên tử H và ${k} nguyên tử O`;
    return question('chemistry', s, {
      prompt: `Có ${k} phân tử nước H₂O. Tổng số nguyên tử của từng nguyên tố trong những phân tử này là bao nhiêu?`,
      options: [answer, `${k} nguyên tử H và ${2 * k} nguyên tử O`, `${k} nguyên tử H và ${k} nguyên tử O`, `${2 * k} nguyên tử H và ${2 * k} nguyên tử O`], answer,
      explanation: `Mỗi phân tử H₂O gồm 2 nguyên tử H và 1 nguyên tử O. ${k} phân tử gồm ${k}×2 = ${2 * k} nguyên tử H và ${k}×1 = ${k} nguyên tử O. Chỉ số dưới 2 đi với H, không đi với toàn bộ công thức.`,
      hints: ['Đếm trong một phân tử trước.', 'H₂O có 2 H và 1 O.', `Nhân cả hai số đếm với ${k}.`],
      misconception: 'Đọc chỉ số dưới thành hệ số của cả phân tử hoặc đảo tỉ lệ số nguyên tử.',
    });
  }
  if (variant === 1) {
    const answer = '2H₂ + O₂ → 2H₂O';
    return question('chemistry', s, {
      prompt: 'Giữ nguyên các chất H₂, O₂ và H₂O. Cách viết nào cân bằng số nguyên tử H và O trong phản ứng tạo nước?',
      options: [answer, 'H₂ + O₂ → H₂O', 'H₂ + O₂ → 2H₂O', '2H₂ + O₂ → H₂O'], answer,
      explanation: 'Ở 2H₂ + O₂ → 2H₂O, bên trái có 4 H và 2 O; bên phải cũng có 4 H và 2 O. Hệ số trước công thức nhân với toàn bộ phân tử. Không thay chỉ số dưới vì làm vậy đổi chất.',
      hints: ['Đếm riêng H và O ở mỗi vế.', 'Ở 2H₂O có 4 H và 2 O.', 'Muốn có 4 H và 2 O bên trái, cần 2H₂ và 1O₂.'],
      misconception: 'Cân bằng bằng cách thay công thức hóa học hoặc chỉ kiểm tra một nguyên tố.',
    });
  }
  if (variant === 2) {
    const mol = k, grams = 18 * mol, answer = quantity(mol, 'mol');
    return question('chemistry', s, {
      prompt: `Một mẫu nước tinh khiết có khối lượng ${grams} g. Cho khối lượng mol của H₂O là 18 g/mol. Mẫu có bao nhiêu mol phân tử nước?`,
      options: [answer, quantity(grams * 18, 'mol'), quantity(grams, 'mol'), quantity(18 / grams, 'mol')], answer,
      explanation: `18 g tương ứng 1 mol. Số mol n = khối lượng / khối lượng mol = ${grams} g / (18 g/mol) = ${answer}. Đơn vị g triệt tiêu, còn mol. Giá trị 18 g/mol là số làm tròn đã cho của bài.`,
      hints: ['Một mol mẫu này nặng 18 g.', `Hỏi có bao nhiêu nhóm 18 g trong ${grams} g.`, `Tính ${grams} / 18; dùng đơn vị mol.`],
      misconception: 'Nhân với khối lượng mol khi cần chia hoặc nhầm g và mol.', difficulty: 2,
    });
  }
  if (variant === 3) {
    const answer = quantity(2 * k, 'mol nguyên tử O');
    return question('chemistry', s, {
      prompt: `Một mẫu chứa ${k} mol phân tử O₂. Mẫu chứa bao nhiêu mol nguyên tử O?`,
      options: [answer, quantity(k, 'mol nguyên tử O'), quantity(k / 2, 'mol nguyên tử O'), quantity(k * 4, 'mol nguyên tử O')], answer,
      explanation: `Mỗi phân tử O₂ có 2 nguyên tử O. Vì vậy ${k} mol phân tử O₂ chứa ${2 * k} mol nguyên tử O. “Mol phân tử” và “mol nguyên tử” cần ghi rõ để biết đang đếm loại hạt nào.`,
      hints: ['Mol là cách đếm hạt; cần xác định loại hạt.', 'Một phân tử O₂ có hai nguyên tử O.', `Nhân ${k} mol phân tử với 2 nguyên tử trong mỗi phân tử.`],
      misconception: 'Cho rằng một mol phân tử luôn chứa đúng một mol nguyên tử.', difficulty: 2, transfer: true,
    });
  }
  const first = 3 * k, second = 8 * k, answer = quantity(first + second, 'g');
  return question('chemistry', s, {
    prompt: `Trong một bình kín, ban đầu có ${first} g chất A và ${second} g chất B. Hai chất phản ứng, không có chất đi vào hoặc thoát ra. Tổng khối lượng toàn bộ chất trong bình sau phản ứng là bao nhiêu?`,
    options: [answer, quantity(second - first, 'g'), quantity(second, 'g'), quantity(first * second, 'g')], answer,
    explanation: `Trong phản ứng hóa học thông thường của hệ kín này, khối lượng toàn bộ chất được bảo toàn: ${first} + ${second} = ${answer}. Không cần biết phản ứng đã hoàn toàn chưa vì câu hỏi hỏi tổng mọi chất, kể cả chất còn dư.`,
    hints: ['Đề hỏi tổng mọi chất, không chỉ một sản phẩm.', 'Bình kín không cho vật chất đi vào hay thoát ra.', `Cộng ${first} g và ${second} g.`],
    misconception: 'Nghĩ phản ứng làm mất khối lượng hoặc coi tổng mọi chất bằng riêng lượng sản phẩm.', transfer: true,
  });
}

function experimentQuestion(seed = 0) {
  const s = seedNumber(seed), variant = s % 4, k = Math.floor(s / 4) % 8 + 2;
  if (variant === 0) {
    const low = k + 2, high = low + 3, answer = 'Trong điều kiện đã thử, nhóm nhận 8 giờ sáng có mức tăng chiều cao trung bình lớn hơn';
    return question('experiment', s, {
      prompt: 'Kết luận nào được bảng dữ liệu hỗ trợ trực tiếp?',
      context: 'Dữ liệu giả định để học đọc thí nghiệm: 40 cây cùng loài được phân ngẫu nhiên vào hai nhóm. Đất, nhiệt độ và lượng nước giống nhau; chỉ thay thời gian chiếu sáng mỗi ngày. Sau 14 ngày, đo mức tăng chiều cao. Chưa có số liệu độ phân tán.',
      table: { headers: ['Nhóm', 'Giờ sáng/ngày', 'Tăng chiều cao trung bình (cm)'], rows: [['A', '4', String(low)], ['B', '8', String(high)]] },
      options: [answer, 'Mọi cây ở nhóm B đều cao hơn mọi cây ở nhóm A', 'Càng tăng giờ sáng thì mọi loài cây luôn cao hơn', 'Không thể đọc được nhóm nào có trung bình lớn hơn'], answer,
      explanation: `Trung bình nhóm B là ${high} cm, cao hơn nhóm A (${low} cm) một lượng 3 cm. Bảng không cho từng cây, độ phân tán, loài khác hay thời gian chiếu sáng khác. Vì vậy không kết luận “mọi cây” hoặc một quy luật không giới hạn.`,
      hints: ['Chỉ so sánh điều bảng thực sự đo.', 'Số trung bình không mô tả từng cá thể.', 'Chọn phát biểu giới hạn trong loài, thời gian và điều kiện đã thử.'],
      misconception: 'Biến kết quả trung bình của một thí nghiệm thành khẳng định cho mọi cá thể hoặc mọi điều kiện.', difficulty: 2, transfer: true,
    });
  }
  if (variant === 1) {
    const answer = 'Vừa thay phân bón vừa thay lượng nước nên chưa tách được ảnh hưởng của phân bón';
    return question('experiment', s, {
      prompt: 'Một bạn muốn kiểm tra phân bón có làm cây lớn nhanh hơn không. Nhóm A có phân bón và nhận 200 mL nước/ngày; nhóm B không có phân bón và nhận 100 mL nước/ngày. Vấn đề chính của cách làm này là gì?',
      options: [answer, 'Cần đổi thêm cả loại đất và giống cây giữa hai nhóm', 'Chỉ cần nhóm A lớn hơn là đã chứng minh phân bón có tác dụng', 'Không có cách nào kiểm tra ảnh hưởng của phân bón bằng thí nghiệm'], answer,
      explanation: 'Phân bón và lượng nước cùng thay đổi nên khác biệt tăng trưởng có thể do nước, phân bón hoặc cả hai. Một sửa đổi hợp lý là giữ lượng nước như nhau, giữ các điều kiện khác tương đương và phân cây ngẫu nhiên vào nhóm; chỉ thay yếu tố phân bón đang kiểm tra.',
      hints: ['Liệt kê tất cả yếu tố khác nhau giữa hai nhóm.', 'Không chỉ phân bón khác nhau: lượng nước cũng khác.', 'Cần giữ lượng nước như nhau để tách ảnh hưởng của phân bón.'],
      misconception: 'Thấy hai việc đi cùng nhau thì kết luận ngay quan hệ nhân quả.',
    });
  }
  if (variant === 2) {
    const pH = 6 + (k % 2), answer = `pH ${pH}`;
    return question('experiment', s, {
      prompt: 'Theo bảng, trong ba giá trị pH đã thử, pH nào có hoạt tính enzyme trung bình cao nhất?',
      context: 'Dữ liệu giả định: cùng loại enzyme, lượng enzyme, nhiệt độ, thời gian và nồng độ cơ chất; chỉ thay pH. Hoạt tính được đo bằng lượng sản phẩm tạo ra trong một phút. Mỗi điều kiện được lặp lại.',
      table: { headers: ['pH', 'Hoạt tính trung bình (đơn vị/phút)'], rows: [[String(pH - 2), String(k * 2)], [String(pH), String(k * 5)], [String(pH + 2), String(k * 3)]] },
      options: [answer, `pH ${pH - 2}`, `pH ${pH + 2}`, 'Cả ba pH có hoạt tính bằng nhau'], answer,
      explanation: `Giá trị ${k * 5} lớn nhất trong ba số ${k * 2}, ${k * 5}, ${k * 3}, nên pH ${pH} cao nhất trong các mức đã thử. Chưa đủ dữ liệu để nói đây là pH tối ưu tuyệt đối hoặc phù hợp với mọi enzyme. Không cần biết trước sinh học để đọc được bảng này.`,
      hints: ['Đọc cột hoạt tính, không chọn pH lớn nhất.', 'So sánh ba số đo ở cột bên phải.', `Số lớn nhất là ${k * 5}; tìm pH ở cùng hàng.`],
      misconception: 'Chọn giá trị của biến đầu vào lớn nhất thay vì so sánh kết quả đo.', transfer: true,
    });
  }
  const answer = 'Lặp lại phép đo trên nhiều mẫu tương đương rồi xem cả trung bình và mức phân tán';
  return question('experiment', s, {
    prompt: 'Hai phương pháp chăm cây cho kết quả khác nhau trên hai cây duy nhất. Cách nào giúp kiểm tra xem kết quả có ổn định hơn trước khi khái quát?',
    options: [answer, 'Chọn chỉ lần đo có kết quả đúng với điều mình mong đợi', 'Đổi đồng thời tất cả điều kiện trong lần đo tiếp theo', 'Kết luận ngay rằng phương pháp thắng trên một cây luôn tốt hơn'], answer,
    explanation: 'Lặp lại trên nhiều mẫu tương đương giúp thấy khác biệt có ổn định hay chỉ do biến thiên giữa cá thể/phép đo. Cần xem cả trung bình và độ phân tán, giữ các điều kiện được kiểm soát. Lặp lại không tự động sửa được một thiết kế bị nhiễu hoặc cách lấy mẫu thiên lệch.',
    hints: ['Một cây có thể khác cây còn lại vì nhiều lý do.', 'Cần thêm các mẫu và phép đo được thiết kế tương đương.', 'Giữ cả những kết quả trái dự đoán; xem phân bố chứ không chọn một kết quả đẹp.'],
    misconception: 'Khái quát từ một quan sát hoặc chỉ giữ dữ liệu xác nhận điều mình tin.', difficulty: 2,
  });
}

export const scienceTopics = [
  {
    id: 'units', domain: 'science', title: 'Số đo có ý nghĩa', subtitle: 'Đơn vị, đổi đơn vị và kiểm tra kết quả', icon: 'ruler', color: 'blue', minutes: 15, level: 0,
    prerequisites: ['numbers', 'fractions'], visual: 'units',
    why: 'Đơn vị giúp hiểu câu hỏi đang nói về độ dài, thời gian hay khối lượng. Nó cũng giúp phát hiện nhiều lỗi trước khi bấm máy tính.',
    concepts: ['Một số đo thường gồm con số và đơn vị: 2 m và 2 s nói về hai đại lượng khác nhau. Đừng cộng chúng chỉ vì cùng có số 2.', 'Đổi đơn vị giữ nguyên đại lượng thực. Vì 1 m = 100 cm, 2 m = 200 cm; đổi diện tích cần bình phương hệ số: 1 m² = 10.000 cm².', 'Trong phép nhân và chia, đơn vị có thể triệt tiêu như các thừa số. Kiểm tra đúng đơn vị là điều cần, chưa đủ để khẳng định một công thức đúng về vật lý.'],
    example: { prompt: 'Đổi 36 km/h sang m/s.', steps: ['Đổi 36 km thành 36.000 m.', 'Đổi 1 giờ thành 3.600 s.', '36.000 m / 3.600 s = 10 m/s.'], answer: '36 km/h = 10 m/s.' },
    reflection: 'Vì sao đổi từ cm² sang m² phải chia cho 10.000, trong khi đổi từ cm sang m chỉ chia cho 100?',
    source: { label: 'THCP: tham khảo cách dạy đơn vị và kiểm tra thứ nguyên; bài học do ứng dụng biên soạn.', chapter: '72, mục 72.2–72.5 và 72.7', part: 17, pages: 'PDF 63–68, 72–73 / trang in 1303–1308, 1312–1313' },
    makeQuestion: unitsQuestion,
  },
  {
    id: 'motion', domain: 'science', title: 'Đọc chuyển động', subtitle: 'Từ vị trí đến vận tốc và gia tốc', icon: 'activity', color: 'green', minutes: 15, level: 1,
    prerequisites: ['units', 'linear'], visual: 'graph',
    why: 'Hiểu chuyển động bắt đầu từ đọc bảng: đang ở đâu, sau bao lâu, thay đổi thế nào. Không cần thuộc một loạt công thức mới bắt đầu được.',
    concepts: ['Vị trí cho biết vật ở đâu so với một mốc đã chọn. Độ dời bằng vị trí cuối trừ vị trí đầu, có thể âm; quãng đường là tổng chiều dài đã đi, không âm.', 'Tốc độ trung bình = tổng quãng đường / tổng thời gian. Vận tốc trung bình theo trục = độ dời / thời gian. Dấu của vận tốc cho biết hướng.', 'Gia tốc mô tả sự thay đổi của véc tơ vận tốc theo thời gian. Khi đi tròn với tốc độ không đổi, hướng vẫn thay đổi nên vẫn có gia tốc.'],
    example: { prompt: 'Một xe đi thẳng từ x = 2 m đến x = 14 m trong 4 s. Tìm vận tốc trung bình.', steps: ['Chọn chiều dương theo trục đã cho.', 'Độ dời = 14 − 2 = 12 m.', 'Vận tốc trung bình = 12 / 4 = 3 m/s.'], answer: '3 m/s theo chiều dương. Chưa biết vận tốc ở từng thời điểm.' },
    reflection: 'Một người đi ra xa 5 m rồi quay về chỗ cũ. Quãng đường và độ dời có giống nhau không? Giải thích bằng lời.',
    source: { label: 'THCP: tham khảo mô hình chuyển động và véc tơ; bài tập được biên soạn mới.', chapter: '66, mục 66.1, 66.5–66.7', part: 15, pages: 'PDF 15–16, 40–45 / trang in 1095–1096, 1120–1125' },
    makeQuestion: motionQuestion,
  },
  {
    id: 'forces', domain: 'science', title: 'Lực làm thay đổi điều gì?', subtitle: 'Hợp lực, quán tính và gia tốc', icon: 'arrow', color: 'peach', minutes: 15, level: 1,
    prerequisites: ['motion', 'algebra'], visual: 'balance',
    why: 'Vẽ các lực trước khi tính giúp tránh lỗi “vật đang đi thì lực phải đẩy cùng chiều”. Lực tổng quyết định sự thay đổi vận tốc.',
    concepts: ['Lực có độ lớn và hướng. Hợp lực là tổng véc tơ của các lực tác dụng lên cùng vật. Hai lực cùng phương, ngược chiều cần trừ độ lớn.', 'Trong hệ quy chiếu quán tính với khối lượng không đổi: hợp lực F = m×a. Hợp lực bằng 0 thì vật có thể đứng yên hoặc tiếp tục chuyển động thẳng đều.', 'Với lò xo nằm ngang lý tưởng, trong giới hạn đàn hồi và không có lực ngang khác, x đo từ vị trí lò xo không biến dạng: F = −k×x. Dấu trừ chỉ lực ngược dấu độ biến dạng, không có nghĩa luôn ngược vận tốc. Khi treo lò xo thẳng đứng, vị trí cân bằng của vật không phải vị trí lò xo không biến dạng. Khối lượng dùng kg; trọng lượng là một lực, dùng N.'],
    example: { prompt: 'Một xe 2 kg chịu lực kéo 10 N sang phải và lực cản 4 N sang trái. Các lực đứng cân bằng. Tìm gia tốc ngang.', steps: ['Vẽ hai lực ngang ngược chiều.', 'Hợp lực = 10 − 4 = 6 N sang phải.', 'a = 6 N / 2 kg = 3 m/s² sang phải.'], answer: 'Gia tốc 3 m/s² sang phải; cần biết vận tốc ban đầu để mô tả chuyển động tiếp theo.' },
    reflection: 'Vì sao một vật đang chuyển động có thể chịu hợp lực bằng 0? Trong trường hợp đó điều gì giữ nguyên?',
    source: { label: 'THCP: tham khảo Newton và mô hình lò xo; diễn giải lực hồi phục được kiểm tra lại độc lập.', chapter: '66, mục 66.3–66.5 và 66.13.1', part: 15, pages: 'PDF 34–36, 40–41, 55 / trang in 1114–1116, 1120–1121, 1135' },
    makeQuestion: forcesQuestion,
  },
  {
    id: 'energy', domain: 'science', title: 'Theo dấu năng lượng', subtitle: 'Động năng, thế năng và sự chuyển đổi', icon: 'bolt', color: 'purple', minutes: 15, level: 1,
    prerequisites: ['units', 'exponents', 'forces'], visual: 'graph',
    why: 'Năng lượng cho một cách khác để hiểu thay đổi: dạng này giảm thì dạng khác có thể tăng. Đơn vị và giả thiết giúp tránh lẫn lực với năng lượng.',
    concepts: ['Động năng của vật chuyển động chậm so với ánh sáng là Eđ = m×v²/2; m tính bằng kg, v bằng m/s thì Eđ tính bằng J. Giữ khối lượng, tăng tốc độ gấp đôi làm động năng gấp bốn.', 'Gần mặt đất với g coi như không đổi, nâng một vật lên Δh làm thế năng tăng m×g×Δh. Một lực tính bằng N khác với năng lượng tính bằng J = N×m.', 'Trong hệ lò xo lý tưởng không có lực cản và không nhận công từ ngoài, cơ năng = động năng + thế năng không đổi. Nếu có ma sát, cơ năng có thể chuyển thành nội năng; không nói năng lượng toàn bộ tự biến mất.'],
    example: { prompt: 'Hệ lò xo lý tưởng có cơ năng 40 J. Lúc động năng là 15 J, thế năng là bao nhiêu?', steps: ['Nêu điều kiện: không lực cản, không công từ ngoài.', 'Cơ năng = động năng + thế năng.', 'Thế năng = 40 − 15 = 25 J.'], answer: '25 J. Hai dạng có thể đổi qua lại trong khi tổng vẫn là 40 J.' },
    reflection: 'Nếu vận tốc tăng gấp đôi mà khối lượng không đổi, vì sao động năng không chỉ gấp đôi? Dùng công thức rồi nói lại bằng lời.',
    source: { label: 'THCP: tham khảo trao đổi động năng–thế năng và kiểm tra đơn vị. Bài học được biên soạn mới.', chapter: '66, mục 66.13.1: Động năng và thế năng', part: 15, pages: 'PDF 58–59 / trang in 1138–1139' },
    makeQuestion: energyQuestion,
  },
  {
    id: 'chemistry', domain: 'science', title: 'Hóa học bắt đầu từ đếm', subtitle: 'Nguyên tử, cân bằng phản ứng và mol', icon: 'flask', color: 'blue', minutes: 15, level: 0,
    prerequisites: ['fractions', 'units'], visual: 'molecule',
    why: 'Đếm đúng hạt và đổi đơn vị nối kiến thức toán với hóa. Cân bằng phản ứng có ý nghĩa vì nguyên tử được sắp xếp lại, không phải một mẹo đổi các con số.',
    concepts: ['Nguyên tố là loại nguyên tử được xác định bởi số proton. Phân tử gồm các nguyên tử liên kết; H₂O có 2 nguyên tử H và 1 nguyên tử O. Hệ số 2H₂O chỉ hai phân tử; thay chỉ số dưới sẽ đổi chất.', 'Trong phản ứng hóa học thông thường, bảo toàn số nguyên tử từng nguyên tố giúp cân bằng phương trình. Ví dụ 2H₂ + O₂ → 2H₂O có 4 H và 2 O ở mỗi vế. Đối với hệ kín, tổng khối lượng trước và sau bằng nhau.', 'Mol là đơn vị lượng chất: 1 mol chứa đúng 6,02214076 × 10²³ thực thể đã chỉ rõ. Khối lượng mol M có đơn vị g/mol; n = m/M. Hệ số phản ứng cho tỉ lệ số hạt hoặc số mol, không trực tiếp cho tỉ lệ gam.'],
    example: { prompt: 'Có 36 g nước, với M(H₂O) = 18 g/mol. Có bao nhiêu mol phân tử nước, bao nhiêu mol nguyên tử H?', steps: ['Số mol phân tử nước = 36 / 18 = 2 mol.', 'Mỗi phân tử H₂O có 2 nguyên tử H.', 'Số mol nguyên tử H = 2 × 2 = 4 mol.'], answer: '2 mol phân tử H₂O và 4 mol nguyên tử H. Phải ghi rõ đang đếm loại hạt nào.' },
    reflection: 'Phân biệt 2H₂O và H₂O₂: mỗi cách viết có bao nhiêu H, bao nhiêu O và có cùng mô tả một chất không?',
    source: { label: 'THCP: tham khảo cách giải thích bảo toàn và mol. Các số liệu, đơn vị được kiểm tra lại; bài học mới không sao chép lỗi nguồn.', chapter: '71, mục 71.1–71.3 và 71.5', part: 17, pages: 'PDF 33–34, 36–38 / trang in 1273–1274, 1276–1278' },
    makeQuestion: chemistryQuestion,
  },
  {
    id: 'experiment', domain: 'science', title: 'Suy luận như nhà khoa học', subtitle: 'Đọc bảng, đối chứng và giới hạn kết luận', icon: 'microscope', color: 'green', minutes: 15, level: 0,
    prerequisites: ['numbers', 'statistics'], visual: 'experiment',
    why: 'Bạn có thể hiểu một tình huống sinh học hoặc hóa học mới bằng cách đọc mục tiêu, bảng dữ liệu và thiết kế thử nghiệm, ngay cả khi chưa biết mọi thuật ngữ.',
    concepts: ['Bắt đầu bằng câu hỏi và dự đoán có thể kiểm tra. Biến thay đổi là yếu tố ta chủ động điều chỉnh; biến kết quả là thứ ta đo. Các điều kiện khác cần giữ tương đương để tránh lẫn nguyên nhân.', 'Nhóm đối chứng là điểm so sánh phù hợp với câu hỏi. Phân mẫu ngẫu nhiên, lặp lại và giữ điều kiện tương đương giúp tăng chất lượng bằng chứng; chỉ lặp lại không sửa được mọi lỗi thiết kế.', 'Kết luận cần nằm trong dữ liệu. Trung bình nhóm cao hơn không có nghĩa mọi cá thể đều cao hơn. Hai đại lượng đi cùng nhau chưa tự chứng minh quan hệ nhân quả; cần xem cách lấy mẫu, biến nhiễu và độ phân tán.'],
    example: { prompt: 'Muốn biết thêm phân bón có làm cây tăng chiều cao hơn không, cần so sánh như thế nào?', steps: ['Chọn nhiều cây cùng loài, phân ngẫu nhiên vào hai nhóm.', 'Giữ nước, đất, ánh sáng và thời gian tương đương; chỉ một nhóm nhận phân bón.', 'Đo mức tăng chiều cao theo cùng cách; xem trung bình, độ phân tán và các giới hạn trước khi kết luận.'], answer: 'Chỉ thay yếu tố đang kiểm tra, giữ điểm so sánh công bằng và không khái quát vượt dữ liệu.' },
    reflection: 'Nếu hai nhóm vừa khác phân bón vừa khác lượng nước, vì sao chưa thể kết luận phân bón gây ra khác biệt?',
    source: { label: 'THCP: tham khảo cách đánh giá bằng chứng và thí nghiệm đối chứng. Các tình huống cây/enzyme và bảng số là dữ liệu giả định do ứng dụng viết.', chapter: '74, mục 74.14.5–74.14.6', part: 20, pages: 'PDF 5–8 / trang in 1485–1488' },
    makeQuestion: experimentQuestion,
  },
];
