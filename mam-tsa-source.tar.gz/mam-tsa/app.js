import { topics, domains } from './content.js';
import { STORAGE_KEY, defaultState, validateImport, recordAttempt, topicEvidence, recommendTopics, studyPlan, createQuestions, todayKey, sourceLabel } from './learning.js';
import { renderApp, h, icon } from './views.js';
import { prepareTutorPayload } from './ai.js';
import { openDurableStorage, readDurableState, writeDurableState, durableStorageAvailable } from './storage.js';

const app=document.getElementById('app'),modalRoot=document.getElementById('modal-root'),toastRoot=document.getElementById('toast-root');
let state=defaultState(),recovery=null,pendingImport=null,pendingStart=null,lastFocus=null,toastTimeout=null,storageReady=false,localSavedAt=0,durableRevision=0,saveQueue=Promise.resolve(),actionPending=false;
const ui={route:'today',filter:'all',notebookFilter:'notes',tutorTopic:'numbers',explore:{fraction:[true,true,true,false],number:2,slope:1,die:1,experiment:0},timer:{running:false,remaining:2700},api:{aiAvailable:false},warning:'',chatPending:false,standalone:Boolean(globalThis.__TSA_STANDALONE__)};
try {
  const raw=localStorage.getItem(STORAGE_KEY);
  localSavedAt=Number(localStorage.getItem(STORAGE_KEY+':savedAt'))||0;
  if(raw)try{state=validateImport(JSON.parse(raw));}catch(error){recovery=raw;ui.warning='Bản lưu cũ chưa đọc được. Hãy xuất bản lưu để giữ dữ liệu, rồi nhập bản sao lưu hợp lệ hoặc đặt lại.';}
}catch(error){ui.warning='Trình duyệt đang chặn lưu dữ liệu. Bạn vẫn học được và có thể xuất bản sao lưu trước khi đóng trang.';}
ui.timer.remaining=studyPlan(state.profile.dailyMinutes)[0].focus*60;

function storageConflict(){
  ui.storageConflict=true;ui.timer.running=false;
  ui.warning='Một thẻ khác đã lưu tiến độ mới hơn. Thẻ này đã dừng lưu để bảo vệ dữ liệu. Bạn có thể xuất bản đang mở trước khi tải lại bản mới nhất.';
  return false;
}
function persist(){
  if(!storageReady||ui.storageConflict)return Promise.resolve(false);
  if(recovery){ui.warning='Bản lưu cũ đang được giữ nguyên. Xuất dữ liệu để giữ bản gốc, rồi nhập bản sao lưu hợp lệ hoặc đặt lại.';return Promise.resolve(false);}
  // Capture each change now; serialize commits so rapid answers cannot race.
  const snapshot=structuredClone(state);
  const save=async()=>{
    if(ui.storageConflict)return false;
    let currentLocal=localSavedAt;
    try{currentLocal=Number(localStorage.getItem(STORAGE_KEY+':savedAt'))||0;}catch{}
    if(currentLocal>localSavedAt)return storageConflict();
    const savedAt=Math.max(Date.now(),localSavedAt+1,durableRevision+1);
    if(durableStorageAvailable()){
      const saved=await writeDurableState(snapshot,savedAt,durableRevision);
      if(saved){
        durableRevision=savedAt;
        // A rejected stale write must never enter the localStorage mirror.
        try{localStorage.setItem(STORAGE_KEY,JSON.stringify(snapshot));localStorage.setItem(STORAGE_KEY+':savedAt',String(savedAt));}catch{}
        localSavedAt=savedAt;ui.warning='';return true;
      }
      const latest=await readDurableState();
      if((latest?.savedAt||0)!==durableRevision)return storageConflict();
    }
    try{
      // This branch also supports browsers without IndexedDB. Web Locks, when
      // available, serialize this compare-and-write across browser tabs.
      const latest=Number(localStorage.getItem(STORAGE_KEY+':savedAt'))||0;
      if(latest>localSavedAt)return storageConflict();
      localStorage.setItem(STORAGE_KEY,JSON.stringify(snapshot));localStorage.setItem(STORAGE_KEY+':savedAt',String(savedAt));
      localSavedAt=savedAt;ui.warning='';return true;
    }catch{}
    ui.warning='Chưa lưu được thay đổi vào trình duyệt. Hãy xuất bản sao lưu trước khi đóng trang.';return false;
  };
  const commit=()=>navigator.locks?.request?navigator.locks.request('mam-tsa-save',save):save();
  const result=saveQueue.then(commit).catch(()=>{ui.warning='Chưa lưu được thay đổi. Hãy xuất bản sao lưu trước khi đóng trang.';return false;});
  saveQueue=result.then(()=>undefined);return result;
}
function toast(message,type='info'){
  clearTimeout(toastTimeout);
  toastRoot.innerHTML='<div class="toast '+h(type)+'">'+icon(type==='error'?'alert':'check')+'<span>'+h(message)+'</span></div>';
  toastTimeout=setTimeout(()=>{toastRoot.innerHTML='';},5000);
}
async function saveAndRender(message,submittedForm=null){const saved=await persist();render(saved?submittedForm:null);if(message)toast(saved?message:'Thay đổi đang giữ tạm trong phiên này. Hãy xuất bản sao lưu.',saved?'success':'error');}
function openChapterCheck(id){
  const topic=topics.find(t=>t.id===id);if(!topic)return;
  const draft=document.querySelector('form[data-form="reflection"] [name="text"]')?.value||'';
  openModal('Kiểm tra mức hiểu sau phần học','<p><strong>'+h(topic.title)+'</strong></p><p>Viết điều bạn hiểu, rồi thử 5 câu đổi dữ kiện. stem sẽ ghi riêng phần tự làm, phần cần gợi ý và lỗi cần sửa. Một lượt đúng chưa đủ xác nhận nhớ lâu; mình còn kiểm tra lại sau ít nhất 24 giờ.</p><form data-form="chapter-check" data-topic="'+h(id)+'"><label class="form-group" for="chapter-reflection">'+h(topic.reflection)+'<textarea id="chapter-reflection" class="form-control" name="text" required maxlength="10000" placeholder="Mình hiểu rằng… Mình còn băn khoăn… Nếu chưa rõ, cứ ghi điều đó.">'+h(draft)+'</textarea></label><p class="muted text-small">Phần viết giúp bạn tự nhìn lại; hiện chưa được tự động chấm đúng/sai.</p><div class="row" style="margin-top:16px"><button type="submit" class="btn btn-primary">Bắt đầu kiểm tra 5 câu</button>'+btn('close-modal','Để sau')+'</div></form>');
}
function route(){
  const hash=location.hash.slice(1);
  if(!hash)return'today';
  try{return decodeURIComponent(hash);}catch{return'not-found';}
}
function go(path){closeModal();if(location.hash==='#'+path){ui.route=path;render();window.scrollTo(0,0);}else location.hash=path;}
function formKey(form){return JSON.stringify([form.dataset.form,form.dataset.topic||'']);}
function captureFormDrafts(submittedForm){
  const drafts=new Map(),skip=submittedForm?formKey(submittedForm):null;
  for(const form of app.querySelectorAll('form[data-form]')){
    const key=formKey(form);if(key===skip)continue;
    const fields=[...form.elements].filter(field=>field.name&&['INPUT','TEXTAREA','SELECT'].includes(field.tagName)&&field.type!=='file');
    drafts.set(key,fields.map(field=>({name:field.name,type:field.type,value:field.value,checked:field.checked,focused:field===document.activeElement,start:field.selectionStart,end:field.selectionEnd})));
  }
  return drafts;
}
function restoreFormDrafts(drafts){
  for(const form of app.querySelectorAll('form[data-form]')){
    for(const draft of drafts.get(formKey(form))||[]){
      const field=[...form.elements].find(item=>item.name===draft.name&&item.type===draft.type);if(!field)continue;
      field.value=draft.value;if(['checkbox','radio'].includes(field.type))field.checked=draft.checked;
      if(draft.focused){field.focus({preventScroll:true});if(draft.start!==null&&draft.start!==undefined)try{field.setSelectionRange(draft.start,draft.end);}catch{}}
    }
  }
}
function render(submittedForm=null){
  const nextRoute=route(),drafts=ui.route===nextRoute?captureFormDrafts(submittedForm):new Map();
  ui.route=nextRoute;
  app.innerHTML=renderApp(state,ui);
  restoreFormDrafts(drafts);
  if(ui.route==='tutor'){
    const messages=document.querySelector('.chat-messages');
    if(messages)messages.scrollTop=messages.scrollHeight;
  }
  updateClocks();
}
function closeModal(){
  if(!modalRoot.children.length)return;
  modalRoot.innerHTML='';document.body.classList.remove('modal-open');
  if(lastFocus?.isConnected)lastFocus.focus();
}
function openModal(title,body,actions=''){
  lastFocus=document.activeElement;
  modalRoot.innerHTML='<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-header"><h2 id="modal-title">'+h(title)+'</h2><button type="button" class="icon-btn" data-action="close-modal" aria-label="Đóng hộp thoại">'+icon('close')+'</button></div><div class="modal-body">'+body+'</div>'+(actions?'<div class="modal-actions">'+actions+'</div>':'')+'</section></div>';
  document.body.classList.add('modal-open');
  setTimeout(()=>modalRoot.querySelector('input,textarea,select,button,a[href]')?.focus(),0);
}
function btn(action,label,primary=false,extra=''){return'<button type="button" class="btn '+(primary?'btn-primary':'btn-secondary')+'" data-action="'+action+'" '+extra+'>'+h(label)+'</button>';}
function download(text,name,type='application/json'){
  const url=URL.createObjectURL(new Blob([text],{type})),anchor=document.createElement('a');
  anchor.href=url;anchor.download=name;document.body.append(anchor);anchor.click();anchor.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);
}
function exportBackup(){
  if(recovery){openModal('Giữ lại bản lưu chưa đọc được','<p>Mình sẽ xuất nguyên bản dữ liệu cũ thành tệp văn bản để bạn không mất bản gốc. Tệp này chưa được xác nhận là bản sao lưu hợp lệ.</p>',btn('export-recovery','Xuất bản gốc',true)+btn('close-modal','Đóng'));return;}
  download(JSON.stringify({...state,exportedAt:new Date().toISOString()},null,2),'mam-tsa-sao-luu-'+todayKey()+'.json');
  toast('Đã tạo tệp sao lưu. Giữ tệp này để chuyển tiến độ sang thiết bị khác.');
}
async function importFile(file){
  if(!file)return;
  if(file.size>256*1024*1024){toast('Tệp quá lớn. Bản sao lưu cần nhỏ hơn 256 MB.','error');return;}
  try{
    pendingImport=validateImport(JSON.parse(await file.text()));
    openModal('Khôi phục tiến độ?','<p>Bản sao lưu có <strong>'+pendingImport.attempts.length+' lượt làm bài</strong>, '+pendingImport.notes.length+' ghi chú và lịch học '+pendingImport.profile.dailyMinutes+' phút/ngày.</p><p>Khôi phục sẽ thay thế dữ liệu hiện tại. Bạn có thể xuất bản hiện tại trước khi tiếp tục.</p>',btn('export','Xuất bản hiện tại')+btn('close-modal','Để sau')+btn('confirm-import','Khôi phục bản này',true));
  }catch(error){pendingImport=null;toast('Không nhập được: '+error.message,'error');}
}
async function beginAssessment(mode,topicId,replace=false){
  if(state.activeAssessment&&!replace){pendingStart={mode,topicId};openModal('Bạn đang có một bài luyện dở','<p>Các câu đã trả lời được lưu. Bạn muốn tiếp tục bài đang làm hay bắt đầu bài mới?</p>'+(topicId&&state.lessonReadAt?.[topicId]&&Date.parse(state.activeAssessment.startedAt)<Date.parse(state.lessonReadAt[topicId])?'<p>Bài đang dở bắt đầu trước lần đọc xong mới nhất. Bạn có thể làm tiếp, rồi mở một bài mới để kiểm tra kiến thức sau phần vừa học.</p>':''),btn('resume-assessment','Tiếp tục bài cũ',true)+btn('replace-assessment','Bắt đầu bài mới'));return;}
  try{
    const questions=createQuestions(topics,state,mode,topicId),now=new Date();
    state={...state,seed:state.seed+questions.length+13,activeAssessment:{id:'result-'+Date.now()+'-'+state.seed,mode,topicId:topicId||'',questions,index:0,results:[],startedAt:now.toISOString(),expiresAt:mode==='practice'?new Date(now.getTime()+15*60*1000).toISOString():null,selection:'',hintLevel:0,confidence:'medium',answered:false,lastCorrect:false,lastUnknown:false}};
    await persist();go('assessment');
  }catch(error){toast('Chưa mở được bài luyện: '+error.message,'error');}
}
async function answerQuestion(unknown=false){
  const a=state.activeAssessment;
  if(!a||a.answered)return;
  if(!unknown&&!a.selection){toast('Bạn chọn một câu trả lời trước nhé.','error');return;}
  const q=a.questions[a.index],answer=unknown?'__unknown':a.selection;
  state=recordAttempt(state,q,answer,{assessmentId:a.id,hintsUsed:a.hintLevel,confidence:unknown?'low':a.confidence,mode:a.mode});
  const correct=!unknown&&answer===q.answer,results=[...a.results];results[a.index]={correct,unknown};
  state.activeAssessment={...a,answered:true,lastCorrect:correct,lastUnknown:unknown,results};
  await persist();render();document.querySelector('.feedback')?.focus();
}
async function nextQuestion(){
  const a=state.activeAssessment;if(!a||!a.answered)return;
  if(a.index>=a.questions.length-1){await finishAssessment();return;}
  state.activeAssessment={...a,index:a.index+1,selection:'',hintLevel:0,confidence:'medium',answered:false,lastCorrect:false,lastUnknown:false};
  await persist();render();document.querySelector('.question-card')?.focus();window.scrollTo(0,0);
}
async function finishAssessment(expired=false){
  const a=state.activeAssessment;if(!a)return;
  const results=[...a.results];
  for(let i=0;i<a.questions.length;i++)if(!results[i]){
    results[i]={correct:false,unknown:true};
    if(expired)state=recordAttempt(state,a.questions[i],'__unknown',{assessmentId:a.id,mode:a.mode,confidence:'low'});
  }
  const result={id:a.id||'result-'+Date.now()+'-'+state.assessments.length,mode:a.mode,topicId:a.topicId||'',startedAt:a.startedAt,at:new Date().toISOString(),correct:results.filter(r=>r.correct).length,total:a.questions.length,unknown:results.filter(r=>r.unknown).length,seconds:Math.max(0,Math.round((Date.now()-Date.parse(a.startedAt))/1000))};
  state={...state,activeAssessment:null,assessments:[...state.assessments,result]};
  await persist();go('results/'+result.id);if(expired)toast('Hết thời gian. Các câu chưa làm được ghi riêng trong kết quả.');
}
function contextTopic(){return topics.find(t=>t.id===ui.tutorTopic)||topics[0];}
function guidedReply(message,topic){
  const text=message.toLocaleLowerCase('vi'),ev=topicEvidence(state,topic.id);
  if(/kiểm tra|hỏi mình|bài tập|tự làm/.test(text))return'Để kiểm tra '+topic.title.toLowerCase()+', mình sẽ đưa 5 câu với số hoặc bối cảnh khác. Bạn bấm “Tự kiểm tra chủ đề này” bên dưới. Mình sẽ ghi riêng câu tự làm, câu dùng gợi ý và câu chưa học; chưa suy ra mức hiểu từ một câu đúng.';
  if(/ví dụ|minh họa/.test(text))return topic.example.prompt+'\n\n'+topic.example.steps.join('\n')+'\n\nBây giờ bạn thử nói lại: '+topic.reflection;
  if(/lộ trình|hôm nay|ôn lại|kế hoạch/.test(text)){
    const recommended=recommendTopics(state,topics).slice(0,3);
    return'Hôm nay bạn có '+state.profile.dailyMinutes+' phút. Mình đề xuất ba phiên có nghỉ: '+studyPlan(state.profile.dailyMinutes).map(p=>p.focus+' phút học + '+p.rest+' phút nghỉ').join('; ')+'.\n\nƯu tiên hiện tại: '+recommended.map(t=>t.title).join(' → ')+'. Các đề xuất dựa trên bài làm đã lưu; khi chưa đủ dữ liệu, mình bắt đầu từ nền tảng.';
  }
  if(/90|điểm|tsa/.test(text))return'Mục tiêu của bạn là TSA 90+ vào tháng 5/2027. Những bài ở đây là bài tự biên soạn để học và tìm lỗ hổng. Tỉ lệ đúng hay mức nắm vững trong ứng dụng chưa được hiệu chuẩn thành điểm TSA. Mình sẽ theo dõi việc tự làm, dùng gợi ý, vận dụng và nhớ lại; điểm thi cần đo bằng đề phù hợp đã được thẩm định.';
  if(/sai|khó|chưa hiểu|không hiểu/.test(text))return'Mình chia nhỏ phần này nhé. '+topic.concepts[0]+'\n\nHãy thử bước đầu: '+topic.example.steps[0]+'\n\nChỗ nào trong bước đó làm bạn vướng? Bạn có thể mở bài học và dùng gợi ý từng tầng. Hiện có '+ev.independent+' câu bạn tự làm đúng ở chủ đề này.';
  return topic.concepts.slice(0,2).join('\n\n')+'\n\nBạn thử giải thích bằng lời của mình: '+topic.reflection+'\n\nĐây là hướng dẫn có sẵn theo chủ đề, chưa phải phản hồi của AI trực tuyến.';
}
async function sendTutor(message,submittedForm=null){
  const text=String(message||'').trim();if(!text||ui.chatPending)return;
  if(text.length>3000){toast('Bạn chia câu hỏi thành đoạn dưới 3.000 ký tự nhé.','error');return;}
  const topic=contextTopic(),history=state.chat.slice(-12).map(m=>({role:m.role,content:m.content}));
  const payload=prepareTutorPayload(text,topic,history);
  state.chat=[...state.chat,{role:'user',content:text,mode:'guided'}].slice(-30);submittedForm?.reset();ui.chatPending=true;await persist();render();
  let reply,mode='guided';
  if(ui.api.aiAvailable&&state.profile.aiConsent&&!ui.standalone){
    try{
      const response=await fetch('/api/tutor',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(30000)});
      const data=await response.json();
      if(!response.ok)throw new Error(data.message||'Kết nối AI chưa sẵn sàng.');
      reply=data.reply;mode='online';
    }catch(error){reply='Lần này chưa nhận được phản hồi AI. Mình chuyển sang hướng dẫn có sẵn:\n\n'+guidedReply(text,topic);toast('Kết nối AI chưa thành công; hướng dẫn có sẵn vẫn dùng được.','error');}
  }else reply=guidedReply(text,topic);
  state.chat=[...state.chat,{role:'assistant',content:reply,mode}].slice(-30);ui.chatPending=false;await persist();render();document.querySelector('[data-form="chat"] [name="message"]')?.focus();
}
function openSources(){
  openModal('Nền tảng của góc học này','<p><strong>Toán Học Chân Phương</strong> — Nguyễn Vĩnh Phú, bản 2022–2026: nguồn tham khảo cách học và kiến thức. Đã lập chỉ mục 2.224 trang, đọc sâu có chọn lọc các phần phục vụ người mới.</p><ul><li>Chương 24, 38, 39 và 52: học chủ động, giả thuyết–kiểm chứng, giải thích lại và nền tảng số học.</li><li>Chương 53–65: đại số, hình, đồ thị và phản tư sau lời giải.</li><li>Chương 66, 71, 72, 74: vật lý, hóa cơ bản, đơn vị và xác suất.</li><li>Phụ lục 75.A: kiểm tra từng bước, điều kiện và khả năng vận dụng.</li></ul><p>Bài học, hình tương tác và câu hỏi trong ứng dụng được viết mới. Phạm vi hiện tại là 21 chủ đề nền tảng. Bài đọc là văn bản tự biên soạn.</p><p>Các bài luyện chưa được hiệu chuẩn theo thang điểm TSA. Mục tiêu tháng 5/2027 là mốc cá nhân bạn đặt. Cấu trúc và lịch thi cần đối chiếu thông báo chính thức.</p><p>Việc tham khảo trực tiếp Brilliant và trang TSA chính thức đang bị giới hạn truy cập mạng; chưa dùng chúng làm bằng chứng đã đối chiếu.</p>',btn('close-modal','Mình hiểu rồi',true));
}
function openAIInfo(){
  openModal('Hai cách hỗ trợ bạn học','<p><strong>Hướng dẫn có sẵn:</strong> dùng ngay, hoạt động trên thiết bị; chọn ví dụ, giải thích theo chủ đề và đề xuất ôn tập từ kết quả đã lưu. Cách này chưa tự chấm đúng/sai phần bạn giải thích bằng lời.</p><p><strong>AI trực tuyến:</strong> cần một khóa API được thêm bảo mật trong cài đặt môi trường với tên <code>TSA_AI_API_KEY</code>, rồi khởi động lại máy chủ. Không nhập khóa vào câu hỏi hay gửi khóa trong chat.</p><p>Khi kết nối sẵn sàng, bạn có thể bật quyền gửi câu hỏi ở phần Cài đặt. Câu hỏi và ngữ cảnh bài học sẽ được gửi tới nhà cung cấp AI; bạn chủ động chọn việc này.</p><p>AI có thể trả lời sai. Hãy kiểm tra điều kiện, phép tính và đối chiếu lời giải.</p>',btn('close-modal','Đóng',true));
}
function openSearch(){
  openModal('Bạn muốn hiểu điều gì?','<label class="form-group" for="topic-search">Tìm chủ đề<input id="topic-search" class="form-control" type="search" placeholder="Phân số, chuyển động, đọc hiểu…" autocomplete="off"></label><div id="search-results"></div>');
  updateSearch('');
}
function updateSearch(value){
  const normalize=v=>v.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').toLowerCase();
  const query=normalize(value),matches=topics.filter(t=>normalize(t.title+' '+t.subtitle+' '+domains[t.domain].title).includes(query));
  const target=document.getElementById('search-results');if(target)target.innerHTML=matches.length?matches.map(t=>'<a class="search-result row" href="#learn/'+h(t.id)+'">'+icon(domains[t.domain].icon)+'<span>'+h(t.title)+'</span>'+icon('arrow')+'</a>').join(''):'<p class="empty-state">Chưa tìm thấy. Bạn thử tên ngắn hơn nhé.</p>';
}
async function flushStudyTime(){if(unsavedSeconds>0){unsavedSeconds=0;await persist();}}
async function resetTimer(){ui.timer.running=false;ui.timer.remaining=studyPlan(state.profile.dailyMinutes)[0].focus*60;await flushStudyTime();render();}
function updateClocks(){
  const whole=Math.max(0,Math.ceil(ui.timer.remaining)),m=Math.floor(whole/60),s=whole%60,value=String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
  document.querySelectorAll('[data-focus-timer]').forEach(el=>{el.textContent=value;});
  document.querySelectorAll('[data-study-minutes]').forEach(el=>{el.textContent=Math.floor((state.studySeconds[todayKey()]||0)/60);});
  const active=state.activeAssessment;
  document.querySelectorAll('[data-assessment-timer]').forEach(el=>{const seconds=active?.expiresAt?Math.max(0,Math.ceil((Date.parse(active.expiresAt)-Date.now())/1000)):0;el.textContent=String(Math.floor(seconds/60)).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0');});
}

document.addEventListener('click',async event=>{
  if(event.target.closest('.skip-link')){event.preventDefault();document.getElementById('main-content')?.focus();return;}
  const element=event.target.closest('[data-action]');
  if(!element){if(event.target.classList.contains('modal-backdrop'))closeModal();return;}
  const action=element.dataset.action;
  if(element.disabled)return;
  const mutation=['start-assessment','replace-assessment','choose-answer','confidence','submit-answer','unknown','next-question','hint','complete-lesson','confirm-delete-note','timer-toggle','timer-reset','tutor-preset','confirm-import','confirm-reset','retry-error'].includes(action);
  if(mutation&&(actionPending||ui.storageConflict)){toast(ui.storageConflict?'Hãy xuất bản đang mở rồi tải lại tiến độ mới nhất.':'Đang lưu thay đổi, bạn chờ một chút nhé.','error');return;}
  if(mutation){actionPending=true;element.disabled=true;}
  try{
    switch(action){
      case'close-modal':closeModal();break;
      case'search':openSearch();break;
      case'sources':openSources();break;
      case'ai-info':openAIInfo();break;
      case'mobile-more':openModal('Góc học tập của bạn','<nav class="stack" aria-label="Các mục học tập khác"><a class="btn btn-secondary" href="#today">Hôm nay</a><a class="btn btn-secondary" href="#roadmap">Khóa học</a><a class="btn btn-secondary" href="#progress">Tiến bộ</a><a class="btn btn-secondary" href="#assess">Kiểm tra hiểu</a><a class="btn btn-secondary" href="#notebook">Sổ tay của mình</a><a class="btn btn-secondary" href="#tutor">Bạn đồng hành</a><a class="btn btn-secondary" href="#settings">Cài đặt & dữ liệu</a></nav>',btn('close-modal','Đóng'));break;
      case'filter':ui.filter=element.dataset.domain||'all';render();break;
      case'notebook-filter':ui.notebookFilter=element.dataset.value||'notes';ui.journalPage=0;render();break;
      case'journal-page':ui.journalPage=Math.max(0,Number(element.dataset.value)||0);render();break;
      case'start-assessment':await beginAssessment(element.dataset.mode||'topic',element.dataset.topic);break;
      case'resume-assessment':go('assessment');break;
      case'replace-assessment':if(pendingStart){const p=pendingStart;pendingStart=null;closeModal();await beginAssessment(p.mode,p.topicId,true);}break;
      case'choose-answer':if(state.activeAssessment&&!state.activeAssessment.answered){state.activeAssessment.selection=element.dataset.value;await persist();render();}break;
      case'confidence':if(state.activeAssessment&&!state.activeAssessment.answered){state.activeAssessment.confidence=element.dataset.value;await persist();render();}break;
      case'submit-answer':await answerQuestion();break;
      case'unknown':await answerQuestion(true);break;
      case'next-question':await nextQuestion();break;
      case'hint':{const a=state.activeAssessment;if(a&&!a.answered){a.hintLevel=Math.min(a.hintLevel+1,a.questions[a.index].hints.length);await persist();render();}break;}
      case'quit-assessment':openModal('Dừng một chút nhé?','<p>Câu trả lời đã làm được lưu. Bạn có thể quay lại tiếp tục bài này từ mục Kiểm tra. Với bài có đồng hồ, thời gian vẫn chạy.</p>',btn('close-modal','Học tiếp',true)+btn('leave-assessment','Lưu và rời bài'));break;
      case'leave-assessment':go('assess');break;
      case'complete-lesson':{const id=element.dataset.topic;if(!state.completedLessons.includes(id))state.completedLessons.push(id);state.lessonReadAt={...state.lessonReadAt,[id]:new Date().toISOString()};await saveAndRender();if(!ui.storageConflict)openChapterCheck(id);break;}
      case'retry-error':await beginAssessment('topic',element.dataset.topic);break;
      case'delete-note':{const id=element.dataset.id;openModal('Xóa ghi chú này?','<p>Ghi chú này sẽ được xóa khỏi bản lưu trên thiết bị. Các bài làm và ghi chú khác vẫn được giữ.</p>',btn('close-modal','Giữ lại')+btn('confirm-delete-note','Xóa ghi chú',true,'data-id="'+h(id)+'"'));break;}
      case'confirm-delete-note':state.notes=state.notes.filter(n=>n.id!==element.dataset.id);closeModal();await saveAndRender('Đã xóa ghi chú.');break;
      case'timer-toggle':ui.timer.running=!ui.timer.running;lastTick=performance.now();await flushStudyTime();render();break;
      case'timer-reset':await resetTimer();toast('Đã đặt lại đồng hồ phiên. Thời gian đã học vẫn được giữ.');break;
      case'fraction-piece':{const i=Number(element.dataset.index);if(i>=0&&i<4){ui.explore.fraction[i]=!ui.explore.fraction[i];render();}break;}
      case'roll-die':ui.explore.die=1+Math.floor(Math.random()*6);render();break;
      case'experiment-toggle':ui.explore.experiment=ui.explore.experiment?0:1;render();break;
      case'tutor-preset':await sendTutor(element.dataset.message);break;
      case'export':exportBackup();break;
      case'reload-latest':location.reload();break;
      case'export-recovery':download(recovery||'','mam-tsa-ban-goc-can-khoi-phuc.txt','text/plain');closeModal();break;
      case'import':{let input=document.getElementById('backup-file');if(!input){input=document.createElement('input');input.type='file';input.id='backup-file';input.accept='.json,application/json';input.hidden=true;document.body.append(input);input.addEventListener('change',async()=>{await importFile(input.files?.[0]);input.value='';});}input.click();break;}
      case'confirm-import':if(pendingImport){state=pendingImport;pendingImport=null;recovery=null;ui.warning='';ui.timer.running=false;ui.timer.remaining=studyPlan(state.profile.dailyMinutes)[0].focus*60;closeModal();await saveAndRender('Đã khôi phục tiến độ từ bản sao lưu.',app.querySelector('form[data-form="settings"]'));}break;
      case'reset-data':openModal('Bắt đầu lại từ đầu?','<p>Thao tác này xóa bài làm, ghi chú và lịch học trên thiết bị này. Bạn nên xuất bản sao lưu trước khi đặt lại.</p>',btn('export','Xuất bản sao lưu')+btn('close-modal','Giữ dữ liệu')+btn('confirm-reset','Xóa và bắt đầu lại',true));break;
      case'confirm-reset':state=defaultState();recovery=null;ui.warning='';ui.timer.running=false;ui.timer.remaining=studyPlan(150)[0].focus*60;closeModal();await saveAndRender('Đã bắt đầu lại với lịch 150 phút/ngày.');go('today');break;
      case'download-standalone':{
        if(ui.standalone&&(location.protocol==='file:'||!navigator.onLine)){toast('Bạn đang dùng bản HTML ngoại tuyến. Hãy giữ tệp này cùng bản sao lưu tiến độ.');break;}
        const sourceURL=new URL(ui.standalone?location.href:'/dist/mam-tsa.html',location.href);sourceURL.hash='';
        const response=await fetch(sourceURL);if(!response.ok)throw new Error('Chưa tải được bản HTML. Bạn hãy thử lại khi có mạng.');
        const html=await response.text();if(!html.includes('__TSA_STANDALONE__'))throw new Error('Tệp trả về chưa phải bản ứng dụng ngoại tuyến. Bạn hãy thử lại sau.');
        download(html,'mam-tsa.html','text/html');toast('Đã tạo tệp HTML dùng ngoại tuyến. Dữ liệu giữa hai bản được chuyển bằng sao lưu.');break;
      }
      default:toast('Tác vụ này chưa được nhận diện. Bạn thử mở lại trang nhé.','error');
    }
  }catch(error){toast(error.message||'Thao tác chưa thành công. Dữ liệu đã lưu vẫn được giữ.','error');}
  finally{if(mutation){actionPending=false;if(element.isConnected)element.disabled=false;}}
});
document.addEventListener('submit',async event=>{
  const form=event.target.closest('[data-form]');if(!form)return;event.preventDefault();
  if(!form.reportValidity())return;
  if(actionPending||ui.storageConflict){toast(ui.storageConflict?'Hãy xuất bản đang mở rồi tải lại tiến độ mới nhất.':'Đang lưu thay đổi, bạn chờ một chút nhé.','error');return;}
  actionPending=true;
  const data=new FormData(form);
  const submitter=event.submitter,originalLabel=submitter?.innerHTML;
  if(submitter){submitter.disabled=true;submitter.textContent='Đang lưu…';}
  form.setAttribute('aria-busy','true');
  try{
  switch(form.dataset.form){
    case'settings':{
      const minutes=Number(data.get('dailyMinutes')),month=String(data.get('targetMonth')||'');
      if(!Number.isFinite(minutes)||minutes<15||minutes>480||!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)){toast('Bạn kiểm tra lại thời gian và tháng mục tiêu nhé.','error');return;}
      state.profile={name:String(data.get('name')||'').trim().slice(0,60),dailyMinutes:Math.round(minutes),targetMonth:month,aiConsent:data.get('aiConsent')==='on'&&ui.api.aiAvailable&&!ui.standalone};
      if(!ui.timer.running)ui.timer.remaining=studyPlan(minutes)[0].focus*60;
      await saveAndRender('Đã cập nhật lịch học của bạn.',form);break;
    }
    case'note':{
      const text=String(data.get('text')||'').trim();if(!text){toast('Bạn viết một ý muốn ghi nhớ trước nhé.','error');return;}
      state.notes.unshift({id:'note-'+Date.now()+'-'+state.notes.length,text:text.slice(0,10000),topicId:String(data.get('topicId')||''),at:new Date().toISOString()});
      ui.journalPage=0;await saveAndRender('Đã lưu ghi chú vào sổ hiểu biết.',form);break;
    }
    case'reflection':{
      const text=String(data.get('text')||'').trim();if(!text){toast('Bạn thử viết bằng lời của mình nhé.','error');return;}
      state.reflections.unshift({id:'reflection-'+Date.now()+'-'+state.reflections.length,topicId:form.dataset.topic||'',text:text.slice(0,10000),at:new Date().toISOString()});
      await saveAndRender('Đã lưu phần tự giải thích. Nội dung này chưa được chấm đúng/sai tự động.',form);break;
    }
    case'chapter-check':{
      const text=String(data.get('text')||'').trim(),id=form.dataset.topic;if(!text||!topics.some(t=>t.id===id))return;
      state.reflections.unshift({id:'reflection-'+Date.now()+'-'+state.reflections.length,topicId:id,text:text.slice(0,10000),at:new Date().toISOString()});
      const saved=await persist();if(ui.storageConflict){closeModal();render();return;}
      if(!saved)toast('Phần viết chưa lưu được. Hãy xuất bản sao lưu trước khi đóng trang.','error');
      closeModal();await beginAssessment('topic',id);break;
    }
    case'chat':await sendTutor(data.get('message'),form);break;
  }
  }finally{
    actionPending=false;
    if(form.isConnected)form.removeAttribute('aria-busy');
    if(submitter?.isConnected){submitter.disabled=false;submitter.innerHTML=originalLabel;}
  }
});
document.addEventListener('input',event=>{
  if(event.target.id==='topic-search')updateSearch(event.target.value);
  if(event.target.id==='number-slider'||event.target.id==='slope-slider'){
    ui.explore[event.target.id==='number-slider'?'number':'slope']=Number(event.target.value);
    const oldFocus=document.activeElement?.id;render();const restored=oldFocus&&document.getElementById(oldFocus);restored?.focus();
  }
});
document.addEventListener('change',event=>{if(event.target.id==='tutor-topic'){ui.tutorTopic=event.target.value;render();}});
document.addEventListener('keydown',event=>{
  if(!modalRoot.children.length)return;
  if(event.key==='Escape'){event.preventDefault();closeModal();}
  if(event.key==='Tab'){
    const elements=[...modalRoot.querySelectorAll('button:not([disabled]),a[href],input:not([disabled]),textarea,select')].filter(el=>el.offsetParent!==null);
    const first=elements[0],last=elements.at(-1);
    if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus();}
    else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}
  }
});
window.addEventListener('hashchange',()=>{closeModal();render();window.scrollTo(0,0);document.getElementById('main-content')?.focus({preventScroll:true});});
window.addEventListener('pagehide',()=>{flushStudyTime();});
window.addEventListener('storage',event=>{if(storageReady&&event.key===STORAGE_KEY+':savedAt'&&Number(event.newValue)>localSavedAt){storageConflict();render();}});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&ui.timer.running){ui.timer.running=false;flushStudyTime();render();toast('Đồng hồ tập trung đã tạm dừng khi bạn rời trang.');}});
let lastTick=performance.now(),unsavedSeconds=0;
setInterval(()=>{
  const now=performance.now(),delta=Math.min(2,Math.max(0,(now-lastTick)/1000));lastTick=now;
  if(!storageReady)return;
  if(ui.timer.running&&!document.hidden){
    const seconds=Math.min(delta,ui.timer.remaining);ui.timer.remaining=Math.max(0,ui.timer.remaining-seconds);
    const key=todayKey();state.studySeconds[key]=Math.min(86400,(state.studySeconds[key]||0)+seconds);unsavedSeconds+=seconds;
    if(ui.timer.remaining<=0){ui.timer.running=false;persist();render();toast('Bạn vừa hoàn thành một phiên tập trung. Nghỉ 5 phút rồi quay lại nhé!');}
    if(unsavedSeconds>=10){persist();unsavedSeconds=0;}
  }
  if(!actionPending&&!ui.storageConflict&&state.activeAssessment?.expiresAt&&Date.parse(state.activeAssessment.expiresAt)<=Date.now()){actionPending=true;finishAssessment(true).finally(()=>{actionPending=false;});}
  updateClocks();
},1000);
async function checkAI(){
  if(ui.standalone||location.protocol==='file:')return;
  try{const response=await fetch('/api/status',{signal:AbortSignal.timeout(5000)});if(response.ok){const result=await response.json();ui.api={aiAvailable:result.aiAvailable===true};if(['settings','tutor'].includes(route()))render();}}catch{ui.api={aiAvailable:false};}
}
async function initialize(){
  if(await openDurableStorage()){
    const saved=await readDurableState();
    durableRevision=saved?.savedAt||0;
    if(saved&&(saved.savedAt>localSavedAt||recovery)){
      localSavedAt=saved.savedAt;
      try{state=validateImport(saved.state);recovery=null;ui.warning='';}
      catch{ui.warning='Bản lưu dài hạn chưa đọc được. Bản dữ liệu dự phòng đang được giữ để bạn xuất ra.';}
    }
  }
  storageReady=true;ui.timer.remaining=studyPlan(state.profile.dailyMinutes)[0].focus*60;
  render();checkAI();
}
initialize().catch(()=>{storageReady=true;ui.warning='Không mở được kho lưu dài hạn. Hãy dùng xuất dữ liệu để giữ một bản riêng.';render();checkAI();});
