// Keep the browser's live-AI request within the server's documented byte limits.
export function prepareTutorPayload(message,topic,chat=[]){
  const trim=(value,limit)=>String(value??'').slice(0,limit);
  const payload={
    message:trim(message,3000),
    context:{topicTitle:trim(topic.title,150),concepts:(topic.concepts||[]).slice(0,2).map(v=>trim(v,600)),
      hints:(topic.example?.steps||[]).slice(0,2).map(v=>trim(v,350)),
      prompt:trim(topic.example?.prompt,700),explanation:trim(topic.example?.answer,700)},
    history:chat.filter(m=>['user','assistant'].includes(m.role)).slice(-12).map(m=>({role:m.role,content:trim(m.content,2000)}))
  };
  const bytes=()=>new TextEncoder().encode(JSON.stringify(payload)).byteLength;
  while(payload.history.length&&bytes()>28*1024)payload.history.shift();
  if(bytes()>28*1024)throw new Error('Câu hỏi và ngữ cảnh quá dài. Bạn chia câu hỏi thành một ý nhỏ hơn nhé.');
  return payload;
}
