"""Exercise durable storage in real Chromium, with no application server needed.

Run: python tools/storage-check.py
Requires the same Python Playwright + system Chromium as acceptance.py.
The temporary HTTP server and fresh browser context never touch learner data.
"""
import asyncio
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import shutil
from threading import Thread

from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parents[1]


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/storage.js":
            body = (ROOT / "storage.js").read_bytes()
            mime = "text/javascript"
        else:
            body = b"<!doctype html><title>Isolated storage test</title>"
            mime = "text/html"
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *_):
        pass


async def main():
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    Thread(target=server.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{server.server_port}"
    try:
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(
                executable_path=shutil.which("chromium"),
                args=["--no-sandbox"],
            )
            context = await browser.new_context()
            page = await context.new_page()
            await page.goto(base)
            await page.evaluate("async () => window.storage = await import('/storage.js')")
            result = await page.evaluate("""async () => {
              const s = window.storage;
              if (!await s.openDurableStorage() || !s.durableStorageAvailable()) throw Error('open');
              if (await s.readDurableState() !== null) throw Error('empty');
              let quotaReached = false;
              try { localStorage.setItem('quota-test', 'x'.repeat(8 * 1024 * 1024)); }
              catch (error) { quotaReached = error.name === 'QuotaExceededError'; }
              if (!quotaReached) throw Error('localStorage quota was not reached');
              const large = {attempts: [], payload: 'x'.repeat(8 * 1024 * 1024), nested: {value: 1}};
              const firstSave = s.writeDurableState(large, 100);
              large.nested.value = 2;
              if (!await firstSave) throw Error('large save');
              const restored = await s.readDurableState();
              if (restored.state.payload.length !== 8 * 1024 * 1024 || restored.state.nested.value !== 1)
                throw Error('large save or snapshot changed');
              restored.state.nested.value = 99;
              if ((await s.readDurableState()).state.nested.value !== 1) throw Error('read returned mutable storage');
              return {quotaReached, largeBytes: large.payload.length};
            }""")
            await page.reload()
            assert await page.evaluate("""async () => {
              window.storage = await import('/storage.js');
              const record = await storage.readDurableState();
              return record.savedAt === 100 && record.state.payload.length === 8 * 1024 * 1024 &&
                record.state.nested.value === 1;
            }""")
            assert await page.evaluate("""async () => {
              const s = storage;
              const saves = Array.from({length: 50}, (_, n) => s.writeDurableState({order: n}, 101 + n));
              if (!(await Promise.all(saves)).every(Boolean)) throw Error('ordered save rejected');
              if ((await s.readDurableState()).state.order !== 49) throw Error('queue order');
              if (await s.writeDurableState({order: -1}, 149)) throw Error('stale timestamp accepted');
              if (!await s.writeDurableState({order: 50}, 150)) throw Error('equal timestamp rejected');
              if (await s.writeDurableState({bad: () => 1}, 151)) throw Error('uncloneable accepted');
              return true;
            }""")
            await page.reload()
            restored = await page.evaluate("""async () => {
              window.storage = await import('/storage.js');
              return await storage.readDurableState();
            }""")
            assert restored == {"state": {"order": 50}, "savedAt": 150}, restored

            # The timestamp check lives inside the read/write transaction, so a
            # second tab cannot accidentally overwrite a newer persisted record.
            second = await context.new_page()
            await second.goto(base)
            assert await second.evaluate("""async () => {
              const s = await import('/storage.js');
              return await s.writeDurableState({order: 51}, 151);
            }""")
            assert await page.evaluate("storage.writeDurableState({order: -1}, 150)") is False
            assert await page.evaluate("(async () => (await storage.readDurableState()).state.order)()") == 51
            # Both tabs start from exactly the same revision. Their independent
            # read/write transactions must produce one winner, not last-wins.
            contenders = await asyncio.gather(
                page.evaluate("storage.writeDurableState({winner: 'first'}, 153, 151)"),
                second.evaluate("(async () => (await import('/storage.js')).writeDurableState({winner: 'second'}, 153, 151))()"),
            )
            assert sorted(contenders) == [False, True], contenders
            winner = "first" if contenders[0] else "second"
            assert await page.evaluate("(async () => (await storage.readDurableState()).state.winner)()") == winner
            assert await page.evaluate("storage.writeDurableState({stale: true}, 154, 151)") is False
            assert await page.evaluate("storage.writeDurableState({next: true}, 154, 153)") is True
            await second.close()
            assert await page.evaluate("""async () => {
              const s = storage;
              const pending = s.writeDurableState({pending: true}, 155, 154);
              const clear = s.clearDurableState();
              return await pending && await clear && await s.readDurableState() === null;
            }""")
            assert await page.evaluate("storage.writeDurableState({fresh: true}, 156, 0)") is True
            assert await page.evaluate("storage.writeDurableState({stale: true}, 157, 0)") is False

            # An explicitly aborted browser transaction reports failure, keeps
            # the preceding record and does not break the following save.
            assert await page.evaluate("""async () => {
              await storage.writeDurableState({safe: true}, 200);
              const put = IDBObjectStore.prototype.put;
              IDBObjectStore.prototype.put = function(...args) {
                const request = put.apply(this, args); this.transaction.abort(); return request;
              };
              let rejected;
              try { rejected = !await storage.writeDurableState({safe: false}, 201); }
              finally { IDBObjectStore.prototype.put = put; }
              return rejected && (await storage.readDurableState()).state.safe &&
                await storage.writeDurableState({recovered: true}, 202);
            }""")
            await context.close()

            unsupported = await browser.new_context()
            page = await unsupported.new_page()
            await page.goto(base)
            assert await page.evaluate("""async () => {
              Object.defineProperty(globalThis, 'indexedDB', {value: undefined});
              const s = await import('/storage.js');
              return !await s.openDurableStorage() && !s.durableStorageAvailable() &&
                await s.readDurableState() === null && !await s.writeDurableState({x: 1}) &&
                !await s.clearDurableState();
            }""")
            await unsupported.close()

            # A pending database deletion held by another connection also blocks
            # open(). Confirm the UI startup deadline in the real browser.
            blocked = await browser.new_context()
            page = await blocked.new_page()
            await page.goto(base)
            blocked_result = await page.evaluate("""async () => {
              const held = await new Promise((resolve, reject) => {
                const request = indexedDB.open('mam-tsa', 1);
                request.onsuccess = () => resolve(request.result);
                request.onerror = () => reject(Error('test database'));
              });
              const deletion = indexedDB.deleteDatabase('mam-tsa');
              await new Promise(resolve => { deletion.onblocked = resolve; });
              const s = await import('/storage.js');
              const started = performance.now();
              const success = await s.openDurableStorage();
              const elapsed = performance.now() - started;
              held.close();
              await new Promise(resolve => { deletion.onsuccess = resolve; });
              return {success, elapsed};
            }""")
            assert blocked_result["success"] is False, blocked_result
            assert blocked_result["elapsed"] < 2000, blocked_result
            await blocked.close()
            await browser.close()
            print({**result, "orderedWrites": 50, "largeReload": "passed", "reload": "passed", "crossTab": "passed", "compareAndSwap": "one winner; stale base rejected; absent base works", "clear": "passed",
                   "transactionRecovery": "passed", "unsupported": "passed", "blockedOpen": blocked_result})
    finally:
        server.shutdown()
        server.server_close()


if __name__ == "__main__":
    asyncio.run(main())
