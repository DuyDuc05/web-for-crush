"""Real-browser UI regression for years of data and optional storage support.

Usage: python tools/storage-integration.py --base-url http://127.0.0.1:3001
Uses isolated browser contexts; never imports into the user's browser profile.
"""
import argparse
import asyncio
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
import tempfile
import traceback

from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parents[1]
STORAGE_KEY = "mam-tsa-v1"


async def ready(page, url):
    await page.goto(url)
    await page.locator('a.avatar[href="#settings"]').wait_for()


async def persisted(page):
    return await page.evaluate("""async () => {
      const s = await import('/storage.js');
      const record = await s.readDurableState();
      return record && {savedAt: record.savedAt, notes: record.state.notes.length,
        attempts: record.state.attempts.length, profile: record.state.profile,
        firstNote: record.state.notes[0], lastNote: record.state.notes.at(-1)};
    }""")


async def export_json(page):
    await page.goto(page.url.split("#")[0] + "#settings")
    async with page.expect_download() as download_info:
        await page.locator('[data-action="export"]').click()
    download = await download_info.value
    with tempfile.TemporaryDirectory(prefix="mam-storage-export-") as folder:
        path = Path(folder) / "backup.json"
        await download.save_as(path)
        return json.loads(path.read_text())


async def change_profile(page, *, month, name):
    await page.goto(page.url.split("#")[0] + "#settings")
    await page.locator('#profile-name').fill(name)
    await page.locator('#daily-minutes').fill("150")
    await page.locator('#target-month').fill(month)
    await page.locator('[data-form="settings"] button[type="submit"]').click()
    await page.locator('.toast.success').filter(has_text="Đã cập nhật").wait_for()
    # A preceding success toast may still be visible while a large new save is
    # queued. Confirm this specific profile committed before requesting reload.
    await page.wait_for_function("""async ({month, name}) => {
      const {readDurableState, durableStorageAvailable} = await import('/storage.js');
      const record = durableStorageAvailable() ? await readDurableState() : null;
      const state = record?.state || JSON.parse(localStorage.getItem('mam-tsa-v1') || 'null');
      return state?.profile.targetMonth === month && state?.profile.name === name;
    }""", arg={"month": month, "name": name})


async def exercise_question(page):
    await page.goto(page.url.split("#")[0] + "#learn/numbers")
    await page.locator('[data-action="start-assessment"][data-mode="topic"][data-topic="numbers"]').click()
    await page.locator('[data-action="choose-answer"]').first.click()
    await page.locator('[data-action="submit-answer"]').click()
    await page.locator('.feedback').wait_for()


async def main(base_url):
    report = {"testedAt": datetime.now(timezone.utc).isoformat(), "baseUrl": base_url,
              "checks": [], "errors": [], "notChecked": [
                  "Physical iOS/Android storage eviction", "Unlimited lifetime or disk capacity",
                  "A browser/user deleting all site data", "Automatic cloud synchronization"]}
    try:
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(
                executable_path=shutil.which("chromium"), args=["--no-sandbox"])
            context = await browser.new_context(accept_downloads=True)
            page = await context.new_page()
            page.on("pageerror", lambda error: report["errors"].append(str(error)))
            await ready(page, base_url + "/#settings")
            backup = await page.evaluate("async () => (await import('/learning.js')).defaultState()")
            backup["profile"].update(name="Kiểm tra lưu lâu dài", dailyMinutes=150, targetMonth="2027-05")
            backup["notes"] = [{"id": f"note-{i}", "topicId": "numbers", "at": "2026-10-18T01:00:00Z",
                                 "text": f"ghi-chu-{i:04d} " + "x" * 9980} for i in range(900)]
            backup["attempts"] = [{"id": f"attempt-{i}", "topicId": "numbers", "questionId": f"question-{i}",
                "prompt": f"Kiểm tra dữ liệu {i}", "answer": "Chưa học / chưa biết", "expected": "2",
                "explanation": "Kiểm tra độ bền bản sao lưu.", "correct": False, "unknown": True,
                "independent": False, "hintsUsed": 0, "confidence": "low", "mode": "topic",
                "difficulty": 1, "transfer": False, "at": "2026-10-18T01:00:00Z"} for i in range(10020)]
            raw = json.dumps(backup, ensure_ascii=False).encode()
            assert len(raw) > 5 * 1024 * 1024
            async with page.expect_file_chooser() as chooser_info:
                await page.locator('[data-action="import"]').click()
            await (await chooser_info.value).set_files({"name": "large-backup.json", "mimeType": "application/json", "buffer": raw})
            await page.locator('[data-action="confirm-import"]').click()
            await page.locator('.toast.success').filter(has_text="Đã khôi phục").wait_for(timeout=60000)
            record = await persisted(page)
            assert record["notes"] == 900 and record["attempts"] == 10020, record
            assert record["lastNote"]["text"] == backup["notes"][-1]["text"]
            mirrored = await page.evaluate("key => JSON.parse(localStorage.getItem(key) || 'null')", STORAGE_KEY)
            assert not mirrored or len(mirrored["notes"]) != 900, "large fixture unexpectedly fit localStorage"
            report["checks"].append({"name": "UI import exceeds localStorage quota; IndexedDB commit acknowledged",
                                      "bytes": len(raw), "notes": 900, "attempts": 10020, "passed": True})

            await page.reload()
            await page.locator('#profile-name').wait_for()
            assert await page.locator('#profile-name').input_value() == backup["profile"]["name"]
            exported = await export_json(page)
            assert exported["profile"] == backup["profile"]
            assert len(exported["notes"]) == 900 and len(exported["attempts"]) == 10020
            assert exported["notes"] == backup["notes"]
            assert exported["attempts"][0]["id"] == "attempt-0" and exported["attempts"][-1]["id"] == "attempt-10019"
            report["checks"].append({"name": "Reload and JSON export preserve every large note, profile and >10000 attempts", "passed": True})

            await page.goto(base_url + "/#notebook")
            assert await page.locator('.journal-card').count() == 20
            await page.locator('[data-action="journal-page"][data-value="1"]').click()
            assert await page.locator('.journal-card').count() == 20
            await page.locator('#note-text').fill("Ghi chú mới khi localStorage đã quá hạn mức")
            await page.locator('[data-form="note"] button[type="submit"]').click()
            await page.locator('.toast.success').filter(has_text="Đã lưu ghi chú").wait_for()
            assert (await persisted(page))["notes"] == 901
            report["checks"].append({"name": "Large journal pagination and new note remain usable after quota exhaustion", "passed": True})

            await page.add_init_script("localStorage.setItem('mam-tsa-v1','{broken-json');")
            await page.reload()
            await page.locator('#note-text').wait_for()
            assert await page.locator('.error-banner').count() == 0
            exported = await export_json(page)
            assert len(exported["notes"]) == 901 and len(exported["attempts"]) == 10020
            report["checks"].append({"name": "Corrupt localStorage recovers automatically from valid IndexedDB", "passed": True})

            await change_profile(page, month="2020-01", name="Mục tiêu đã qua")
            await exercise_question(page)
            await page.wait_for_function("""async () => {
              const {readDurableState} = await import('/storage.js');
              return (await readDurableState()).state.attempts.length === 10021;
            }""")
            report["checks"].append({"name": "Past goal month does not lock lessons or recording answers", "passed": True})
            await change_profile(page, month="2099-12", name="Mục tiêu tương lai")
            await page.reload()
            await page.locator('#target-month').wait_for()
            assert await page.locator('#target-month').input_value() == "2099-12"
            report["checks"].append({"name": "Future goal month saves and survives reload", "passed": True})
            await context.close()

            fallback = await browser.new_context(accept_downloads=True)
            await fallback.add_init_script("Object.defineProperty(globalThis,'indexedDB',{value:undefined});")
            page = await fallback.new_page()
            page.on("pageerror", lambda error: report["errors"].append(str(error)))
            await ready(page, base_url + "/#settings")
            await change_profile(page, month="2035-04", name="Dự phòng localStorage")
            await page.reload()
            await page.locator('#profile-name').wait_for()
            assert await page.locator('#profile-name').input_value() == "Dự phòng localStorage"
            await exercise_question(page)
            assert await page.evaluate("key => JSON.parse(localStorage.getItem(key)).attempts.length", STORAGE_KEY) == 1
            await page.reload()
            await page.locator('.feedback').wait_for()
            exported = await export_json(page)
            assert len(exported["attempts"]) == 1 and exported["profile"]["name"] == "Dự phòng localStorage"
            report["checks"].append({"name": "IndexedDB unavailable: localStorage profile, answer, reload and export work", "passed": True})
            await fallback.close()
            await browser.close()
        assert not report["errors"], report["errors"]
        report["passed"] = True
    except Exception:
        report["passed"] = False
        report["failure"] = traceback.format_exc()
        raise
    finally:
        output = ROOT / "reports" / "storage-integration.json"
        output.parent.mkdir(exist_ok=True)
        output.write_text(json.dumps(report, ensure_ascii=False, indent=2))
        print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://127.0.0.1:3001")
    asyncio.run(main(parser.parse_args().base_url.rstrip("/")))
