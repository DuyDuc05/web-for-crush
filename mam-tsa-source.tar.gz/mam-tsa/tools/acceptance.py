"""Browser acceptance: 30 genuine desktop + 30 phone-emulated learner flows.

Requires Python Playwright + Chromium and a running npm start server.
Usage: python tools/acceptance.py --base-url http://127.0.0.1:3000
Reports JSON per attempted round (including failures), screenshots and summary.
This explicitly emulates phones; it does not test physical iOS/Android hardware.
"""
import argparse
import asyncio
import json
from pathlib import Path
import traceback
import shutil
import hashlib
from datetime import datetime, timezone
from datetime import timedelta

from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

STORAGE_KEY = "mam-tsa-v1"


async def state(page):
    return await page.evaluate("key => JSON.parse(localStorage.getItem(key))", STORAGE_KEY)


async def layout(page, label, report):
    dimensions = await page.evaluate("""() => ({
      viewport: innerWidth, document: document.documentElement.scrollWidth,
      body: document.body.scrollWidth, title: document.title,
      controls: [...document.querySelectorAll('button,a,input,select,textarea,summary')]
        .filter(e => e.getClientRects().length && getComputedStyle(e).visibility !== 'hidden')
        .map(e=>({tag:e.tagName,action:e.dataset.action,href:e.getAttribute('href'),
           name:e.getAttribute('aria-label')||e.textContent.trim()||e.getAttribute('name'),
           left:Math.round(e.getBoundingClientRect().left),right:Math.round(e.getBoundingClientRect().right)}))
    })""")
    assert dimensions["document"] <= dimensions["viewport"] + 1, f"{label}: horizontal overflow {dimensions}"
    assert dimensions["body"] <= dimensions["viewport"] + 1, f"{label}: body overflow"
    assert dimensions["title"], "missing document title"
    assert all(c["name"] for c in dimensions["controls"] if c["tag"] in ["BUTTON", "A", "SUMMARY"]), f"{label}: unnamed visible control"
    clipped=[c for c in dimensions["controls"] if c["left"] < -1 or c["right"] > dimensions["viewport"]+1]
    assert not clipped,f"{label}: controls clipped horizontally: {clipped}"
    report["layouts"].append({"page": label, **dimensions})


async def saved_at(page):
    return await page.evaluate("() => Number(localStorage.getItem('mam-tsa-v1:savedAt'))||0")


async def wait_saved(page,before):
    await page.wait_for_function("before => (Number(localStorage.getItem('mam-tsa-v1:savedAt'))||0) > before",arg=before)


async def prepare_pointer(locator,report,label):
    # Scroll as a user would before clicking; still require an unobstructed
    # target and Playwright's normal visibility/enabled/stability checks.
    await locator.evaluate("el=>el.scrollIntoView({block:'center',inline:'nearest',behavior:'instant'})")
    hit=await locator.evaluate("""el=>{const r=el.getBoundingClientRect(),top=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return {value:el.dataset.value,hit:top===el||el.contains(top),top:top?.tagName,rect:{x:r.x,y:r.y,width:r.width,height:r.height}}}""")
    if report is not None:report.setdefault('pointer_hit_tests',[]).append({'control':label,**hit})
    assert hit['hit'],f"Control is obstructed after scrolling ({label}): {hit}"


async def submit_form(page,form,report=None):
    before=await saved_at(page)
    button=form.locator('[type="submit"]')
    await prepare_pointer(button,report,'submit:'+str(await form.get_attribute('data-form')))
    await button.click()
    await wait_saved(page,before)


async def draft_survives_timer(page,form,report,label):
    fields=await form.evaluate("""form=>[...form.elements].filter(el=>el.name&&['INPUT','TEXTAREA','SELECT'].includes(el.tagName)&&el.type!=='file').map(el=>({name:el.name,type:el.type,value:el.value,checked:el.checked}))""")
    for _ in range(2):
        await click(page,"timer-toggle",report,within=".topbar")
        actual=await form.evaluate("""form=>[...form.elements].filter(el=>el.name&&['INPUT','TEXTAREA','SELECT'].includes(el.tagName)&&el.type!=='file').map(el=>({name:el.name,type:el.type,value:el.value,checked:el.checked}))""")
        assert actual==fields,f"{label}: timer render discarded unsaved form fields: {actual} != {fields}"
    report["actions"].append(f"draft-survives-timer:{label}")


async def click(page, action, report, extra="", within="", index=0):
    locator = page.locator(f'{within} [data-action="{action}"]{extra}:visible').nth(index)
    persisted={"start-assessment","replace-assessment","choose-answer","confidence","submit-answer","unknown","next-question","hint","complete-lesson","confirm-delete-note","confirm-import","confirm-reset"}
    must_wait=action in persisted
    if action=="start-assessment":
        must_wait=not (await state(page))["activeAssessment"]
    before=await saved_at(page) if must_wait else None
    chat_before=len((await state(page))["chat"]) if action=="tutor-preset" else None
    timer_before=await page.locator('.topbar [data-action="timer-toggle"]').get_attribute('aria-label') if action=="timer-toggle" else None
    await prepare_pointer(locator,report,action)
    await locator.click()
    if must_wait:await wait_saved(page,before)
    if action=="timer-toggle":
        await page.wait_for_function("old => document.querySelector('.topbar [data-action=timer-toggle]').getAttribute('aria-label')!==old",arg=timer_before)
    if action=="tutor-preset":
        await page.wait_for_function("n => {const s=JSON.parse(localStorage.getItem('mam-tsa-v1'));return s.chat.length===n+2&&s.chat.at(-1).role==='assistant';}",arg=chat_before)
    report["actions"].append(action)


async def navigate(page, route, report):
    await page.locator('#app .page-content').wait_for()
    headings={
        'settings':'Không gian học của bạn',
        'assess':'Kiểm tra mức độ hiểu',
        'roadmap':'Lộ trình của riêng bạn',
        'progress':'Nhìn thấy mình tiến bộ',
        'notebook':'Sổ tay của mình',
        'tutor':'Mình cùng tháo từng nút nhé.',
    }
    if route=='today':
        profile=(await state(page))['profile']
        expected_heading=(f"Chào {profile['name']}," if profile['name'] else 'Chào bạn,')+' mình cùng học nhé.'
    else:
        expected_heading=headings[route]
    async def destination():
        return await page.evaluate("""() => ({hash:location.hash,
          heading:document.querySelector('#app .page-content h1')?.textContent,
          visible:!!document.querySelector('#app .page-content h1')?.getClientRects().length,
          active:[...document.querySelectorAll('a[aria-current="page"]')].map(a=>a.getAttribute('href')),
          dialogs:[...document.querySelectorAll('[role="dialog"]')].filter(e=>e.getClientRects().length).length})""")
    def arrived(snapshot):
        return (snapshot['hash']==f'#{route}' and snapshot['heading']==expected_heading
            and snapshot['visible'] and f'#{route}' in snapshot['active'] and snapshot['dialogs']==0)
    target=page.locator(f'a[href="#{route}"]:visible')
    if not await target.count():
        await click(page,"mobile-more",report)
        target=page.locator(f'[role="dialog"] a[href="#{route}"]:visible')
    await prepare_pointer(target.first,report,'navigate:'+route)
    try:
        await target.first.click()
    except PlaywrightTimeoutError as error:
        # A native click can change the app before Playwright's navigation wait
        # times out. Never retry that click or accept only a changed URL: require
        # the rendered destination, its active navigation and the closed dialog.
        snapshot=await destination()
        if not arrived(snapshot):raise
        report.setdefault('automation_warnings',[]).append({
            'action':'navigate:'+route,'error':str(error),'verified_destination':snapshot,
            'resolution':'Native click rendered the exact destination; no retry or forced click. All subsequent assertions remain required.'})
    # Hash navigation dispatches its render callback asynchronously. Wait for
    # the rendered destination rather than assuming it finished within 30 ms.
    # Keep the same 15-second default deadline and every destination assertion.
    await page.wait_for_function("""({route,heading}) => {
        const title=document.querySelector('#app .page-content h1');
        return location.hash==='#'+route && title?.textContent===heading
          && !!title.getClientRects().length
          && [...document.querySelectorAll('a[aria-current="page"]')].some(a=>a.getAttribute('href')==='#'+route)
          && ![...document.querySelectorAll('[role="dialog"]')].some(el=>el.getClientRects().length);
    }""",arg={'route':route,'heading':expected_heading},polling=100)
    snapshot=await destination()
    assert arrived(snapshot),f'Navigation did not render the expected destination {route}: {snapshot}'
    report["actions"].append(f"navigate:{route}")
    await layout(page, route, report)


async def quiz(page, report, mode, count, topic="", start=True):
    attrs = f'[data-mode="{mode}"]' + (f'[data-topic="{topic}"]' if topic else "")
    if start:
        await click(page, "start-assessment", report, attrs)
    await page.wait_for_function("() => location.hash === '#assessment'")
    for index in range(count):
        s = await state(page)
        assessment = s["activeAssessment"]
        assert assessment, f"{mode}: no persisted active assessment"
        assert len(assessment["questions"]) == count
        assert assessment["index"] == index
        q = assessment["questions"][index]
        if index==0 and mode=="practice":
            duration=(datetime.fromisoformat(assessment["expiresAt"])-datetime.fromisoformat(assessment["startedAt"])).total_seconds()
            assert duration==900,"Practice timer should match the displayed 15 minutes"
        before = len(s["attempts"])
        branch = index % 5
        if branch == 3:
            await click(page, "unknown", report)
        else:
            if branch == 2:
                for _ in range(3):
                    await click(page, "hint", report)
                hinted = await state(page)
                assert hinted["activeAssessment"]["hintLevel"] == 3
                assert await page.locator('[data-action="hint"]').is_disabled()
            value = next(v for v in q["options"] if v != q["answer"]) if branch == 0 else q["answer"]
            await click(page,"confidence",report,f'[data-value="{["high","medium","low"][index%3]}"]')
            await click(page,"choose-answer",report,index=q["options"].index(value))
            await click(page, "submit-answer", report)
        after = await state(page)
        assert len(after["attempts"]) == before + 1, f"{mode}: answer was not persisted"
        a = after["attempts"][-1]
        assert a["questionId"] == q["id"]
        assert a["assessmentId"] == assessment["id"],"Answer is not linked to its actual assessment"
        assert a["unknown"] == (branch == 3)
        assert a["correct"] == (branch not in [0, 3])
        if branch == 2:
            assert not a["independent"] and a["hintsUsed"] >= 1
        feedback_classes=(await page.locator('.feedback').get_attribute('class')).split()
        assert ("correct" in feedback_classes)==(branch not in [0,3]),"Answer feedback displays the wrong correctness"
        await layout(page, f"{mode}:answer-{index+1}", report)
        if index==0 and mode=="diagnostic":
            await click(page,"quit-assessment",report)
            await click(page,"close-modal",report)
            await click(page,"quit-assessment",report)
            await click(page,"leave-assessment",report)
            await page.wait_for_function("() => location.hash === '#assess'")
            await page.locator('a[href="#assessment"]:visible').first.click()
            await page.wait_for_function("() => location.hash === '#assessment'")
            await page.reload(wait_until="networkidle")
            assert (await state(page))["activeAssessment"]["answered"]
            assert len((await state(page))["attempts"])==before+1
            report["actions"].append("resume-answer-after-reload")
        await click(page, "next-question", report)
    await page.wait_for_function("() => location.hash.startsWith('#results/')")
    s = await state(page)
    assert s["activeAssessment"] is None
    result = s["assessments"][-1]
    assert result["total"] == count
    assert result["correct"] == sum(i % 5 not in [0, 3] for i in range(count))
    assert all(a.get("assessmentId")==result["id"] for a in s["attempts"][-count:]),"Result is not linked to its own answers"
    report["assessments"].append({"mode":mode,"total":count,"correct":result["correct"]})
    await layout(page, f"{mode}:results", report)
    print(f"{report['kind']} {report['round']}: {mode} {count} questions checked",flush=True)


async def learner_round(browser, base_url, kind, number, output):
    widths = [1280, 1440, 1920] if kind == "desktop" else [360, 390, 414]
    width = widths[(number - 1) % len(widths)]
    height = 900 if kind == "desktop" else 844
    report = {"kind":kind,"round":number,"viewport":{"width":width,"height":height},
              "phone_emulation":kind == "mobile", "physical_device":False,
              "seed": number*977+(0 if kind == "desktop" else 50000),
              "started_at":datetime.now(timezone.utc).isoformat(),"actions":[],"layouts":[],
              "assessments":[],"console_errors":[],"page_errors":[],"http_errors":[],"passed":False}
    context = await browser.new_context(viewport={"width":width,"height":height},
        is_mobile=kind == "mobile",has_touch=kind == "mobile",device_scale_factor=1,
        accept_downloads=True,reduced_motion="reduce")
    seed_fixture={"version":1,"profile":{"name":"","dailyMinutes":150,"targetMonth":"2027-05","aiConsent":False},"attempts":[],"notes":[],"completedLessons":[],"seed":report["seed"]}
    await context.add_init_script("try{if(!localStorage.getItem('mam-tsa-v1'))localStorage.setItem('mam-tsa-v1',JSON.stringify("+json.dumps(seed_fixture)+"));}catch{}")
    page = await context.new_page()
    page.set_default_timeout(15000)
    page.on("pageerror", lambda error: report["page_errors"].append(str(error)))
    page.on("console", lambda msg: report["console_errors"].append(msg.text) if msg.type == "error" else None)
    page.on("response", lambda response: report["http_errors"].append({"url":response.url,"status":response.status}) if response.status>=400 else None)
    prefix = f"{kind}-{number:02}"
    try:
        await page.goto(base_url,wait_until="networkidle")
        await page.locator('#app .page-content').wait_for()
        assert (await state(page))["seed"]==report["seed"],"Round seed was not actually applied"
        await layout(page,"initial",report)
        await page.screenshot(path=str(output/f"{prefix}-dashboard.png"),full_page=True)
        await navigate(page,"settings",report)
        form=page.locator('form[data-form="settings"]')
        await form.locator('[name="name"]').fill(f"Học thử {kind} {number}")
        await form.locator('[name="dailyMinutes"]').fill("150")
        await form.locator('[name="targetMonth"]').fill("2027-05")
        api_status=await (await page.request.get(base_url+"/api/status")).json()
        if not api_status["aiAvailable"]:
            await form.locator('[name="aiConsent"]').check()
            report["actions"].append("ai-consent-fail-closed")
        await draft_survives_timer(page,form,report,"settings")
        await submit_form(page,form,report)
        report["actions"].append("save-settings")
        assert (await state(page))["profile"]["dailyMinutes"] == 150
        assert not (await state(page))["profile"]["aiConsent"]
        assert (await state(page))["seed"]==report["seed"]
        await page.reload(wait_until="networkidle")
        await navigate(page,"assess",report)
        await quiz(page,report,"diagnostic",12)
        await misc_controls(page,report)
        print(f"{kind} {number}: all 21 lessons and interactive controls checked",flush=True)
        await navigate(page,"roadmap",report)
        await page.locator('a[href="#learn/numbers"]:visible').first.click()
        report["actions"].append("open-lesson:numbers")
        await layout(page,"lesson",report)
        await page.locator('#number-slider').fill("-3")
        assert await page.locator('#number-slider').input_value()=="-3"
        report["actions"].append("number-slider")
        await click(page,"complete-lesson",report)
        assert "numbers" in (await state(page))["completedLessons"]
        assert (await state(page))["lessonReadAt"]["numbers"]
        chapter_form=page.locator('form[data-form="chapter-check"]')
        await chapter_form.wait_for()
        assert await chapter_form.locator('[name="text"]').get_attribute('required') is not None
        await layout(page,"chapter-check:modal",report)
        await chapter_form.get_by_role('button',name="Để sau",exact=True).click()
        report["actions"].append("defer-chapter-check")
        await navigate(page,"today",report)
        pending=page.locator('section[aria-label="Kiểm tra sau phần đã học"]')
        assert await pending.locator('[data-action="start-assessment"][data-topic="numbers"]').count()==1
        assert "Đã đọc · chưa kiểm tra" in await pending.inner_text()
        report["actions"].append("today-pending-chapter-check")
        await open_lesson(page,"numbers",report)
        chapter_draft=f"Mình hiểu trục số: sang phải là tăng, sang trái là giảm. Lượt {number}."
        await page.locator('form[data-form="reflection"] [name="text"]').fill(chapter_draft)
        await click(page,"complete-lesson",report)
        chapter_form=page.locator('form[data-form="chapter-check"]')
        assert await chapter_form.locator('[name="text"]').input_value()==chapter_draft,"Chapter self-explanation did not retain the learner's existing draft"
        report["actions"].append("chapter-reflection-draft-prefill")
        await submit_form(page,chapter_form,report)
        report["actions"].append("submit-chapter-self-explanation")
        await quiz(page,report,"topic",5,"numbers",start=False)
        current=await state(page)
        chapter_result=current["assessments"][-1]
        chapter_answers=[a for a in current["attempts"] if a.get("assessmentId")==chapter_result["id"]]
        assert len(chapter_answers)==5 and chapter_result["topicId"]=="numbers"
        assert sum(a["correct"] for a in chapter_answers)==3
        assert sum(a["unknown"] for a in chapter_answers)==1
        panel=page.locator('[data-quality-topic="numbers"]')
        await panel.wait_for()
        assert "3/5 câu đúng" in await panel.inner_text()
        assert "1 câu chưa biết" in await panel.inner_text()
        assert "Cần củng cố" in await panel.inner_text()
        await layout(page,"chapter-check:quality-results",report)
        await page.screenshot(path=str(output/f"{prefix}-chapter-quality.png"),full_page=True)
        await page.reload(wait_until="networkidle")
        assert "3/5 câu đúng" in await page.locator('[data-quality-topic="numbers"]').inner_text()
        report["actions"].append("chapter-quality-result-linked-and-reloaded")
        await open_lesson(page,"numbers",report)
        reflection=page.locator('form[data-form="reflection"]')
        await reflection.locator('[name="text"]').fill(f"Mình giải thích bằng trục số: đi sang phải là tăng. Lượt {number}.")
        await draft_survives_timer(page,reflection,report,"reflection")
        await submit_form(page,reflection,report)
        assert await reflection.locator('[name="text"]').input_value()=="","Successful reflection save left the submitted draft in the form"
        report["actions"].append("save-reflection")
        assert len((await state(page))["reflections"]) >= 1
        await navigate(page,"assess",report)
        await quiz(page,report,"practice",15)
        await navigate(page,"progress",report)
        await page.screenshot(path=str(output/f"{prefix}-progress.png"),full_page=True)
        await navigate(page,"notebook",report)
        text=f"Ghi chú độc lập {kind} {number}: mình cần kiểm tra dấu âm."
        form=page.locator('form[data-form="note"]')
        await form.locator('[name="topicId"]').select_option("fractions")
        report["actions"].append("note-topic")
        await form.locator('[name="text"]').fill(text)
        await draft_survives_timer(page,form,report,"note-and-topic")
        await submit_form(page,form,report)
        assert await form.locator('[name="text"]').input_value()=="","Successful note save left the submitted draft in the form"
        report["actions"].append("save-note")
        assert any(n["text"]==text for n in (await state(page))["notes"])
        assert next(n for n in (await state(page))["notes"] if n["text"]==text)["topicId"]=="fractions"
        await page.reload(wait_until="networkidle")
        assert await page.get_by_text(text,exact=True).count() >= 1
        assert len((await state(page))["attempts"]) == 32
        report["actions"].append("reload-persistence")
        await notebook_controls(page,report)
        await navigate(page,"tutor",report)
        # Tutor control selectors are supplemented after app startup inspection.
        await tutor_flow(page,report)
        await navigate(page,"settings",report)
        async with page.expect_download() as download_info:
            await click(page,"export",report)
        download=await download_info.value
        backup_path=output/f"{prefix}-backup.json"
        await download.save_as(backup_path)
        backup=json.loads(backup_path.read_text())
        assert len(backup["attempts"]) == 37
        before=(await state(page))["attempts"]
        await upload(page,report,"corrupt.json",b'{"broken":true}')
        await page.locator('#toast-root .toast.error').wait_for()
        assert "Không nhập được" in await page.locator('#toast-root').inner_text()
        assert (await state(page))["attempts"] == before,"bad backup changed evidence"
        report["actions"].append("import-corrupt-preserves-state")
        await import_good(page,report,backup)
        await reset_cancel(page,report)
        assert len((await state(page))["attempts"]) == 37
        await click(page,"reset-data",report)
        await click(page,"confirm-reset",report)
        await page.wait_for_function("() => location.hash === '#today'")
        assert len((await state(page))["attempts"])==0
        await navigate(page,"settings",report)
        await import_good(page,report,backup)
        async with page.expect_download() as download_info:
            await click(page,"download-standalone",report)
        downloaded=await download_info.value
        html_path=output/f"{prefix}-mam-tsa.html"
        await downloaded.save_as(html_path)
        assert html_path.stat().st_size>100000 and "__TSA_STANDALONE__" in html_path.read_text()
        if number==1:
            await standalone_flow(browser,html_path,backup,report,output,prefix,base_url)
        if number!=1:html_path.unlink()
        await timer_flow(page,report)
        await entry_points_flow(browser,base_url,backup,report)
        if number==1:
            await multi_tab_flow(browser,base_url,report)
        await recovery_flow(browser,base_url,report,output,prefix)
        await page.screenshot(path=str(output/f"{prefix}-final.png"),full_page=True)
        assert not report["page_errors"], report["page_errors"]
        assert not report["console_errors"], report["console_errors"]
        assert not report["http_errors"], report["http_errors"]
        report["passed"]=True
    except Exception as error:
        report["error"]=str(error)
        report["traceback"]=traceback.format_exc()
        try: await page.screenshot(path=str(output/f"{prefix}-failure.png"),full_page=True)
        except Exception: pass
    finally:
        report["finished_at"]=datetime.now(timezone.utc).isoformat()
        (output/f"{prefix}.json").write_text(json.dumps(report,ensure_ascii=False,indent=2))
        await context.close()
    return report


async def tutor_flow(page,report):
    await page.locator('#tutor-topic').select_option("fractions")
    report["actions"].append("tutor-topic")
    await click(page,"ai-info",report)
    await layout(page,"ai-info-dialog",report)
    await click(page,"close-modal",report)
    form=page.locator('form[data-form="chat"]')
    chat_before=len((await state(page))["chat"])
    await form.locator('[name="message"]').fill("Vì sao trừ một số âm lại thành cộng?")
    await submit_form(page,form,report)
    await page.wait_for_function("n => {const s=JSON.parse(localStorage.getItem('mam-tsa-v1'));return s.chat.length===n+2&&s.chat.at(-1).role==='assistant';}",arg=chat_before)
    assert await form.locator('[name="message"]').input_value()=="","Successful tutor submission left the submitted draft in the form"
    s=await state(page)
    assert s["chat"][-1]["role"] == "assistant"
    assert s["chat"][-1]["mode"] in ["guided","online"]
    report["actions"].append("tutor-question")
    for index in range(3):
        before=len((await state(page))["chat"])
        await click(page,"tutor-preset",report,index=index)
        assert len((await state(page))["chat"])==before+2
    await layout(page,"tutor:response",report)


async def upload(page,report,name,buffer):
    async with page.expect_file_chooser() as info:
        await click(page,"import",report)
    await (await info.value).set_files({"name":name,"mimeType":"application/json","buffer":buffer})


async def open_lesson(page,topic,report):
    await navigate(page,"roadmap",report)
    await click(page,"filter",report,'[data-domain="all"]')
    await page.locator(f'a[href="#learn/{topic}"]:visible').first.click()
    await page.wait_for_function("route => location.hash === '#learn/'+route",arg=topic)
    report["actions"].append("open-lesson:"+topic)
    await layout(page,"lesson:"+topic,report)


async def misc_controls(page,report):
    await click(page,"sources",report)
    await layout(page,"sources-dialog",report)
    await click(page,"close-modal",report)
    await click(page,"search",report)
    await page.locator('#topic-search').fill("phan so")
    assert await page.locator('#search-results a').count()>=1
    await page.locator('#topic-search').fill("zzzz-no-topic")
    assert await page.locator('#search-results a').count()==0
    await page.locator('#topic-search').fill("phan so")
    await page.locator('#search-results a').first.click()
    await page.wait_for_function("() => location.hash === '#learn/fractions'")
    report["actions"].append("search-filter-and-open")
    await navigate(page,"roadmap",report)
    for domain,count in [("math",12),("reading",3),("science",6),("all",21)]:
        await click(page,"filter",report,f'[data-domain="{domain}"]')
        assert await page.locator('.topic-card').count()==count
        await layout(page,"roadmap:"+domain,report)
    calendar=page.locator('details.weekly-calendar')
    if await calendar.count():
        await calendar.locator(':scope > summary').click()
        assert await calendar.get_attribute('open') is not None
        report["actions"].append("weekly-calendar-open")
        week=calendar.locator('details.weekly-item').first
        was_open=await week.get_attribute('open') is not None
        await week.locator(':scope > summary').click()
        assert (await week.get_attribute('open') is not None)!=was_open
        if was_open:
            await week.locator(':scope > summary').click()
        assert await week.get_attribute('open') is not None
        report["actions"].append("weekly-week-open")
        await layout(page,"roadmap:weekly-expanded",report)
        route=await week.locator('a').first.get_attribute('href')
        await week.locator('a').first.click()
        await page.wait_for_function("route => location.hash === route",arg=route)
        report["actions"].append("weekly-topic-link")
        await navigate(page,"roadmap",report)
    # Every current lesson is actually opened and measured in every round.
    for topic in ["numbers","fractions","percent","algebra","linear","quadratic","functions",
                  "geometry","trigonometry","exponents","probability","statistics","units",
                  "motion","forces","energy","chemistry","experiment","reading-evidence",
                  "reading-inference","reading-structure"]:
        await open_lesson(page,topic,report)
    await open_lesson(page,"fractions",report)
    for index in range(4):
        locator=page.locator(f'[data-action="fraction-piece"][data-index="{index}"]')
        before=await locator.get_attribute("aria-pressed")
        await locator.click()
        assert await locator.get_attribute("aria-pressed")!=before
        report["actions"].append("fraction-piece")
    await open_lesson(page,"linear",report)
    await page.locator('#slope-slider').fill("-2")
    assert await page.locator('#slope-slider').input_value()=="-2"
    report["actions"].append("slope-slider")
    await open_lesson(page,"probability",report)
    await click(page,"roll-die",report)
    assert 1<=int(await page.locator('.die-face').inner_text())<=6
    await open_lesson(page,"experiment",report)
    for expected in ["true","false"]:
        await click(page,"experiment-toggle",report)
        assert await page.locator('[data-action="experiment-toggle"]').get_attribute('aria-pressed')==expected


async def notebook_controls(page,report):
    form=page.locator('form[data-form="note"]')
    await form.locator('[name="text"]').fill("Ghi chú tạm sẽ xóa")
    await submit_form(page,form,report)
    report["actions"].append("save-note")
    assert len((await state(page))["notes"])==2
    temporary=page.locator('.journal-card').filter(has=page.get_by_text("Ghi chú tạm sẽ xóa",exact=True))
    await temporary.locator('[data-action="delete-note"]').click()
    report["actions"].append("delete-note")
    await click(page,"close-modal",report)
    assert len((await state(page))["notes"])==2
    await temporary.locator('[data-action="delete-note"]').click()
    await click(page,"confirm-delete-note",report)
    assert len((await state(page))["notes"])==1
    await click(page,"notebook-filter",report,'[data-value="reflections"]')
    assert await page.locator('.journal-card').count()==2
    await layout(page,"notebook:reflections",report)
    await click(page,"notebook-filter",report,'[data-value="notes"]')
    assert await page.locator('.journal-card').count()==1
    await click(page,"notebook-filter",report,'[data-value="errors"]')
    assert await page.locator('.journal-card').count()>=1
    await layout(page,"notebook:errors",report)
    await click(page,"retry-error",report)
    await page.wait_for_function("() => location.hash === '#assessment'")
    await navigate(page,"assess",report)
    await click(page,"start-assessment",report,'[data-mode="review"]')
    await click(page,"resume-assessment",report)
    await page.wait_for_function("() => location.hash === '#assessment'")
    await navigate(page,"assess",report)
    await click(page,"start-assessment",report,'[data-mode="review"]')
    await click(page,"replace-assessment",report)
    await page.wait_for_function("() => location.hash === '#assessment'")
    assert (await state(page))["activeAssessment"]["mode"]=="review"
    assert len((await state(page))["activeAssessment"]["questions"])==5
    report["actions"].append("review-start-and-replace")
    await quiz(page,report,"review",5,start=False)


async def recovery_flow(browser,base_url,report,output,prefix):
    context=await browser.new_context(viewport=report["viewport"],is_mobile=report["phone_emulation"],has_touch=report["phone_emulation"])
    await context.add_init_script("try{localStorage.setItem('mam-tsa-v1','{malformed-preserve-original');}catch{}")
    page=await context.new_page()
    await page.goto(base_url,wait_until="networkidle")
    await navigate(page,"settings",report)
    await click(page,"export",report)
    async with page.expect_download() as info:
        await click(page,"export-recovery",report)
    path=output/f"{prefix}-recovery.txt"
    await (await info.value).save_as(path)
    assert path.read_text()=="{malformed-preserve-original"
    assert await page.evaluate("key => localStorage.getItem(key)",STORAGE_KEY)=="{malformed-preserve-original"
    await context.close()
    report["actions"].append("recovery-keeps-original")


async def entry_points_flow(browser,base_url,backup,report):
    """Exercise repeated assessment controls at their actual route locations.

    The old dates are an explicit due-review fixture in a separate context;
    they are never reported as genuine elapsed learning days.
    """
    context=await browser.new_context(viewport=report["viewport"],is_mobile=report["phone_emulation"],has_touch=report["phone_emulation"],reduced_motion="reduce")
    fixture=json.loads(json.dumps(backup))
    fixture["activeAssessment"]=None
    old=(datetime.now(timezone.utc)-timedelta(days=30)).isoformat()
    for a in fixture["attempts"]:a["at"]=old
    fixture["notes"]=[{"id":f"page-fixture-{i}","text":f"Ghi chú kiểm tra phân trang {i}","topicId":"numbers","at":old} for i in range(21)]
    await context.add_init_script("try{if(!localStorage.getItem('mam-tsa-v1'))localStorage.setItem('mam-tsa-v1',JSON.stringify("+json.dumps(fixture)+"));}catch{}")
    page=await context.new_page()
    await page.goto(base_url,wait_until="networkidle")
    await navigate(page,"today",report)
    await click(page,"start-assessment",report,'[data-mode="review"]',within=".page-content")
    await page.wait_for_function("() => location.hash === '#assessment'")
    assert (await state(page))["activeAssessment"]["mode"]=="review"
    report["actions"].append("today-review-entry:dated-fixture")
    await navigate(page,"progress",report)
    await click(page,"start-assessment",report,'[data-topic="numbers"]',within=".page-content")
    await click(page,"replace-assessment",report)
    await page.wait_for_function("() => location.hash === '#assessment'")
    assert (await state(page))["activeAssessment"]["topicId"]=="numbers"
    report["actions"].append("progress-assessment-entry")
    await navigate(page,"tutor",report)
    await page.locator('#tutor-topic').select_option("fractions")
    await click(page,"start-assessment",report,'[data-topic="fractions"]',within=".page-content")
    await click(page,"replace-assessment",report)
    await page.wait_for_function("() => location.hash === '#assessment'")
    assert (await state(page))["activeAssessment"]["topicId"]=="fractions"
    assert len((await state(page))["attempts"])==37
    report["actions"].append("tutor-assessment-entry")
    await navigate(page,"notebook",report)
    assert await page.locator('.journal-card').count()==20
    await click(page,"journal-page",report,'[data-value="1"]')
    assert await page.locator('.journal-card').count()==1
    await layout(page,"notebook:page-2-fixture",report)
    await click(page,"journal-page",report,'[data-value="0"]')
    assert await page.locator('.journal-card').count()==20
    report["actions"].append("journal-pagination:21-note-fixture")
    await context.close()


async def standalone_flow(browser,html_path,backup,report,output,prefix,base_url):
    context=await browser.new_context(viewport=report["viewport"],is_mobile=report["phone_emulation"],has_touch=report["phone_emulation"],offline=True,accept_downloads=True,reduced_motion="reduce")
    page=await context.new_page()
    errors=[];http_requests=[]
    page.on("pageerror",lambda error:errors.append(str(error)))
    page.on("request",lambda request:http_requests.append(request.url) if request.url.startswith(("http:","https:")) else None)
    fallback_url=None
    try:
        await page.goto(html_path.resolve().as_uri(),wait_until="networkidle")
        report["file_protocol"]={"tested":True,"blocked":False}
    except Exception as error:
        if "ERR_BLOCKED_BY_ADMINISTRATOR" not in str(error):raise
        # Respect the browser administrator's file-URL restriction. Serve the
        # same downloaded bytes as a local HTTP document, then turn off network.
        report["file_protocol"]={"tested":False,"blocked":True,"reason":"ERR_BLOCKED_BY_ADMINISTRATOR"}
        fallback_url=base_url+"/__acceptance_downloaded_html__"
        await page.route(fallback_url,lambda route:route.fulfill(status=200,content_type="text/html; charset=utf-8",body=html_path.read_text()))
        await context.set_offline(False)
        await page.goto(fallback_url,wait_until="networkidle")
        await context.set_offline(True)
    await page.locator('#app .page-content').wait_for()
    await layout(page,"offline:initial",report)
    await navigate(page,"settings",report)
    await import_good(page,report,backup)
    await navigate(page,"tutor",report)
    form=page.locator('form[data-form="chat"]')
    chat_before=len((await state(page))["chat"])
    await form.locator('[name="message"]').fill("Cho mình một ví dụ")
    await submit_form(page,form,report)
    await page.wait_for_function("n => {const s=JSON.parse(localStorage.getItem('mam-tsa-v1'));return s.chat.length===n+2&&s.chat.at(-1).role==='assistant';}",arg=chat_before)
    assert (await state(page))["chat"][-1]["mode"]=="guided"
    await open_lesson(page,"numbers",report)
    await click(page,"start-assessment",report,'[data-mode="topic"]')
    await page.wait_for_function("() => location.hash === '#assessment'")
    await click(page,"unknown",report)
    assert len((await state(page))["attempts"])==38
    await page.reload(wait_until="networkidle")
    assert (await state(page))["activeAssessment"]["answered"]
    await layout(page,"offline:answered-after-reload",report)
    await page.screenshot(path=str(output/f"{prefix}-offline.png"),full_page=True)
    await navigate(page,"settings",report)
    async with page.expect_download() as info:
        await click(page,"export",report)
    path=output/f"{prefix}-offline-backup.json"
    await (await info.value).save_as(path)
    assert len(json.loads(path.read_text())["attempts"])==38
    await click(page,"download-standalone",report)
    assert not errors,errors
    unexpected=[url for url in http_requests if url!=fallback_url]
    assert not unexpected,unexpected
    report["offline_verified"]={"file":str(html_path),"mode":"local-http-document" if fallback_url else "file-url","network_offline":True,"unexpected_http_requests":0,"restored_attempts":37,"attempts_after_answer_and_reload":38}
    report["actions"].append("downloaded-html-offline-import-learn-tutor-reload-export")
    await context.close()


async def multi_tab_flow(browser,base_url,report):
    context=await browser.new_context(viewport=report["viewport"],is_mobile=report["phone_emulation"],has_touch=report["phone_emulation"],reduced_motion="reduce")
    stale=await context.new_page()
    await stale.goto(base_url,wait_until="networkidle")
    await navigate(stale,"settings",report)
    form=stale.locator('form[data-form="settings"]')
    await form.locator('[name="name"]').fill("Hồ sơ tab cũ")
    await submit_form(stale,form,report)
    await stale.get_by_text("Đã cập nhật lịch học của bạn.",exact=True).wait_for()
    current=await context.new_page()
    await current.goto(base_url,wait_until="networkidle")
    await navigate(current,"settings",report)
    form=current.locator('form[data-form="settings"]')
    await form.locator('[name="name"]').fill("Hồ sơ mới cần được giữ")
    await submit_form(current,form,report)
    await current.get_by_text("Đã cập nhật lịch học của bạn.",exact=True).wait_for()
    await navigate(current,"notebook",report)
    form=current.locator('form[data-form="note"]')
    await form.locator('[name="text"]').fill("Ghi chú của tab mới cần được giữ")
    await submit_form(current,form,report)
    await current.get_by_text("Đã lưu ghi chú vào sổ hiểu biết.",exact=True).wait_for()
    await stale.close()
    await current.wait_for_timeout(250)
    # A reload of the current tab could itself rewrite the good snapshot and
    # hide the regression, so open a third tab without closing the current one.
    reopened=await context.new_page()
    await reopened.goto(base_url,wait_until="networkidle")
    await reopened.locator('#app .page-content').wait_for()
    saved=await state(reopened)
    assert saved["profile"]["name"]=="Hồ sơ mới cần được giữ","Closing a stale tab overwrote the newer profile"
    assert any(n["text"]=="Ghi chú của tab mới cần được giữ" for n in saved["notes"]),"Closing a stale tab lost newer notes"
    report["actions"].append("stale-tab-close-preserves-newer-profile-and-notes")
    await context.close()


async def import_good(page,report,backup):
    settings=page.locator('form[data-form="settings"]')
    await settings.locator('[name="name"]').fill("Bản nháp trước khôi phục")
    await upload(page,report,"restore.json",json.dumps(backup,ensure_ascii=False).encode())
    await page.locator('[data-action="confirm-import"]').wait_for()
    # Import may ask for confirmation; only the visible specific dialog is accepted.
    dialog=page.locator('[role="dialog"]:visible')
    if await dialog.count():
        await click(page,"confirm-import",report)
    assert (await state(page))["profile"]["name"] == backup["profile"]["name"]
    assert len((await state(page))["attempts"]) == len(backup["attempts"])
    assert await settings.locator('[name="name"]').input_value()==backup["profile"]["name"],"Restored profile is hidden by an obsolete settings draft"
    assert await settings.locator('[name="dailyMinutes"]').input_value()==str(backup["profile"]["dailyMinutes"])
    assert await settings.locator('[name="targetMonth"]').input_value()==backup["profile"]["targetMonth"]
    report["actions"].append("import-updates-visible-settings")
    report["actions"].append("import-good")


async def reset_cancel(page,report):
    await click(page,"reset-data",report)
    await layout(page,"reset-dialog",report)
    dialog=page.locator('[role="dialog"]:visible')
    assert await dialog.count() == 1
    await page.keyboard.press("Escape")
    assert await dialog.count() == 0
    report["actions"].append("cancel-reset-escape")


async def timer_flow(page,report):
    await navigate(page,"settings",report)
    before=sum((await state(page))["studySeconds"].values())
    await click(page,"timer-toggle",report)
    await page.wait_for_timeout(1200)
    await click(page,"timer-toggle",report)
    after=sum((await state(page))["studySeconds"].values())
    assert after>before,"active timer did not record study time"
    await page.wait_for_timeout(1100)
    assert sum((await state(page))["studySeconds"].values()) == after,"paused timer still counted study time"
    await click(page,"timer-toggle",report,within=".page-content")
    await page.wait_for_timeout(1200)
    await click(page,"timer-toggle",report,within=".page-content")
    final=sum((await state(page))["studySeconds"].values())
    assert final>after,"settings timer did not record study time"
    await click(page,"timer-reset",report)
    await page.wait_for_function("() => [...document.querySelectorAll('[data-focus-timer]')].every(el=>el.textContent==='45:00')")
    assert sum((await state(page))["studySeconds"].values())==final,"timer reset removed accumulated study time"
    report["actions"].append("timer-pause-no-count")


async def main(args):
    output=Path(args.output);output.mkdir(parents=True,exist_ok=True)
    repo=Path(__file__).resolve().parents[1]
    source_files=["app.js","views.js","learning.js","quality.js","ai.js","storage.js","styles.css","index.html","server.mjs","content.js","content/math.js","content/science.js","content/reading.js","dist/mam-tsa.html"]
    def fingerprint():return {name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in source_files if (repo/name).is_file()}
    source_before=fingerprint()
    retained={}; prior_attempts=[]
    for directory in args.resume_from:
        prior=Path(directory)
        previous=json.loads((prior/'summary.json').read_text())
        if not previous.get('source_unchanged_during_run') or previous.get('source_sha256')!=source_before:
            raise SystemExit(f'Cannot retain results from a different production snapshot: {prior}')
        prior_attempts.extend(previous.get('prior_failed_attempts',[]))
        for filename in previous.get('round_reports',[]):
            original=prior/filename
            if not original.is_file():continue
            result=json.loads(original.read_text())
            key=(result['kind'],result['round'])
            if not result.get('passed'):
                prior_attempts.append({'report':str(original),'kind':key[0],'round':key[1],'error':result.get('error')})
                continue
            if key[0] not in ['desktop','mobile'] or not 1<=key[1]<=args.rounds:continue
            expected_seed=key[1]*977+(50000 if key[0]=='mobile' else 0)
            assert result['seed']==expected_seed and sum(a['total'] for a in result['assessments'])==37,'Retained run does not cover the same learner flow'
            if key in retained:continue
            prefix=f'{key[0]}-{key[1]:02}'
            for artifact in prior.glob(prefix+'*'):
                if artifact.is_file():shutil.copy2(artifact,output/artifact.name)
            result['retained_from']=str(original)
            (output/filename).write_text(json.dumps(result,ensure_ascii=False,indent=2))
            retained[key]=result
    executable=shutil.which("chromium")
    browser_versions=set()
    # Isolate the Playwright driver as well as the browser. A slow protocol
    # connection in one profile must not share the other profile's driver loop.
    semaphore=asyncio.Semaphore(args.workers)
    stop=asyncio.Event()
    async def worker(kind,number):
        async with semaphore:
            if stop.is_set():return None
            async with async_playwright() as p:
                browser=await p.chromium.launch(headless=True,**({"executable_path":executable} if executable else {}))
                browser_versions.add(browser.version)
                try:
                    result=await learner_round(browser,args.base_url,kind,number,output)
                finally:
                    await browser.close()
                print(f"{kind} {number}/{args.rounds}: {'PASS' if result['passed'] else 'FAIL '+result.get('error','')}",flush=True)
                if not result["passed"] and args.stop_on_failure:stop.set()
                return result
    batches=await asyncio.gather(*(worker(kind,number) for number in range(1,args.rounds+1) for kind in ["desktop","mobile"] if (kind,number) not in retained))
    browser_version=','.join(sorted(browser_versions)) or 'retained profiles only'
    fresh_results=[item for item in batches if item is not None]
    results=sorted([*retained.values(),*fresh_results],key=lambda r:(r['round'],r['kind']))
    source_after=fingerprint()
    summary={"base_url":args.base_url,"rounds_requested_per_form_factor":args.rounds,"browser":"Chromium",
        "browser_version":browser_version,"workers":args.workers,"new_round_browser_isolation":"separate Playwright driver and browser process per round","phone_emulation":True,"physical_device_tested":False,
        "retained_passes":len(retained),"new_attempted":len(fresh_results),"prior_failed_attempts":prior_attempts,
        "source_attempt_directories":args.resume_from,
        "source_unchanged_during_run":source_before==source_after,"source_sha256":source_after,
        "attempted":len(results),"passed":sum(r["passed"] for r in results),
        "desktop_passed":sum(r["passed"] for r in results if r["kind"]=="desktop"),
        "mobile_passed":sum(r["passed"] for r in results if r["kind"]=="mobile"),
        "actions_covered":sorted(set(a for r in results for a in r["actions"])),
        "failures":[{"kind":r["kind"],"round":r["round"],"error":r.get("error")} for r in results if not r["passed"]],
        "round_reports":[f"{r['kind']}-{r['round']:02}.json" for r in results]}
    (output/"summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k not in ["actions_covered","round_reports","source_sha256"]},ensure_ascii=False),flush=True)
    if summary["passed"]!=args.rounds*2 or not summary["source_unchanged_during_run"]:raise SystemExit(1)


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url",default="http://127.0.0.1:3000")
    parser.add_argument("--rounds",type=int,default=30)
    parser.add_argument("--workers",type=int,default=2)
    parser.add_argument("--resume-from",action="append",default=[],help="Retain passed rounds only when production fingerprints match; failed attempts remain in their original directory")
    parser.add_argument("--output",default="/workspace/tsa-document-review/browser-acceptance")
    parser.add_argument("--stop-on-failure",action="store_true")
    asyncio.run(main(parser.parse_args()))
