// IndexedDB keeps the working copy outside localStorage's small string quota.
// Browser data can still be deleted: portable JSON backups remain necessary.
const DATABASE = 'mam-tsa';
const STORE = 'learning';
const KEY = 'current';
let database = null;
let opening = null;
let operations = Promise.resolve();

export function durableStorageAvailable() {
  return database !== null;
}

export function openDurableStorage() {
  if (database) return Promise.resolve(true);
  if (opening) return opening;
  opening = new Promise(resolve => {
    let finished = false;
    let request;
    const finish = success => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      resolve(success);
    };
    const timer = setTimeout(() => finish(false), 1800);
    try {
      if (!globalThis.indexedDB) { finish(false); return; }
      request = globalThis.indexedDB.open(DATABASE, 1);
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains(STORE)) {
          request.result.createObjectStore(STORE);
        }
      };
      request.onsuccess = () => {
        const connection = request.result;
        if (finished) { connection.close(); return; }
        if (!connection.objectStoreNames.contains(STORE)) {
          connection.close(); finish(false); return;
        }
        database = connection;
        connection.onversionchange = () => {
          connection.close();
          if (database === connection) database = null;
        };
        connection.onclose = () => {
          if (database === connection) database = null;
        };
        finish(true);
      };
      request.onerror = () => finish(false);
      request.onblocked = () => finish(false);
    } catch { finish(false); }
  }).then(success => { opening = null; return success; });
  return opening;
}

// Reads and clears share the queue, so a read after save sees that save and a
// reset cannot race with a pending save. A failure never poisons later writes.
function enqueue(operation, fallback) {
  const result = operations.then(operation).catch(() => fallback);
  operations = result.then(() => undefined);
  return result;
}

function transact(mode, action, fallback) {
  return new Promise(resolve => {
    let transaction;
    let value = fallback;
    let finished = false;
    const finish = result => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      resolve(result);
    };
    const timer = setTimeout(() => {
      try { transaction?.abort(); } catch { /* Already completed. */ }
      finish(fallback);
    }, 5000);
    try {
      transaction = database.transaction(STORE, mode);
      transaction.oncomplete = () => finish(value);
      transaction.onerror = () => finish(fallback);
      transaction.onabort = () => finish(fallback);
      action(transaction.objectStore(STORE), result => { value = result; });
    } catch { finish(fallback); }
  });
}

export function readDurableState() {
  return enqueue(async () => {
    if (!await openDurableStorage()) return null;
    return transact('readonly', (store, result) => {
      const request = store.get(KEY);
      request.onsuccess = () => {
        const record = request.result;
        if (record && record.state && typeof record.state === 'object' &&
            Number.isFinite(record.savedAt)) result(record);
      };
    }, null);
  }, null);
}

export function writeDurableState(state, savedAt = Date.now(), expectedSavedAt) {
  // Snapshot immediately, before the asynchronous queue: caller mutations after
  // this call must not change the saved version of the learner's work.
  let snapshot;
  try {
    if (!state || typeof state !== 'object' || !Number.isFinite(savedAt) || savedAt < 0 ||
        (expectedSavedAt !== undefined && (!Number.isFinite(expectedSavedAt) || expectedSavedAt < 0))) {
      return Promise.resolve(false);
    }
    snapshot = typeof globalThis.structuredClone === 'function'
      ? globalThis.structuredClone(state) : JSON.parse(JSON.stringify(state));
  } catch { return Promise.resolve(false); }
  return enqueue(async () => {
    if (!await openDurableStorage()) return false;
    return transact('readwrite', (store, result) => {
      const request = store.get(KEY);
      request.onsuccess = () => {
        // Read and compare inside the same transaction, including other tabs.
        // Equal timestamps are allowed so consecutive saves in one ms work.
        // An app that supplies its loaded revision gets compare-and-swap:
        // another tab's intervening save cannot be replaced by a stale copy.
        if (expectedSavedAt !== undefined && (request.result?.savedAt || 0) !== expectedSavedAt) return;
        if (request.result?.savedAt > savedAt) return;
        const put = store.put({ state: snapshot, savedAt }, KEY);
        put.onsuccess = () => result(true);
      };
    }, false);
  }, false);
}

export function clearDurableState() {
  return enqueue(async () => {
    if (!await openDurableStorage()) return false;
    return transact('readwrite', (store, result) => {
      const request = store.delete(KEY);
      request.onsuccess = () => result(true);
    }, false);
  }, false);
}
