import test from 'node:test';
import assert from 'node:assert/strict';
import { defaultState, recordAttempt, topicEvidence } from '../learning.js';
test('crossing Vietnam midnight by a minute is not evidence of long-term retention',()=>{
  let state=defaultState();
  const times=['2026-10-18T16:58:00Z','2026-10-18T16:59:00Z','2026-10-18T17:00:00Z'];
  times.forEach((at,i)=>{state=recordAttempt(state,{id:'numbers:'+i,topicId:'numbers',prompt:'Tính '+(i+1)+' + '+(4-i),answer:'5',explanation:'2+3=5',transfer:i===2},'5',{at});});
  assert.equal(topicEvidence(state,'numbers').days,2);
  assert.equal(topicEvidence(state,'numbers').retained,false);
  state=recordAttempt(state,{id:'numbers:next-day',topicId:'numbers',prompt:'Tính 7 - 2',answer:'5',explanation:'3+2=5',transfer:true},'5',{at:'2026-10-19T17:00:00Z'});
  assert.equal(topicEvidence(state,'numbers').retained,true);
});
