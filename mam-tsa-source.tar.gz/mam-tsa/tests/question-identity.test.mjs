import test from 'node:test';
import assert from 'node:assert/strict';
import {defaultState,recordAttempt,topicEvidence,validateImport,questionFingerprint} from '../learning.js';
import {readingTopics} from '../content/reading.js';
test('re-seeding an identical reading passage is not a new independent question',()=>{
  const topic=readingTopics.find(t=>t.id==='reading-evidence');
  const questions=[0,6,12].map(seed=>topic.makeQuestion(seed));
  assert.equal(new Set(questions.map(q=>q.id)).size,3);
  assert.equal(new Set(questions.map(questionFingerprint)).size,1);
  let state=defaultState();
  questions.forEach((q,i)=>{state=recordAttempt(state,q,q.answer,{at:'2026-10-18T0'+(i+1)+':00:00Z'});});
  assert.deepEqual(state.attempts.map(a=>a.independent),[true,false,false]);
  const restored=validateImport(JSON.parse(JSON.stringify(state)));
  assert.deepEqual(restored.attempts,state.attempts);
  const repeated=topic.makeQuestion(18);
  state=recordAttempt(restored,repeated,repeated.answer,{at:'2026-10-20T03:00:00Z'});
  assert.equal(state.attempts.at(-1).independent,false);
  assert.equal(state.attempts.at(-1).retrieval,true);
  assert.equal(topicEvidence(state,topic.id).retained,false);
});
test('changing option order does not change question identity, new context does',()=>{
  const q=readingTopics[0].makeQuestion(0);
  assert.equal(questionFingerprint(q),questionFingerprint({...q,options:[...q.options].reverse()}));
  assert.notEqual(questionFingerprint(q),questionFingerprint({...q,context:q.context+' Dữ kiện mới.'}));
  const legacy=defaultState();
  legacy.attempts=[{questionId:'old-seed',topicId:q.topicId,prompt:q.prompt,correct:true,unknown:false,independent:true,hintsUsed:0,at:'2026-10-18T01:00:00Z'}];
  assert.equal(recordAttempt(legacy,q,q.answer).attempts.at(-1).independent,false);
});
