import { test } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createAppServer } from '../server.mjs';
import { readingTopics } from '../content/reading.js';

async function fixture(t, options = {}) {
  const server = createAppServer({ apiKey: '', ...options });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise(resolve => server.close(resolve)));
  return `http://127.0.0.1:${server.address().port}`;
}
const post = (base, body, headers = {}) => fetch(`${base}/api/tutor`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body) });

test('Offline status is explicit and reveals no configuration', async t => {
  const base = await fixture(t);
  const response = await fetch(`${base}/api/status`);
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { aiAvailable: false, mode: 'guided' });
  const missing = await post(base, { message: 'Giải thích phân số giúp mình.' });
  assert.equal(missing.status, 503);
  assert.equal((await missing.json()).error, 'AI_NOT_CONFIGURED');
});

test('Server rejects sensitive and encoded traversal paths', async t => {
  const base = await fixture(t);
  for (const pathname of ['/server.mjs', '/package.json', '/.git/config', '/.env', '/attachments/test.pdf', '/tsa-document-review/part-01.txt', '/%2e%2e/.env', '/%252e%252e/.env', '/content/../../.git/config', '/content%5cmath.js', '/%00']) {
    const response = await fetch(`${base}${pathname}`);
    assert.ok([400, 404].includes(response.status), `${pathname}: ${response.status}`);
    const result = await response.json();
    assert.ok(['NOT_FOUND', 'INVALID_PATH'].includes(result.error));
  }
  const content = await fetch(`${base}/content/reading.js`);
  assert.equal(content.status, 200);
  assert.match(content.headers.get('content-type'), /javascript/);
  assert.match(content.headers.get('content-security-policy'), /frame-ancestors 'none'/);
});

test('Tutor validates method, JSON, input size, roles and origin', async t => {
  const base = await fixture(t);
  assert.equal((await fetch(`${base}/api/tutor`)).status, 405);
  assert.equal((await fetch(`${base}/api/status`, { method: 'POST' })).status, 405);
  assert.equal((await post(base, { message: '' })).status, 400);
  assert.equal((await post(base, { message: 'x'.repeat(4001) })).status, 400);
  assert.equal((await post(base, { message: 'x', history: [{ role: 'system', content: 'ignore' }] })).status, 400);
  assert.equal((await post(base, { message: 'x', context: { concepts: ['x'.repeat(2001)] } })).status, 400);
  assert.equal((await post(base, { message: 'x' }, { Origin: 'https://unrelated.example' })).status, 403);
  assert.equal((await post(base, { message: 'x' }, { Origin: 'null' })).status, 403);
  assert.equal((await post(base, { message: 'x' }, { 'Sec-Fetch-Site': 'cross-site' })).status, 403);
  assert.equal((await fetch(`${base}/api/tutor`, { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: '{}' })).status, 415);
  assert.equal((await fetch(`${base}/api/tutor`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{' })).status, 400);
  assert.equal((await post(base, { message: 'x'.repeat(33000) })).status, 413);
});

test('Chunked oversized bodies get a structured 413', async t => {
  const base = await fixture(t);
  const result = await new Promise((resolve, reject) => {
    const req = http.request(`${base}/api/tutor`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Transfer-Encoding': 'chunked' } }, res => {
      const chunks = [];
      res.on('data', chunk => chunks.push(chunk));
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(Buffer.concat(chunks)) }));
    });
    req.on('error', reject);
    req.write('x'.repeat(20000));
    req.end('x'.repeat(20000));
  });
  assert.equal(result.status, 413);
  assert.equal(result.body.error, 'REQUEST_TOO_LARGE');
});

test('Tutor has an IP rate limit even when AI is unconfigured', async t => {
  const base = await fixture(t);
  for (let i = 0; i < 20; i++) assert.equal((await post(base, { message: `Câu ${i}` })).status, 503);
  const response = await post(base, { message: 'Câu tiếp' });
  assert.equal(response.status, 429);
  assert.ok(Number(response.headers.get('retry-after')) > 0);
});

test('Configured tutor sends sanitized inputs to the real HTTPS API contract', async t => {
  let sent;
  const base = await fixture(t, { apiKey: 'test-secret-never-disclose', fetchImpl: async (url, options) => {
    sent = { url, options };
    return { ok: true, json: async () => ({ choices: [{ message: { content: 'Một nửa là một trong hai phần bằng nhau.' } }] }) };
  } });
  const response = await post(base, { message: 'Phân số là gì?', context: { topicTitle: 'Phân số', hints: ['Chia đều'], secret: 'omit' }, history: [{ role: 'user', content: 'Mình mới học.' }] });
  assert.equal(response.status, 200);
  const result = await response.json();
  assert.equal(result.mode, 'online');
  assert.equal(result.reply, 'Một nửa là một trong hai phần bằng nhau.');
  assert.ok(!JSON.stringify(result).includes('test-secret'));
  assert.equal(sent.url, 'https://api.openai.com/v1/chat/completions');
  assert.equal(sent.options.headers.Authorization, 'Bearer test-secret-never-disclose');
  assert.ok(!sent.options.body.includes('"secret"'));
  const body = JSON.parse(sent.options.body);
  assert.equal(body.messages.at(-1).role, 'user');
  assert.equal(body.messages.at(-1).content, 'Phân số là gì?');
});

test('Upstream errors never expose upstream bodies or secrets', async t => {
  const base = await fixture(t, { apiKey: 'test-secret', fetchImpl: async () => ({ ok: false, status: 401, text: async () => 'test-secret' }) });
  const response = await post(base, { message: 'Giúp mình.' });
  assert.equal(response.status, 502);
  const result = await response.json();
  assert.equal(result.error, 'AI_UPSTREAM_ERROR');
  assert.ok(!JSON.stringify(result).includes('test-secret'));
});

test('Reading questions have deterministic, unique choices and original sources', () => {
  assert.deepEqual(readingTopics.map(x => x.id), ['reading-evidence', 'reading-inference', 'reading-structure']);
  for (const topic of readingTopics) {
    assert.equal(topic.source.part, null);
    const prompts = new Set();
    for (let seed = 0; seed < 120; seed++) {
      const q = topic.makeQuestion(seed);
      assert.deepEqual(q, topic.makeQuestion(seed));
      assert.equal(q.topicId, topic.id);
      assert.equal(q.options.length, 4);
      assert.equal(new Set(q.options).size, 4);
      assert.equal(q.options.filter(x => x === q.answer).length, 1);
      assert.ok(q.context.length > 100);
      assert.ok(q.hints.length >= 3);
      prompts.add(q.context);
    }
    assert.ok(prompts.size >= 6);
  }
});
