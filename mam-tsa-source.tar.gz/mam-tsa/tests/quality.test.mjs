import test from 'node:test';
import assert from 'node:assert/strict';
import { defaultState, recordAttempt, validateImport } from '../learning.js';
import { chapterQuality, qualityOverview } from '../quality.js';

const topic = { id: 'numbers' };
const question = n => ({ id: `numbers:${n}`, topicId: 'numbers', prompt: `Một nhóm có ${n + 2} vật, thêm 3 vật. Có tất cả bao nhiêu vật?`, answer: String(n + 5), explanation: 'Cộng số vật ban đầu với 3.', transfer: n === 4 });
function readState() {
  const state = defaultState();
  state.completedLessons = ['numbers'];
  state.lessonReadAt = { numbers: '2026-10-19T08:00:00.000Z' };
  return state;
}
function quiz(state, { start = '2026-10-19T09:00:00Z', hints = 0, unknown = false, wrong = false } = {}) {
  for (let n = 0; n < 5; n++) {
    state = recordAttempt(state, question(n), unknown ? '__unknown' : wrong ? '9999' : question(n).answer, {
      at: new Date(Date.parse(start) + n * 60000).toISOString(), mode: 'topic', hintsUsed: hints
    });
  }
  state.assessments = [...state.assessments, {
    id: `result-${start}`, topicId: 'numbers', mode: 'topic', startedAt: start, at: new Date(Date.parse(start) + 5 * 60000).toISOString(),
    correct: unknown || wrong ? 0 : 5, total: 5, unknown: unknown ? 5 : 0, seconds: 300
  }];
  return state;
}

test('reading and a saved reflection do not establish understanding without a post-reading topic quiz', () => {
  const state = readState();
  state.reflections = [{ id: 'r1', topicId: 'numbers', text: 'Em đã hiểu.', at: '2026-10-19T08:10:00Z' }];
  // A mixed diagnostic is useful evidence but is not the end-of-section quiz.
  state.assessments = [{ id: 'd1', mode: 'diagnostic', topicId: '', at: '2026-10-19T08:30:00Z', correct: 12, total: 12, unknown: 0 }];
  const q = chapterQuality(state, topic, '2026-10-19T10:00:00Z');
  assert.equal(q.status, 'read-untested');
  assert.equal(q.read, true);
  assert.equal(q.hasAssessment, false);
  assert.equal(q.retained, false);
  assert.equal(q.nextAction, 'assess');
  assert.equal(q.reflectionCount, 1);
  assert.match(q.reflectionNotice, /chưa tự chấm/);
});

test('a quiz before the latest read-completion cannot stand in for its requested quality check', () => {
  const state = quiz(readState());
  state.lessonReadAt.numbers = '2026-10-20T08:00:00Z';
  const quality = chapterQuality(state, topic, '2026-10-20T09:00:00Z');
  assert.equal(quality.status, 'read-untested');
  assert.equal(quality.hasAssessment, false);
  assert.equal(quality.latestAssessment, null);
  assert.equal(quality.independent, 5);
  assert.equal(quality.lastReadAt, '2026-10-20T08:00:00.000Z');
  delete state.lessonReadAt;
  assert.equal(chapterQuality(state, topic).hasAssessment, true, 'legacy backup retains its quiz without a read timestamp');
});

test('five correct answers with hints and five unknown answers produce different honest repair guidance', () => {
  const guided = chapterQuality(quiz(readState(), { hints: 3 }), topic, '2026-10-19T10:00:00Z');
  assert.equal(guided.latestAssessment.correct, 5);
  assert.equal(guided.guided, 5);
  assert.equal(guided.independent, 0);
  assert.equal(guided.assessmentEvidence.guided, 5);
  assert.equal(guided.status, 'needs-independent');
  assert.equal(guided.retained, false);
  const unknown = chapterQuality(quiz(readState(), { unknown: true }), topic, '2026-10-19T10:00:00Z');
  assert.equal(unknown.unknown, 5);
  assert.equal(unknown.wrong, 0);
  assert.equal(unknown.status, 'needs-repair');
  assert.equal(unknown.nextAction, 'learn');
  const wrong = chapterQuality(quiz(readState(), { wrong: true }), topic, '2026-10-19T10:00:00Z');
  assert.equal(wrong.wrong, 5);
  assert.equal(wrong.unknown, 0);
  assert.equal(wrong.status, 'needs-repair');
});

test('independent new-context work awaits a real 24-hour recall and then recognizes recall evidence', () => {
  let state = quiz(readState());
  const before = chapterQuality(state, topic, '2026-10-20T08:59:00Z');
  assert.equal(before.independent, 5);
  assert.equal(before.transfer, 1);
  assert.equal(before.retained, false);
  assert.equal(before.status, 'awaiting-recall');
  assert.equal(before.dueAt, '2026-10-20T09:04:00.000Z');
  const due = chapterQuality(state, topic, '2026-10-20T09:05:00Z');
  assert.equal(due.status, 'due-recall');
  assert.equal(due.isDue, true);
  state = recordAttempt(state, question(0), question(0).answer, { at: '2026-10-20T09:06:00Z', mode: 'review' });
  const recalled = chapterQuality(state, topic, '2026-10-20T09:07:00Z');
  assert.equal(recalled.retrieval, 1);
  assert.equal(recalled.independent, 5, 'recall does not inflate distinct independent work');
  assert.equal(recalled.retained, true);
  assert.equal(recalled.status, 'retained');
});

test('immediate repeated perfect quizzes do not become new understanding, including after backup restore', () => {
  const state = quiz(quiz(readState()), { start: '2026-10-19T09:20:00Z' });
  const q = chapterQuality(state, topic, '2026-10-19T10:00:00Z');
  assert.equal(q.attempts, 10);
  assert.equal(q.independent, 5);
  assert.equal(q.repeated, 5);
  assert.equal(q.assessmentEvidence.repeated, 5);
  assert.equal(q.assessmentEvidence.independent, 0);
  assert.equal(q.status, 'needs-independent');
  assert.equal(q.retained, false);
  const restored = validateImport(JSON.parse(JSON.stringify(state)));
  // The read timestamp is part of the current schema; legacy schema can omit it.
  assert.deepEqual(chapterQuality(restored, topic, '2026-10-19T10:00:00Z'), q);
});

test('historical mastery cannot hide a new failure, and an incomplete legacy quiz is not guessed from unrelated attempts', () => {
  let state = quiz(readState());
  state = recordAttempt(state, question(0), question(0).answer, { at: '2026-10-20T09:06:00Z', mode: 'review' });
  assert.equal(chapterQuality(state, topic, '2026-10-20T09:07:00Z').status, 'retained');
  state = recordAttempt(state, { ...question(7), id: 'numbers:new' }, 'wrong', { at: '2026-10-20T10:00:00Z', mode: 'practice' });
  const changed = chapterQuality(state, topic, '2026-10-20T10:01:00Z');
  assert.equal(changed.retained, true, 'historical evidence remains visible');
  assert.equal(changed.status, 'needs-repair', 'current action still addresses the new gap');
  assert.equal(qualityOverview(state, [topic], '2026-10-20T10:01:00Z').retained, 0);
  state = recordAttempt(state, question(8), question(8).answer, { at: '2026-10-20T10:02:00Z', mode: 'practice' });
  assert.equal(chapterQuality(state, topic, '2026-10-20T10:03:00Z').status, 'needs-repair', 'a correct different question cannot hide the open gap');
  assert.equal(qualityOverview(state, [topic], '2026-10-20T10:03:00Z').retained, 0);
  assert.equal(chapterQuality(validateImport(JSON.parse(JSON.stringify(state))), topic, '2026-10-20T10:03:00Z').status, 'needs-repair');
  const legacy = readState();
  delete legacy.lessonReadAt;
  legacy.assessments = [{ id: 'old', mode: 'topic', topicId: 'numbers', at: '2026-10-19T09:05:00Z', correct: 5, total: 5, unknown: 0 }];
  const legacyQuality = chapterQuality(legacy, topic, '2026-10-19T10:00:00Z');
  assert.equal(legacyQuality.hasAssessment, true);
  assert.equal(legacyQuality.assessmentEvidence, null);
  assert.equal(legacyQuality.status, 'needs-independent');
});

test('unknown followed by unrelated success stays visible until a new topic quiz confirms the section', () => {
  let state = quiz(readState());
  state = recordAttempt(state, question(0), question(0).answer, { at: '2026-10-20T09:06:00Z', mode: 'review' });
  state = recordAttempt(state, question(9), '__unknown', { at: '2026-10-20T10:00:00Z', mode: 'practice' });
  state = recordAttempt(state, question(10), question(10).answer, { at: '2026-10-20T10:02:00Z', mode: 'practice' });
  assert.equal(chapterQuality(state, topic, '2026-10-20T10:03:00Z').status, 'needs-repair');
  state = quiz(state, { start: '2026-10-21T10:00:00Z' });
  const reassessed = chapterQuality(state, topic, '2026-10-21T10:06:00Z');
  assert.equal(reassessed.status, 'retained', 'a new successful topic quiz can confirm repair; old gaps are not permanent');
  assert.equal(reassessed.latestAssessment.correct, 5);
  assert.equal(reassessed.unknown, 1, 'history remains available after successful reassessment');
});

test('finishing an already-started quiz after marking a section read cannot satisfy its new knowledge check', () => {
  const answeredBeforeRead = quiz(readState());
  answeredBeforeRead.lessonReadAt.numbers = '2026-10-19T10:00:00Z';
  answeredBeforeRead.assessments[0].at = '2026-10-19T10:01:00Z';
  assert.equal(chapterQuality(answeredBeforeRead, topic, '2026-10-19T10:02:00Z').status, 'read-untested');
  assert.equal(chapterQuality(answeredBeforeRead, topic).hasAssessment, false);

  // Even if all answers come later, resuming a quiz started before this read
  // cannot be presented as the explicitly requested new end-of-section quiz.
  const resumed = quiz(readState(), { start: '2026-10-19T10:01:00Z' });
  resumed.lessonReadAt.numbers = '2026-10-19T10:00:00Z';
  resumed.assessments[0].startedAt = '2026-10-19T09:00:00Z';
  assert.equal(chapterQuality(resumed, topic).hasAssessment, false);
  delete resumed.assessments[0].startedAt;
  assert.equal(chapterQuality(resumed, topic).hasAssessment, false, 'missing start time is insufficient when a read timestamp exists');
  resumed.assessments[0].startedAt = '2026-10-19T10:01:00Z';
  assert.equal(chapterQuality(resumed, topic).hasAssessment, true, 'a genuinely new post-reading quiz qualifies');
  assert.equal(chapterQuality(validateImport(JSON.parse(JSON.stringify(resumed))), topic).hasAssessment, true);
});

test('stable assessment IDs preserve the actual quiz evidence across unrelated answers and backup restore', () => {
  let state = quiz(readState(), { hints: 2 });
  const assessmentId = state.assessments[0].id;
  state.attempts = state.attempts.map(a => ({ ...a, assessmentId }));
  // Extra attempts may share the same time window, but do not belong to this quiz.
  for (let n = 10; n < 15; n++) {
    state = recordAttempt(state, question(n), question(n).answer, { at: '2026-10-19T09:04:30Z', mode: 'topic', assessmentId: 'another-quiz' });
  }
  const q = chapterQuality(state, topic, '2026-10-19T10:00:00Z');
  assert.equal(q.assessmentEvidence.guided, 5);
  assert.equal(q.assessmentEvidence.independent, 0);
  assert.equal(q.status, 'needs-independent');
  const restored = validateImport(JSON.parse(JSON.stringify(state)));
  assert.equal(restored.attempts[0].assessmentId, assessmentId);
  assert.deepEqual(chapterQuality(restored, topic, '2026-10-19T10:00:00Z'), q);
});
