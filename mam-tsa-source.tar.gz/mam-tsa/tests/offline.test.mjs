import test, { before } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { topics } from '../content.js';
import { defaultState, validateImport, recordAttempt, createQuestions } from '../learning.js';
import { SOURCE_FILES, OPTIONAL_FILES, packageSource } from '../scripts/package-source.mjs';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
let html;
before(async () => {
  const result = spawnSync(process.execPath, ['scripts/build.mjs'], { cwd: root, encoding: 'utf8' });
  assert.equal(result.status, 0, `Standalone build failed: ${result.stderr}`);
  html = await readFile(path.join(root, 'dist', 'mam-tsa.html'), 'utf8');
});

test('downloaded HTML embeds scripts and styles without a remote asset dependency', () => {
  assert.match(html, /globalThis\.__TSA_STANDALONE__\s*=\s*true/);
  assert.match(html, /<style>[\s\S]+<\/style>/);
  assert.match(html, /<script>[\s\S]+<\/script>/);
  assert.doesNotMatch(html, /<script\b[^>]*\bsrc\s*=/i);
  assert.doesNotMatch(html, /<link\b[^>]*\brel=["']stylesheet["']/i);
  assert.doesNotMatch(html, /@import\s+(?:url\()?\s*["']?https?:/i);
  assert.doesNotMatch(html, /url\(\s*["']?https?:/i);
  for (const match of html.matchAll(/<(?:img|iframe|audio|video|source|embed)\b[^>]*\bsrc\s*=\s*["']([^"']+)["']/gi)) {
    assert.match(match[1], /^(?:data:|#)/, `External required asset: ${match[1]}`);
  }
  assert.doesNotMatch(html, /\b(?:import|export)\s+(?:\{|\*|default|const|function|class)\s/);
});

test('learning and backup still work decades after the default goal month', t => {
  t.mock.timers.enable({ apis: ['Date'], now: new Date('2099-10-19T03:00:00Z') });
  const state = defaultState();
  assert.equal(state.profile.targetMonth, '2027-05');
  const questions = createQuestions(topics, state, 'topic', 'numbers');
  assert.equal(questions.length, 5);
  const answered = recordAttempt(state, questions[0], questions[0].answer);
  answered.notes.push({ id: 'future-note', text: 'Mình vẫn học và giữ được ghi chú.', topicId: 'numbers', at: new Date().toISOString() });
  answered.completedLessons.push('numbers');
  const restored = validateImport(JSON.parse(JSON.stringify(answered)));
  assert.equal(restored.attempts.length, 1);
  assert.equal(restored.attempts[0].correct, true);
  assert.equal(restored.attempts[0].at, '2099-10-19T03:00:00.000Z');
  assert.equal(restored.notes[0].text, 'Mình vẫn học và giữ được ghi chú.');
  assert.deepEqual(restored.completedLessons, ['numbers']);
  assert.equal(createQuestions(topics, restored, 'diagnostic').length, 12);
});

test('source archive contains only the explicit code list plus standalone HTML', async () => {
  const result = await packageSource();
  const listed = spawnSync('tar', ['--list', '--gzip', '--file', result.output], { encoding: 'utf8' });
  assert.equal(listed.status, 0, listed.stderr);
  const names = listed.stdout.trim().split('\n').sort();
  const expected = [...SOURCE_FILES, ...OPTIONAL_FILES].map(v => 'mam-tsa/' + v).sort();
  assert.deepEqual(names, expected);
  for (const name of names) {
    assert.doesNotMatch(name, /(?:^|\/)(?:\.git|\.env(?:\.|$)|node_modules|attachments|tsa-document-review)(?:\/|$)/);
    assert.doesNotMatch(name, /\.(?:pdf|zip|key|pem)$/i);
    assert.ok(!name.includes('..'), `Unexpected traversal entry: ${name}`);
  }
});
