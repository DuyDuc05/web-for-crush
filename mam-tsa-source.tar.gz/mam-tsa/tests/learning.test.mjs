import test from 'node:test';
import assert from 'node:assert/strict';
import {
  defaultState, recordAttempt, topicEvidence, recommendTopics, validateImport,
  todayKey, studyPlan, activityDays, learningStreak, createQuestions,
} from '../learning.js';

const now = '2026-10-18T03:00:00.000Z';
const fixtureNumbers=new Map();
const q = (id = 'numbers:fixture', transfer = false) => {if(!fixtureNumbers.has(id))fixtureNumbers.set(id,3+fixtureNumbers.size);const n=fixtureNumbers.get(id);return{id,topicId:'numbers',prompt:'Tính '+n+' + ('+(5-n)+').',answer:'5',explanation:'Kết quả là 5.',difficulty:1,transfer};};
const answer = (s, id, at, options = {}) => recordAttempt(s, q(id, options.transfer), '5', {at, ...options});

test('new learner defaults to 150 minutes and May 2027 without invented evidence', () => {
  const s = defaultState();
  assert.equal(s.profile.dailyMinutes, 150);
  assert.equal(s.profile.targetMonth, '2027-05');
  assert.deepEqual(s.attempts, []);
  assert.equal(topicEvidence(s, 'numbers', now).score, 0);
  assert.equal(topicEvidence(s, 'numbers', now).label, 'Chưa đủ dữ liệu');
});

test('first unseen correct answer is independent; hints, repeat and unknown are different evidence', () => {
  const initial = defaultState();
  let s = recordAttempt(initial, q(), '5', {at:now});
  assert.equal(initial.attempts.length, 0, 'recordAttempt must not mutate old state');
  assert.equal(s.attempts[0].correct, true);
  assert.equal(s.attempts[0].independent, true);
  s = recordAttempt(s, q(), '5', {at:now});
  assert.equal(s.attempts[1].independent, false, 'memorising the identical question is not new evidence');
  s = recordAttempt(s, q('numbers:hinted'), '5', {hintsUsed:1, at:now});
  assert.equal(s.attempts[2].correct, true);
  assert.equal(s.attempts[2].independent, false);
  s = recordAttempt(s, q('numbers:unknown'), '__unknown', {at:now});
  assert.equal(s.attempts[3].unknown, true);
  assert.equal(s.attempts[3].correct, false);
  assert.equal(s.attempts[3].independent, false);
  const e = topicEvidence(s, 'numbers', now);
  assert.deepEqual([e.attempts,e.known,e.independent,e.guided,e.repeated,e.unknown,e.failed], [4,3,1,1,1,1,0]);
});

test('wrong answers are evidence for consolidation; high confidence errors are visible', () => {
  let s = defaultState();
  for (let i=0;i<2;i++) s = recordAttempt(s,q(`numbers:wrong${i}`),'4',{at:now,confidence:'high'});
  const e = topicEvidence(s, 'numbers', now);
  assert.equal(e.failed,2);
  assert.equal(e.confidenceErrors,2);
  assert.equal(e.label,'Cần củng cố');
  assert.equal(e.independent,0);
});

test('mastery remains capped until new-day retention AND independent transfer evidence exist', () => {
  let s = defaultState();
  for(let i=0;i<12;i++)s=answer(s,`numbers:day0-${i}`,'2026-10-16T03:00:00Z');
  assert.equal(topicEvidence(s,'numbers',now).retained,false);
  assert.equal(topicEvidence(s,'numbers',now).score,60);
  s=answer(s,'numbers:day2','2026-10-18T03:00:00Z');
  assert.equal(topicEvidence(s,'numbers',now).retained,false, 'spaced answers alone cannot establish transfer');
  s=answer(s,'numbers:transfer','2026-10-18T03:01:00Z',{transfer:true,hintsUsed:1});
  assert.equal(topicEvidence(s,'numbers',now).retained,false, 'hinted transfer is not independent');
  s=answer(s,'numbers:new-transfer','2026-10-18T03:02:00Z',{transfer:true});
  const e=topicEvidence(s,'numbers','2026-10-18T03:03:00Z');
  assert.equal(e.retained,true);
  assert.equal(e.days,2);
  assert.equal(e.transfer,1);
  assert.equal(e.label,'Có bằng chứng nhớ lại');
  assert.ok(e.score>60&&e.score<=95);
});

test('review dates distinguish error (10min), hinted (1day), and independent repetition (3days)', () => {
  const s=defaultState();
  const wrong=recordAttempt(s,q(),'4',{at:now});
  assert.equal(topicEvidence(wrong,'numbers',now).dueAt,'2026-10-18T03:10:00.000Z');
  assert.equal(topicEvidence(wrong,'numbers','2026-10-18T03:09:59Z').isDue,false);
  assert.equal(topicEvidence(wrong,'numbers','2026-10-18T03:10:00Z').isDue,true);
  const guided=recordAttempt(s,q(),'5',{at:now,hintsUsed:2});
  assert.equal(topicEvidence(guided,'numbers',now).dueAt,'2026-10-19T03:00:00.000Z');
  let independent=answer(s,'numbers:a',now);
  independent=answer(independent,'numbers:b',now);
  assert.equal(topicEvidence(independent,'numbers',now).dueAt,'2026-10-21T03:00:00.000Z');
});

test('recommendations favour prerequisite foundation and due reviews, without mutating content order', () => {
  const topics=[{id:'advanced',level:2,prerequisites:['foundation']},{id:'foundation',level:0,prerequisites:[]},{id:'review',level:1,prerequisites:[]}];
  assert.equal(recommendTopics(defaultState(),topics,now)[0].id,'foundation');
  const s=recordAttempt(defaultState(),{...q('review:1'),topicId:'review'},'4',{at:'2026-10-17T03:00:00Z'});
  assert.equal(recommendTopics(s,topics,now)[0].id,'review');
  assert.equal(topics[0].id,'advanced');
});

test('150-minute daily plan contains three balanced blocks and accounts for rests honestly', () => {
  const p=studyPlan(150);
  assert.deepEqual(p.map(x=>x.total),[50,50,50]);
  assert.deepEqual(p.map(x=>x.focus),[45,45,45]);
  assert.deepEqual(p.map(x=>x.rest),[5,5,5]);
  assert.equal(p.reduce((n,x)=>n+x.focus+x.rest,0),150);
  for(const n of [15,16,149,151,480]){
    const plan=studyPlan(n);
    assert.equal(plan.reduce((sum,x)=>sum+x.total,0),n);
    assert.ok(plan.every(x=>x.focus>=0&&x.rest>=0));
  }
});

test('Vietnam date, daily activity and streak use the learner timezone', () => {
  assert.equal(todayKey('2026-10-17T18:01:00Z'),'2026-10-18');
  assert.equal(todayKey('2026-10-17T16:59:00Z'),'2026-10-17');
  const s=defaultState();
  s.studySeconds={'2026-10-16':60,'2026-10-17':120,'2026-10-18':59};
  assert.deepEqual(activityDays(s),['2026-10-16','2026-10-17']);
  assert.equal(learningStreak(s,new Date(now)),2);
});

test('backup round-trip preserves evidence, settings, notes and review dates', () => {
  let s=answer(defaultState(),'numbers:good',now);
  s.profile.name='Người học';s.notes=[{id:'n1',text:'Cần đọc kỹ đơn vị',topicId:'numbers',at:now}];
  s.reflections=[{id:'r1',text:'Mình giải thích được vì sao cộng.',topicId:'numbers',at:now}];
  s.studySeconds={'2026-10-18':90};
  const restored=validateImport(JSON.parse(JSON.stringify(s)));
  assert.deepEqual(restored.profile,s.profile);
  assert.deepEqual(restored.attempts,s.attempts);
  assert.deepEqual(restored.notes,s.notes);
  assert.deepEqual(restored.reflections,s.reflections);
  assert.deepEqual(restored.studySeconds,s.studySeconds);
  assert.equal(topicEvidence(restored,'numbers',now).dueAt,topicEvidence(s,'numbers',now).dueAt);
});

test('backup rejects corrupt schema, invalid dates, impossible results and abusive bounds', () => {
  const corrupt=[null,[],{}, {...defaultState(),version:2}, {...defaultState(),profile:{dailyMinutes:0,targetMonth:'2027-05'}}, {...defaultState(),profile:{dailyMinutes:150,targetMonth:'2027-13'}}, {...defaultState(),attempts:[{topicId:'numbers',questionId:'q',correct:true,at:'bad'}]}, {...defaultState(),notes:[{at:now,text:42}]}, {...defaultState(),assessments:[{at:now,total:5,correct:6}]}];
  for(const data of corrupt)assert.throws(()=>validateImport(data));
});

test('backup discards prototype pollution, arbitrary fields and API credential fields', () => {
  const input=JSON.parse(JSON.stringify(defaultState()));
  Object.assign(input,JSON.parse('{"__proto__":{"polluted":true},"constructor":{"prototype":{"polluted":true}},"apiKey":"secret-placeholder","OPENAI_API_KEY":"secret-placeholder"}'));
  input.profile.apiKey='secret-placeholder';input.profile.aiApiKey='secret-placeholder';
  const restored=validateImport(input);
  assert.equal({}.polluted,undefined);
  assert.equal(Object.hasOwn(restored,'__proto__'),false);
  assert.equal(Object.hasOwn(restored,'constructor'),false);
  assert.equal(JSON.stringify(restored).includes('secret-placeholder'),false);
});

test('backup cannot turn hinted or wrong answers into independent evidence', () => {
  let s=recordAttempt(defaultState(),q(),'4',{at:now});
  s.attempts[0].independent=true;
  assert.equal(validateImport(s).attempts[0].independent,false);
  s=recordAttempt(defaultState(),q(),'5',{at:now,hintsUsed:1});
  s.attempts[0].independent=true;
  assert.equal(validateImport(s).attempts[0].independent,false);
});

test('malformed saved assessment is safely abandoned rather than executing supplied data', () => {
  const s=defaultState();
  s.activeAssessment={mode:'topic',index:0,questions:[{id:'q',topicId:'numbers',prompt:'x',options:['a','a'],answer:'a',explanation:'x',hints:[]}],results:[],startedAt:now};
  assert.equal(validateImport(s).activeAssessment,null);
});

test('assessments have 12 diagnostic / 15 mixed / 5 topic questions with requested domain balance', async () => {
  const {topics}=await import('../content.js');
  for(const [mode,total,balance] of [['diagnostic',12,{math:6,science:3,reading:3}],['practice',15,{math:6,science:6,reading:3}]]){
    const questions=createQuestions(topics,defaultState(),mode);
    assert.equal(questions.length,total);
    const counts={math:0,science:0,reading:0};
    for(const q of questions)counts[topics.find(t=>t.id===q.topicId).domain]++;
    assert.deepEqual(counts,balance);
    assert.equal(new Set(questions.map(q=>q.id)).size,total);
  }
  const topic=createQuestions(topics,defaultState(),'topic','numbers');
  assert.equal(topic.length,5);
  assert.ok(topic.every(q=>q.topicId==='numbers'));
});

test('all 21 topics generate 100 deterministic well-formed question seeds', async () => {
  const {topics}=await import('../content.js');
  assert.equal(topics.length,21);
  assert.deepEqual(['math','science','reading'].map(domain=>topics.filter(t=>t.domain===domain).length),[12,6,3]);
  assert.equal(new Set(topics.map(t=>t.id)).size,topics.length);
  for(const t of topics){
    assert.ok(t.concepts.length>=2&&t.example.steps.length>=2&&t.reflection.length>10,t.id);
    for(const id of t.prerequisites)assert.ok(topics.some(t=>t.id===id),`${t.id}: unknown prerequisite ${id}`);
    for(let seed=0;seed<100;seed++){
      const q=t.makeQuestion(seed);
      assert.deepEqual(q,t.makeQuestion(seed),`${t.id}:${seed} is not deterministic`);
      assert.equal(q.topicId,t.id);
      assert.equal(new Set(q.options).size,4,`${t.id}:${seed} must have four distinct answers`);
      assert.equal(q.options.filter(v=>v===q.answer).length,1);
      assert.ok(q.prompt.length>10&&q.explanation.length>20&&q.hints.length>=2);
      assert.ok(q.options.every(v=>typeof v==='string'));
      assert.ok([1,2,3].includes(q.difficulty));
    }
  }
});

const numericAnswer = answer => Number(answer.match(/^-?\d+(?:[,.]\d+)?/)?.[0].replace(',','.'));
const nums = text => [...text.matchAll(/-?\d+(?:[,.]\d+)?/g)].map(m=>Number(m[0].replace(',','.')));
function closeAnswer(q,expected){assert.ok(Math.abs(numericAnswer(q.answer)-expected)<0.000002,`${q.topicId} ${q.prompt}: expected ${expected}, got ${q.answer}`);}

test('science numerical answers are independently recomputed from prompt/table across 100 seeds', async () => {
  const {scienceTopics}=await import('../content/science.js');
  for(const topic of scienceTopics)for(let seed=0;seed<100;seed++){
    const q=topic.makeQuestion(seed),n=nums(q.prompt),p=q.prompt;
    switch(topic.id){
      case 'units':
        if(p.includes('tốc độ'))closeAnswer(q,n[0]*1000/3600);
        else if(p.includes('khối lượng'))closeAnswer(q,n[0]/1000);
        else if(p.includes('diện tích'))closeAnswer(q,n[0]/(100*100));
        else assert.equal(q.answer,'Công thức A');
        break;
      case 'motion':
        if(q.table){const rows=q.table.rows;closeAnswer(q,(Number(rows.at(-1)[1])-Number(rows[0][1]))/(Number(rows.at(-1)[0])-Number(rows[0][0])));}
        else if(p.toLowerCase().includes('gia tốc'))closeAnswer(q,(n[1]-n[0])/n[2]);
        else if(p.includes('Trên một trục'))closeAnswer(q,(n[2]-n[0])/n[1]);
        else closeAnswer(q,n[0]/n[1]);
        break;
      case 'forces':
        if(p.includes('lò xo'))assert.equal(q.answer,'Lực lò xo hướng sang trái, cùng hướng vận tốc');
        else if(p.includes('Trọng lượng'))closeAnswer(q,n[0]*n[1]);
        else if(p.includes('Gia tốc'))closeAnswer(q,n[1]/n[0]);
        else assert.equal(q.answer,`${n[0]-n[1]} N sang phải`);
        break;
      case 'energy':
        if(p.includes('tăng gấp'))assert.equal(q.answer,`Gấp ${n[0]**2} lần`);
        else if(p.includes('cơ năng')){
          // Extract the stated energy measurements, not every numeral: the
          // explicit zero of gravitational potential is a model assumption.
          const total=p.match(/cơ năng (\d+(?:[,.]\d+)?) J/);
          const kinetic=p.match(/động năng là (\d+(?:[,.]\d+)?) J/);
          assert.ok(total&&kinetic,'The prompt must state total and kinetic energy');
          closeAnswer(q,Number(total[1].replace(',','.'))-Number(kinetic[1].replace(',','.')));
        }
        else if(p.includes('nâng lên'))closeAnswer(q,n[0]*n[1]*n[2]);
        else closeAnswer(q,n[0]*n[1]**2/2);
        break;
      case 'chemistry':
        if(p.includes('phân tử nước H₂O'))assert.equal(q.answer,`${2*n[0]} nguyên tử H và ${n[0]} nguyên tử O`);
        else if(p.includes('cân bằng'))assert.equal(q.answer,'2H₂ + O₂ → 2H₂O');
        else if(p.includes('khối lượng mol'))closeAnswer(q,n[0]/n[1]);
        else if(p.includes('mol phân tử O₂'))closeAnswer(q,2*n[0]);
        else closeAnswer(q,n[0]+n[1]);
        break;
      case 'experiment':
        if(p.includes('hoạt tính')){const row=[...q.table.rows].sort((a,b)=>Number(b[1])-Number(a[1]))[0];assert.equal(q.answer,`pH ${row[0]}`);}
        else if(q.table){assert.ok(Number(q.table.rows[1][2])>Number(q.table.rows[0][2]));assert.equal(q.answer,'Trong điều kiện đã thử, nhóm nhận 8 giờ sáng có mức tăng chiều cao trung bình lớn hơn');}
        else if(p.includes('phân bón'))assert.equal(q.answer,'Vừa thay phân bón vừa thay lượng nước nên chưa tách được ảnh hưởng của phân bón');
        else assert.equal(q.answer,'Lặp lại phép đo trên nhiều mẫu tương đương rồi xem cả trung bình và mức phân tán');
        break;
      default:assert.fail(`No independent science oracle for ${topic.id}`);
    }
  }
});

const rational = value => {
  const m=value.replaceAll('−','-').match(/-?\d+(?:[,.]\d+)?(?:\/-?\d+)?/);
  if(!m)return NaN;
  const [a,b]=m[0].replace(',','.').split('/').map(Number);return b===undefined?a:a/b;
};
function equivalent(q,value){assert.ok(Math.abs(rational(q.answer)-value)<0.000002,`${q.topicId}: ${q.prompt}: independently expected ${value}, received ${q.answer}`);}
function rootSet(q,expected){assert.deepEqual(nums(q.answer.replaceAll('−','-')).sort((a,b)=>a-b),[...new Set(expected)].sort((a,b)=>a-b),q.prompt);}

test('math answers independently satisfy arithmetic, equation, geometric and data oracles for 100 seeds/topic', async () => {
  const {mathTopics}=await import('../content/math.js');
  for(const t of mathTopics)for(let seed=0;seed<100;seed++){
    const q=t.makeQuestion(seed),p=q.prompt.replaceAll('−','-'),n=nums(p);
    switch(t.id){
      case 'numbers':
        equivalent(q,[n[0]+n[1],n[0]-n[1],n[0]+n[1]*n[2],Math.max(...n)][seed%4]);break;
      case 'fractions':
        equivalent(q,seed%3===0?n[0]/n[1]+n[2]/n[3]:seed%3===1?(n[0]/n[1])/(n[2]/n[3]):n[0]*n[1]/n[2]);break;
      case 'percent':
        equivalent(q,seed%3===0?n[0]*n[1]/100:seed%3===1?n[0]*(1-n[1]/100)*(1+n[2]/100):n[1]/(1-n[0]/100));break;
      case 'algebra':
        if(seed%4===0)equivalent(q,n[0]*n[2]-n[1]);
        else if(seed%4===1)assert.equal(q.answer,`${n[0]}x + ${n[0]*n[1]}`);
        else if(seed%4===2)assert.equal(q.answer,`−${n[0]}x + ${Math.abs(n[1])}`);
        else assert.equal(q.answer,`Trừ ${n[1]} ở cả hai vế`);
        break;
      case 'linear':
        if(seed%4===0)equivalent(q,(n[2]-n[1])/n[0]);
        else if(seed%4===1){const sign=/x\s*-\s*\d+\./.test(p)?-1:1;equivalent(q,(sign*Math.abs(n[3])-n[1])/(n[0]-n[2]));}
        else if(seed%4===2)equivalent(q,(n[2]-n[1])/n[0]);
        else assert.equal(q.answer,n[1]===n[2]?'Mọi số thực x':'Không có nghiệm');
        break;
      case 'quadratic':
        if(seed%4===0)rootSet(q,[-Math.sqrt(n[0]),Math.sqrt(n[0])]);
        else if(seed%4===2)assert.equal(q.answer,'Không có nghiệm thực');
        else {const factors=[...p.matchAll(/\(x\s*([+-])\s*(\d+)\)|\bx\b/g)].map(m=>m[1]?(m[1]==='-'?1:-1)*Number(m[2]):0);rootSet(q,factors);}
        break;
      case 'functions':
        if(seed%4===0){const intercept=/x\s*-\s*\d/.test(p)?-Math.abs(n[1]):n[1];equivalent(q,n[0]*n[2]+intercept);}
        else if(seed%4===1)equivalent(q,(Number(q.table.rows[1][1])+Number(q.table.rows[2][1]))/2);
        else if(seed%4===2)equivalent(q,(n[3]-n[1])/(n[2]-n[0]));
        else equivalent(q,n[1]);
        break;
      case 'geometry':
        equivalent(q,[n[0]*n[1]/2,2*(n[0]+n[1]),n[0]*n[1]**2,Math.hypot(n[0],n[1]),(n[0]/2)**2][seed%5]);
        if(seed%5===4)assert.ok(q.answer.includes('π cm²'));
        break;
      case 'trigonometry':
        equivalent(q,seed%4===0?n[0]/n[2]:seed%4===1?n[1]/n[2]:seed%4===2?n[0]/n[1]:n[2]*n[0]/n[1]);break;
      case 'exponents':
        equivalent(q,seed%4===0?n[0]**n[1]*n[2]**n[3]:seed%4===1?n[0]**n[1]:seed%4===2?Math.log(n[1])/Math.log(n[0]):Math.sqrt(n[0]**2));break;
      case 'probability':
        if(q.table){const rows=q.table.rows;equivalent(q,Number(rows[0][1])/(Number(rows[0][1])+Number(rows[1][1])));}
        else if(seed%4===0)equivalent(q,n[0]/(n[0]+n[1]));
        else if(seed%4===1){let favorable=0,total=0;for(let a=0;a<n[0]+n[1];a++)for(let b=0;b<n[0]+n[1];b++)if(a!==b){total++;if(a<n[0]&&b<n[0])favorable++;}equivalent(q,favorable/total);}
        else {let count=0;for(let a=1;a<=6;a++)for(let b=1;b<=6;b++)if(a+b===n[0])count++;equivalent(q,count/36);}
        break;
      case 'statistics':
        if(q.table){let sum=0,count=0;for(const row of q.table.rows){sum+=Number(row[0])*Number(row[1]);count+=Number(row[1]);}equivalent(q,sum/count);}
        else if(seed%4===0){const values=n.slice(1);equivalent(q,values.reduce((a,b)=>a+b,0)/values.length);}
        else if(seed%4===1)equivalent(q,[...n].sort((a,b)=>a-b)[Math.floor(n.length/2)]);
        else equivalent(q,Math.max(...n)-Math.min(...n));
        break;
      default:assert.fail(`Missing independent math oracle for ${t.id}`);
    }
  }
});

test('reading answers agree with 18 independently reviewed passage fixtures', async () => {
  const {readingTopics}=await import('../content/reading.js');
  const expected={
    'reading-evidence':['15 giờ','Mỗi lần đo đều diễn ra lúc 7 giờ.','Có 10 bạn chọn xe đạp.','9–11 giờ sáng thứ Ba','Ôn lại các ghi chú.','Cảm giác dễ chịu của người học.'],
    'reading-inference':['Lan đã đăng ký trước.','Viên bi Bình lấy ra màu xanh.','6 giờ 45 phút','Trong phép thử này, cốc đặt dưới nắng có nhiệt độ cuối cao hơn.','Chưa, vì Minh chưa hoàn thành bài B.','Xe đã đi qua trạm A.'],
    'reading-structure':['Trình tự các bước thực hiện.','So sánh hai cách di chuyển theo đặc điểm và điều kiện sử dụng.','Nguyên nhân và kết quả.','Đưa ra tình huống cho thấy nhận định ở câu đầu chưa đủ.','Minh họa một hành động cụ thể phù hợp với ý sử dụng nước cẩn thận.','Nêu vấn đề rồi mô tả cách giải quyết.'],
  };
  for(const t of readingTopics)for(let seed=0;seed<100;seed++){
    const q=t.makeQuestion(seed);
    assert.equal(q.answer,expected[t.id][seed%6],`${t.id}:${seed}`);
    assert.ok(q.context.length>60);
    assert.equal(t.source.part,null,'original passages must not be attributed to the book');
  }
});
