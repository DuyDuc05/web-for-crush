import test from 'node:test';
import assert from 'node:assert/strict';
import {prepareTutorPayload}from'../ai.js';
import {createAppServer}from'../server.mjs';
import {once}from'node:events';
test('long Vietnamese chat history is bounded by bytes and accepted on the next AI request',async()=>{
  const topic={title:'Học',concepts:['ễ'.repeat(5000),'ễ'.repeat(5000)],example:{steps:['ễ'.repeat(3000),'ễ'.repeat(3000)],prompt:'ễ'.repeat(3000),answer:'ễ'.repeat(3000)}};
  const history=Array.from({length:12},(_,i)=>({role:i%2?'assistant':'user',content:'ễ'.repeat(i%2?12000:3000)}));
  const payload=prepareTutorPayload('ễ'.repeat(3000),topic,history);
  assert.ok(new TextEncoder().encode(JSON.stringify(payload)).byteLength<=28*1024);
  assert.ok(payload.history.every(m=>m.content.length<=2000));
  const server=createAppServer({apiKey:'test-key',fetchImpl:async()=>new Response(JSON.stringify({choices:[{message:{content:'Một gợi ý ngắn.'}}]}),{status:200})});
  server.listen(0,'127.0.0.1');await once(server,'listening');
  try{const response=await fetch('http://127.0.0.1:'+server.address().port+'/api/tutor',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});assert.equal(response.status,200);assert.equal((await response.json()).reply,'Một gợi ý ngắn.');}finally{await new Promise(resolve=>server.close(resolve));}
});
